---
name: Auto Evolution (能力吞噬进化系统)
slug: auto-evolution
version: 1.1.0
description: MSOP能力吞噬进化引擎 - 自动扫描GitHub/ClawHub热门项目，分析匹配缺口能力，评分筛选后吞噬注册为新能力，支持沙盒安全验证、自我反思和低价值能力淘汰，实现智能体的持续能力进化
homepage: https://github.com/your-username/auto-evolution
changelog: "Release 1.1.0 - 优化跨平台兼容，修复硬编码路径，简化核心流程"
metadata:
  emoji: "🧬"
  requires:
    bins:
      - node
      - git
    os:
      - linux
      - darwin
      - win32
---

# Auto Evolution - MSOP 能力吞噬进化引擎 🧬

## 概述

Auto Evolution 是一个完整的 MSOP (Multi-agent Self-Organizing Protocol) 能力进化引擎，它让你的智能体能够：
- 自动扫描 GitHub Trending 与 ClawHub 热门技能
- 分析能力缺口并匹配候选项目
- 自动评分筛选（≥7分自动吞噬）
- 沙盒安全验证
- 能力DNA提取与编码
- 生成OpenClaw标准技能
- 部署注册到能力库
- 持续观察、价值评估与自动淘汰

## 核心特性

### 完整15步MSOP流程
```
① SCAN → ② GAP_ANALYSIS → ③ TARGET_SELECTION → ④ EVALUATION 
→ ⑤ APPROVAL(Anti-Poison) → ⑥ FETCH → ⑦ SANDBOX_TEST 
→ ⑧ CAPABILITY_EXTRACTION → ⑨ DNA_ENCODING → ⑩ COMPOSITION 
→ ⑪ SKILL_GENERATION → ⑫ DEPLOY → ⑬ OBSERVE → ⑭ VALUE_UPDATE → ⑮ RETIRE_CHECK
```

### 三大进化模式
| 模式 | 扫描间隔 | 自动通过 | 风险容忍 | 场景 |
|------|---------|---------|---------|------|
| `safe` | 48h | ≥8 | 极低 | 生产环境 |
| `balanced` | 24h | ≥7 | 中等 | 日常使用 |
| `aggressive` | 12h | ≥6 | 高 | 快速扩张 |

### 评分公式 (MSOP)
```
Score = Innovation×0.35 + Integration×0.25 + GapMatch×0.2 + Popularity×0.1 - Risk×0.3
```

### 淘汰规则
满足**全部条件**时自动淘汰：
- `value_score < 3`
- `usage_count < 5`
- `success_rate < 60%`

## 使用方法

### 1. 快速启动（完整MSOP周期）
```bash
cd skills/auto-evolution
node msop-runner.js --dry-run  # 预览模式，不实际修改
node msop-runner.js           # 完整运行
```

### 2. 查看能力库
```bash
node evolution-controller.js status
```

### 3. 执行特定步骤
```bash
node prey-scanner.js        # 猎物扫描
node gap-seeker.js          # 缺口分析
node sandbox-tester.js      # 沙盒测试
node evolution-controller.js retire-check  # 淘汰检查
node evolution-controller.js reflect       # 自我反思
```

## 目录结构
```
auto-evolution/
├── SKILL.md                  # 本文件
├── LICENSE                   # MIT许可
├── msop-runner.js           # 主运行器（推荐入口）
├── evolution-controller.js  # 状态管理与能力库
├── prey-scanner.js          # GitHub/ClawHub扫描
├── gap-seeker.js            # 能力缺口分析
├── approval.js              # Anti-Poison审批模块
├── sandbox-tester.js        # 沙盒安全验证
├── skill-generator.js       # 标准技能生成
├── deploy.js                # 部署到OpenClaw
├── self-reflection.js       # 自我反思
├── capability-genome.md     # 能力DNA图谱
├── capability-registry.json # 能力注册表（自动生成）
├── msop-state.json          # 进化状态（自动生成）
├── candidates/              # 候选项目扫描结果
│   └── latest-candidates.json
├── skills/                  # 生成的技能
│   ├── agency-multi-agent/
│   ├── playwright-browser/
│   ├── rag/
│   └── ...
└── sandbox/                 # 沙盒测试区
```

## 配置

在各模块中修改 `CONFIG` 常量调整：
- `scan_interval` - 扫描间隔（秒）
- `max_repo_per_cycle` - 每轮最多处理候选数
- `auto_approve_threshold` - 自动通过阈值（默认7）
- `retention_days` - 能力保留天数（默认30）
- `evolution_mode` - 进化模式（safe/balanced/aggressive）

## 安全机制

- 🔒 Anti-Poison检测 - 恶意代码模式识别
- 🧪 沙盒隔离验证 - 静态分析+动态验证
- 📋 审批路由 - ≥7分自动通过，<7需人工，<5丢弃
- ⏱️ 超时保护 - 所有操作带超时
- 📝 审计日志 - 完整操作记录

## 数据文件（自动生成，无隐私）
- `capability-registry.json` - 能力库
- `msop-state.json` - 进化状态
- `observation-log.json` - 运行观察
- `candidates/*.json` - 候选结果
