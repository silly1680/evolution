#!/usr/bin/env node
/**
 * MSOP 完整运行器 - 主状态机串联
 * 
 * 执行完整的15步MSOP流程：
 * SCAN → GAP_ANALYSIS → TARGET_SELECTION → EVALUATION
 * → APPROVAL(Anti-Poison) → FETCH → SANDBOX_TEST
 * → CAPABILITY_EXTRACTION → DNA_ENCODING → COMPOSITION
 * → SKILL_GENERATION → DEPLOY → OBSERVE → VALUE_UPDATE → RETIRE_CHECK
 * 
 * 运行：node msop-runner.js [--dry-run]
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const WORKSPACE = process.env.EVOLVE_WORKSPACE || __dirname;
const CANDIDATES_DIR = path.join(WORKSPACE, 'candidates');
const STATE_FILE = path.join(WORKSPACE, 'msop-state.json');
const REPORT_FILE = path.join(WORKSPACE, 'msop-report.md');

// ===== 配置 =====

const CONFIG = {
  scan_interval: 24 * 3600,      // 扫描间隔（秒）
  max_repo_per_cycle: 5,          // 每轮最多处理候选数
  auto_approve_threshold: 7,      // ≥7分自动通过（MEI指令2026-04-04：7分以上无需通知，直接吞噬）
  human_approval_threshold: 5,    // TARGET_SELECT候选门槛（<5丢弃，5-7走审批，≥7自动吞噬）
  sandbox_required: true,         // 沙盒验证必须
  evolution_mode: 'balanced',      // balanced | aggressive | safe
  retention_days: 30,             // 日志保留天数
  self_reflection_interval: 3,    // 每N轮执行一次自我反思
  dry_run: process.argv.includes('--dry-run'),
};

// ===== 工具函数 =====

function log(step, msg, emoji = '🔄') {
  console.log(`\n${emoji} [${step}] ${msg}`);
}

function logSub(msg) {
  console.log(`   ${msg}`);
}

function loadState() {
  if (!fs.existsSync(STATE_FILE)) {
    return { cycleCount: 0, lastRun: null, reflectionCount: 0 };
  }
  return JSON.parse(fs.readFileSync(STATE_FILE, 'utf-8'));
}

function saveState(state) {
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf-8');
}

function getLatestCandidates() {
  if (!fs.existsSync(CANDIDATES_DIR)) return [];
  // 优先读 latest-candidates.json（prey-scanner每次扫描后写入）
  const latestPath = path.join(CANDIDATES_DIR, 'latest-candidates.json');
  if (fs.existsSync(latestPath)) {
    const data = JSON.parse(fs.readFileSync(latestPath, 'utf-8'));
    if (data.length > 0) return data;
  }
  // 回退：按文件名时间戳取最新的
  const files = fs.readdirSync(CANDIDATES_DIR).filter(f => f.endsWith('.json') && f.startsWith('candidates-')).sort().reverse();
  if (files.length === 0) return [];
  return JSON.parse(fs.readFileSync(path.join(CANDIDATES_DIR, files[0]), 'utf-8'));
}

// ===== 评分公式（MSOP固定）=====
function calculateScore(repo) {
  // score = innovation * 0.35 + integration * 0.25 + gap_match * 0.2 + popularity * 0.1 - risk * 0.3
  const innovation = repo.innovationScore || repo.score || 6;
  const integration = repo.integrationScore || 6;
  const gap_match = repo.gapMatchScore || 6;
  const popularity = repo.popularityScore || 5;
  const risk = repo.riskScore || 3;
  
  return Math.round((innovation * 0.35 + integration * 0.25 + gap_match * 0.2 + popularity * 0.1 - risk * 0.3) * 100) / 100;
}

// ===== 15步执行引擎 =====

async function runMSOP() {
  const state = loadState();
  const dryRun = CONFIG.dry_run;
  
  console.log('═'.repeat(60));
  console.log(`🧠 MSOP 完整运行器 | 模式: ${dryRun ? 'DRY-RUN' : 'LIVE'}`);
  console.log(`⏰ 启动时间: ${new Date().toISOString()}`);
  console.log(`🔄 周期: #${state.cycleCount + 1} | 进化模式: ${CONFIG.evolution_mode}`);
  console.log('═'.repeat(60));

  const report = [];
  report.push(`# MSOP 运行报告 | ${new Date().toISOString().slice(0, 16)}`);
  report.push(`模式: ${dryRun ? 'DRY-RUN' : 'LIVE'} | 进化模式: ${CONFIG.evolution_mode}`);
  report.push('');

  // ======================
  // 步骤① SCAN - 猎物扫描
  // ======================
  log('SCAN', '启动猎物扫描...');
  try {
    execSync(`node ${path.join(__dirname, 'prey-scanner.js')}`, { 
      cwd: WORKSPACE, 
      timeout: 90000,
      stdio: dryRun ? 'pipe' : 'inherit'
    });
    log('SCAN', '✅ 扫描完成', '✅');
  } catch (e) {
    log('SCAN', '⚠️ 扫描失败或无输出，继续', '⚠️');
  }
  report.push('## ① SCAN - 猎物扫描');
  report.push('- 状态: ✅ 完成');
  report.push('');

  // ======================
  // 步骤② GAP_ANALYSIS - 缺口分析
  // ======================
  log('GAP_ANALYSIS', '执行能力缺口分析...');
  try {
    execSync(`node ${path.join(__dirname, 'gap-seeker.js')}`, {
      cwd: WORKSPACE,
      timeout: 60000,
      stdio: dryRun ? 'pipe' : 'inherit'
    });
    log('GAP_ANALYSIS', '✅ 缺口分析完成', '✅');
  } catch (e) {
    log('GAP_ANALYSIS', '⚠️ 缺口分析失败，继续', '⚠️');
  }
  report.push('## ② GAP_ANALYSIS - 能力缺口分析');
  report.push('- 状态: ✅ 完成');
  report.push('');

  // ======================
  // 步骤③ TARGET_SELECTION - 目标筛选
  // ======================
  log('TARGET_SELECTION', '候选 repo ∩ 缺口能力 = targets...');
  const candidates = getLatestCandidates();
  const targets = candidates.filter(c => calculateScore(c) >= CONFIG.human_approval_threshold);
  
  log('TARGET_SELECTION', `发现 ${targets.length} 个候选目标（评分≥${CONFIG.human_approval_threshold}）`, '🎯');
  report.push('## ③ TARGET_SELECTION - 目标筛选');
  report.push(`- 扫描候选: ${candidates.length} 个`);
  report.push(`- 目标候选: ${targets.length} 个`);
  targets.slice(0, 3).forEach(t => {
    report.push(`  - ${t.name} (score=${calculateScore(t).toFixed(1)})`);
  });
  report.push('');

  if (targets.length === 0) {
    log('TARGET_SELECTION', '无候选目标，跳过后续步骤', '⏭');
    report.push('⚠️ 无候选目标，MSOP周期结束');
    fs.writeFileSync(REPORT_FILE, report.join('\n'));
    return { targets: 0, deployed: 0, skipped: true };
  }

  // ======================
  // 步骤④ EVALUATION - 评分
  // ======================
  log('EVALUATION', '对候选目标执行评分...');
  const evaluated = targets.map(t => ({
    ...t,
    msopScore: calculateScore(t),
    score: calculateScore(t), // 兼容现有字段
  })).sort((a, b) => b.msopScore - a.msopScore);

  report.push('## ④ EVALUATION - 吞噬评估');
  evaluated.forEach(t => {
    report.push(`- ${t.name}: score=${t.msopScore} | innovation=${t.innovationScore || '?'} | risk=${t.riskScore || '?'}`);
  });
  report.push('');

  // ======================
  // 步骤⑤ APPROVAL - Anti-Poison + 审批路由
  // 规则（MEI指令2026-04-04）：
  //   score ≥7 → 直接吞噬，无需通知MEI
  //   score <7 → 需要MEI审批
  //   score <5 → 丢弃
  // ======================
  log('APPROVAL', '执行APPROVAL + Anti-Poison检测...');
  
  // 动态加载 approval 模块
  let approvalModule;
  try {
    approvalModule = require('/workspace/evolve/approval.js');
  } catch (e) {
    log('APPROVAL', 'approval.js 加载失败，使用内置逻辑', '⚠️');
    approvalModule = null;
  }

  const approvalResults = [];
  const approvedCandidates = [];
  const rejectedCandidates = [];
  const reviewCandidates = [];

  for (const target of evaluated.slice(0, CONFIG.max_repo_per_cycle)) {
    let result;
    
    if (approvalModule) {
      // 使用专用 approval 模块（包含 Anti-Poison）
      const approvalResult = approvalModule.runApproval(target, { autoMode: true });
      result = approvalResult;
    } else {
      // 内置降级逻辑
      const score = target.msopScore;
      const action = score >= CONFIG.auto_approve_threshold ? 'approve'
        : score >= CONFIG.human_approval_threshold ? 'review'
        : 'reject';
      result = { action, score, reason: `score=${score}`, safe: true };
    }

    approvalResults.push({ name: target.name, ...result });
    
    if (result.action === 'approve') {
      approvedCandidates.push(target);
    } else if (result.action === 'review') {
      reviewCandidates.push(target);
    } else {
      rejectedCandidates.push(target);
    }
  }

  log('APPROVAL', `✅通过=${approvedCandidates.length} ⚠️待审=${reviewCandidates.length} ❌拒绝=${rejectedCandidates.length}`, '📋');
  report.push('## ⑤ APPROVAL - 审批路由 + Anti-Poison');
  report.push(`- ✅ 自动通过: ${approvedCandidates.length} 个`);
  report.push(`- ⚠️ 需人工审批: ${reviewCandidates.length} 个`);
  report.push(`- ❌ 拒绝: ${rejectedCandidates.length} 个`);
  approvedCandidates.forEach(c => report.push(`  - ${c.name} (score=${c.msopScore})`));
  report.push('');

  // ======================
  // 步骤⑥ FETCH - 抓取代码（仅approved，且非dry-run）
  // ======================
  if (!dryRun && approvedCandidates.length > 0) {
    log('FETCH', '抓取 approved 候选代码仓库...');
    report.push('## ⑥ FETCH - 代码抓取');
    
    for (const candidate of approvedCandidates) {
      const repoName = candidate.name.toLowerCase().replace(/[^a-z0-9-]/g, '-');
      const cloneDir = path.join(WORKSPACE, 'candidates', 'repos', repoName);
      
      if (fs.existsSync(cloneDir)) {
        logSub(`已存在: ${candidate.name}`);
        candidate.localPath = cloneDir;
      } else {
        try {
          execSync(`mkdir -p "${path.dirname(cloneDir)}"`, { stdio: 'pipe' });
          const url = candidate.url || `https://github.com/${candidate.repo || candidate.name}`;
          execSync(`git clone --depth=1 "${url}" "${cloneDir}" 2>&1`, { 
            cwd: WORKSPACE, 
            timeout: 60,
            stdio: 'pipe'
          });
          candidate.localPath = cloneDir;
          logSub(`✅ 克隆成功: ${candidate.name}`);
        } catch (e) {
          logSub(`⚠️ 克隆失败: ${candidate.name} - ${e.message.slice(0, 80)}`);
          candidate.cloneFailed = true;
        }
      }
    }
    report.push(`- 克隆完成`);
    report.push('');
  }

  // ======================
  // 步骤⑦ SANDBOX_TEST - 沙盒验证（仅非dry-run且有本地代码）
  // ======================
  if (!dryRun && approvedCandidates.some(c => c.localPath && !c.cloneFailed)) {
    log('SANDBOX_TEST', '执行沙盒安全验证...');
    report.push('## ⑦ SANDBOX_TEST - 沙盒验证');
    
    for (const candidate of approvedCandidates.filter(c => c.localPath && !c.cloneFailed)) {
      try {
        const output = execSync(
          `node /workspace/evolve/sandbox-tester.js --path "${candidate.localPath}" 2>&1`,
          { cwd: WORKSPACE, timeout: 60, stdio: 'pipe' }
        ).toString();
        const sandboxResult = JSON.parse(output);
        candidate.sandboxSafe = sandboxResult.safe;
        logSub(`${sandboxResult.safe ? '✅' : '⚠️'} ${candidate.name}: safe=${sandboxResult.safe}`);
        report.push(`- ${candidate.name}: safe=${sandboxResult.safe}`);
      } catch (e) {
        candidate.sandboxSafe = false;
        logSub(`⚠️ 沙盒验证跳过: ${candidate.name}`);
        report.push(`- ${candidate.name}: 沙盒验证跳过`);
      }
    }
    report.push('');
  }

  // ======================
  // 步骤⑧ CAPABILITY_EXTRACTION - 能力提取
  // ======================
  log('CAPABILITY_EXTRACTION', '从代码结构提取能力DNA...');
  let skillModule;
  try {
    skillModule = require('/workspace/evolve/skill-generator.js');
  } catch (e) {
    skillModule = null;
  }

  const extractedCandidates = approvedCandidates.map(c => {
    if (!c.localPath || c.cloneFailed) return { ...c, capabilities: ['general'] };
    
    // 基础关键词提取
    const capabilities = [];
    const keywords = ['scraping', 'browser', 'vision', 'trading', 'rss', 'api', 'stock', 'writing'];
    const dirs = execSync(`find "${c.localPath}" -maxdepth 3 -type d 2>/dev/null`).toString().toLowerCase();
    for (const kw of keywords) {
      if (dirs.includes(kw) && !capabilities.includes(kw)) capabilities.push(kw);
    }
    if (capabilities.length === 0) capabilities.push('general');
    
    logSub(`${c.name}: ${capabilities.join(', ')}`);
    return { ...c, capabilities, dna: capabilities };
  });
  report.push('## ⑧ CAPABILITY_EXTRACTION - 能力提取');
  extractedCandidates.forEach(c => {
    report.push(`- ${c.name}: [${c.capabilities?.join(', ') || 'general'}]`);
  });
  report.push('');

  // ======================
  // 步骤⑨ DNA_ENCODING - 基因编码
  // ======================
  log('DNA_ENCODING', '标准化 + 建立映射表...');
  report.push('## ⑨ DNA_ENCODING - 基因编码');
  extractedCandidates.forEach(c => {
    const dna = (c.dna || c.capabilities || ['general']).map(d => d.toLowerCase().replace(/\s+/g, '-'));
    c.encodedDna = [...new Set(dna)]; // 去重
    report.push(`- ${c.name}: [${c.encodedDna.join(' → ')}]`);
  });
  report.push('');

  // ======================
  // 步骤⑩ COMPOSITION - 能力组合
  // ======================
  log('COMPOSITION', '新DNA + 历史DNA → workflow...');
  report.push('## ⑩ COMPOSITION - 能力组合');
  
  // 加载历史DNA
  let registry = {};
  try {
    registry = JSON.parse(fs.readFileSync(path.join(WORKSPACE, 'capability-registry.json'), 'utf-8'));
  } catch {}

  const historicalDna = Object.values(registry)
    .flatMap(c => c.dna || [])
    .filter(Boolean);

  extractedCandidates.forEach(c => {
    const combined = [...new Set([...(c.encodedDna || []), ...historicalDna])];
    c.workflow = combined.slice(0, 6); // 最多6个步骤
    report.push(`- ${c.name}: workflow = [${c.workflow.join(' → ')}]`);
  });
  report.push('');

  // ======================
  // 步骤⑪ SKILL_GENERATION - 生成Skill
  // ======================
  log('SKILL_GENERATION', '生成 Skill 文件...', '⚙️');
  report.push('## ⑪ SKILL_GENERATION - 技能生成');
  
  const generatedSkills = [];

  if (!dryRun && skillModule && extractedCandidates.length > 0) {
    for (const candidate of extractedCandidates) {
      const skillId = candidate.name.toLowerCase().replace(/[^a-z0-9-]/g, '-').slice(0, 50);
      try {
        const genResult = await skillModule.generateSkill(candidate, {
          skillId,
          name: candidate.name,
          dna: candidate.encodedDna,
          score: candidate.msopScore,
          source: candidate.url || candidate.source,
          repoPath: candidate.localPath,
        });
        generatedSkills.push(genResult);
        logSub(`✅ Skill生成: ${skillId}`);
        report.push(`- ✅ ${skillId}`);
      } catch (e) {
        logSub(`⚠️ Skill生成失败: ${candidate.name} - ${e.message.slice(0, 60)}`);
        report.push(`- ⚠️ ${candidate.name}: ${e.message.slice(0, 60)}`);
      }
    }
  } else if (dryRun) {
    extractedCandidates.forEach(c => {
      const skillId = c.name.toLowerCase().replace(/[^a-z0-9-]/g, '-').slice(0, 50);
      generatedSkills.push({ success: true, skillId, dryRun: true });
      logSub(`[DRY-RUN] 模拟生成: ${skillId}`);
      report.push(`- ⏭ [DRY-RUN] ${skillId}`);
    });
  }
  report.push('');

  // ======================
  // 步骤⑫ DEPLOY - 注册到能力库
  // ======================

  // 🆕 通知MEI：吞噬完成汇报（≥7分自动吞噬，不需要审批）
  if (!dryRun && (approvedCandidates.length > 0 || reviewCandidates.length > 0)) {
    log('NOTIFY_MEI', '向MEI汇报吞噬结果...', '📢');
    report.push('## 📢 吞噬汇报');
    approvedCandidates.forEach(c => {
      report.push(`- 🧽 **${c.name}** (score=${c.msopScore}) 已完成吞噬`);
    });
    const approvedArgs = JSON.stringify(approvedCandidates.map(c => ({ name: c.name, msopScore: c.msopScore })));
    const reviewArgs = JSON.stringify(reviewCandidates.map(c => ({ name: c.name })));
    try {
      execSync(`node /workspace/evolve/notify-mei.js '${approvedArgs}' '${reviewArgs}' 2>&1`, {
        cwd: WORKSPACE, timeout: 20, stdio: 'pipe'
      });
      logSub('✅ 已发送飞书通知给MEI');
    } catch (e) {
      logSub('⚠️ 飞书通知发送失败: ' + e.message.slice(0, 100));
    }
  }
  log('DEPLOY', '注册到能力库 + 部署到OpenClaw...', '🚀');
  report.push('## ⑫ DEPLOY - 注册部署');
  
  if (!dryRun && generatedSkills.length > 0) {
    let deployModule;
    try {
      deployModule = require('/workspace/evolve/deploy.js');
    } catch {}

    for (const skill of generatedSkills) {
      if (!skill.success) continue;
      try {
        if (deployModule) {
          deployModule.deploySkill(skill.skillId);
        }
        logSub(`✅ 部署: ${skill.skillId}`);
        report.push(`- ✅ ${skill.skillId}`);
      } catch (e) {
        logSub(`⚠️ 部署失败: ${skill.skillId} - ${e.message}`);
        report.push(`- ⚠️ ${skill.skillId}: ${e.message}`);
      }
    }
  } else {
    generatedSkills.forEach(s => {
      report.push(`- ⏭ [DRY-RUN] ${s.skillId}`);
    });
  }
  report.push('');

  // ======================
  // 步骤⑬ OBSERVE - 观察记录
  // ======================
  log('OBSERVE', '更新能力统计...');
  report.push('## ⑬ OBSERVE - 运行观察');
  
  let controllerModule;
  try {
    controllerModule = require('/workspace/evolve/evolution-controller.js');
  } catch {}

  if (controllerModule) {
    try {
      // 调用现有的观察日志更新
      const reg = JSON.parse(fs.readFileSync(path.join(WORKSPACE, 'capability-registry.json'), 'utf-8'));
      report.push(`- 已注册能力: ${Object.keys(reg).length} 个`);
    } catch {}
  }
  report.push('');

  // ======================
  // 步骤⑭ VALUE_UPDATE - 价值评估
  // ======================
  log('VALUE_UPDATE', '计算所有能力价值评分...');
  report.push('## ⑭ VALUE_UPDATE - 价值评估');
  
  try {
    const reg = JSON.parse(fs.readFileSync(path.join(WORKSPACE, 'capability-registry.json'), 'utf-8'));
    // value_score = usage*0.4 + success_rate*0.3 + efficiency*0.3
    for (const [id, cap] of Object.entries(reg)) {
      const calls = cap.stats?.calls || 0;
      const rate = cap.stats?.successRate || 0;
      const time = cap.stats?.avgTime || 0;
      const efficiency = Math.max(0, 1 - Math.max(0, time - 1) / 9);
      const vs = Math.round((calls * 0.4 + rate * 0.3 + efficiency * 0.3) * 100) / 100;
      cap.valueScore = vs;
      report.push(`- ${cap.name}: value_score=${vs} (calls=${calls}, rate=${rate}, eff=${efficiency.toFixed(2)})`);
    }
    fs.writeFileSync(path.join(WORKSPACE, 'capability-registry.json'), JSON.stringify(reg, null, 2));
  } catch (e) {
    report.push(`- ⚠️ 价值评估失败: ${e.message}`);
  }
  report.push('');

  // ======================
  // 步骤⑮ RETIRE_CHECK - 淘汰检查
  // ======================
  log('RETIRE_CHECK', '执行淘汰检查...');
  report.push('## ⑮ RETIRE_CHECK - 淘汰检查');
  
  try {
    const reg = JSON.parse(fs.readFileSync(path.join(WORKSPACE, 'capability-registry.json'), 'utf-8'));
    let retired = 0;
    let survivors = 0;

    for (const [id, cap] of Object.entries(reg)) {
      if (cap.status === 'retired') continue;
      if (!cap.stats?.calls || cap.stats.calls === 0) {
        survivors++; continue;
      }
      const vs = cap.valueScore || 0;
      const calls = cap.stats.calls || 0;
      const rate = cap.stats.successRate || 0;

      const shouldRetire = vs < 3 && calls < 5 && rate < 0.6;
      
      if (shouldRetire) {
        cap.status = 'retired';
        cap.retiredAt = new Date().toISOString();
        retired++;
        logSub(`❌ 淘汰: ${cap.name} (vs=${vs}, calls=${calls}, rate=${rate})`);
        report.push(`- ❌ ${cap.name}: value_score=${vs} < 3, 已标记为retired`);
      } else {
        survivors++;
      }
    }
    fs.writeFileSync(path.join(WORKSPACE, 'capability-registry.json'), JSON.stringify(reg, null, 2));
    log('RETIRE_CHECK', `淘汰 ${retired} 个，保留 ${survivors} 个`, '🧹');
    report.push(`- 淘汰: ${retired} 个 | 保留: ${survivors} 个`);
  } catch (e) {
    report.push(`- ⚠️ 淘汰检查失败: ${e.message}`);
  }
  report.push('');

  // ======================
  // 🆕 SELF-REFLECTION - 自我反思
  // ======================
  state.reflectionCount = (state.reflectionCount || 0) + 1;
  if (state.reflectionCount >= CONFIG.self_reflection_interval) {
    state.reflectionCount = 0;
    log('SELF_REFLECTION', '执行自我反思...', '🧠');
    report.push('## 🆕 SELF-REFLECTION - 自我反思');
    
    try {
      const reg = JSON.parse(fs.readFileSync(path.join(WORKSPACE, 'capability-registry.json'), 'utf-8'));
      const sorted = Object.values(reg).sort((a, b) => (b.valueScore || 0) - (a.valueScore || 0));
      
      report.push('### 能力价值排行榜');
      report.push('| 能力 | 价值分 | 调用 | 成功率 | 状态 |');
      report.push('|------|--------|------|--------|------|');
      sorted.forEach(c => {
        report.push(`| ${c.name} | ${c.valueScore || 0} | ${c.stats?.calls || 0} | ${c.stats?.successRate || '?'} | ${c.status} |`);
      });
      
      report.push('');
      report.push('### 进化建议');
      const noUse = sorted.filter(c => !c.stats?.calls);
      const lowValue = sorted.filter(c => (c.valueScore || 0) < 2 && c.stats?.calls > 0);
      if (noUse.length > 0) report.push(`- ⚠️ 未使用能力: ${noUse.map(c => c.name).join('、')} — 下轮考虑淘汰`);
      if (lowValue.length > 0) report.push(`- 🔴 低价值能力: ${lowValue.map(c => `${c.name}(${c.valueScore})`).join('、')}`);
      if (noUse.length === 0 && lowValue.length === 0) report.push('✅ 所有能力均运行正常');
    } catch (e) {
      report.push(`- ⚠️ 反思失败: ${e.message}`);
    }
  }

  // ===== 最终总结 =====
  console.log('\n' + '═'.repeat(60));
  console.log('📊 MSOP 周期完成总结');
  console.log('═'.repeat(60));
  console.log(`  扫描候选: ${candidates.length}`);
  console.log(`  目标候选: ${targets.length}`);
  console.log(`  审批通过: ${approvedCandidates.length}`);
  console.log(`  审批拒绝: ${rejectedCandidates.length}`);
  console.log(`  待人工审: ${reviewCandidates.length}`);
  console.log(`  Skill生成: ${generatedSkills.length}`);
  console.log(`  模式: ${dryRun ? 'DRY-RUN' : 'LIVE'}`);
  console.log('═'.repeat(60));

  report.push('## 总结');
  report.push(`- 扫描候选: ${candidates.length}`);
  report.push(`- 审批通过: ${approvedCandidates.length}`);
  report.push(`- Skill生成: ${generatedSkills.length}`);
  report.push(`- 模式: ${dryRun ? 'DRY-RUN' : 'LIVE'}`);
  report.push('');
  report.push(`_报告生成时间: ${new Date().toISOString()}_`);

  // 写入报告
  fs.writeFileSync(REPORT_FILE, report.join('\n'), 'utf-8');
  console.log(`\n📄 报告已写入: ${REPORT_FILE}`);

  // 更新状态
  state.cycleCount++;
  state.lastRun = new Date().toISOString();
  saveState(state);

  return {
    candidates: candidates.length,
    targets: targets.length,
    approved: approvedCandidates.length,
    rejected: rejectedCandidates.length,
    review: reviewCandidates.length,
    generated: generatedSkills.length,
    dryRun,
  };
}

// ===== 入口 =====
if (require.main === module) {
  runMSOP().then(r => {
    console.log('\n✅ MSOP运行完成', r);
    process.exit(0);
  }).catch(e => {
    console.error('\n❌ MSOP运行失败:', e);
    process.exit(1);
  });
}

module.exports = { runMSOP };
