#!/usr/bin/env node
/**
 * 沙盒验证器 - SANDBOX_TEST
 * 
 * 职责：
 * ① 隔离测试候选能力的真实行为
 * ② 检测：网络行为、文件访问、CPU/内存异常、欺骗行为
 * ③ 输出：safe + test_passed 双布尔结果
 * 
 * 安全边界：
 * - 只在 /workspace/evolve/sandbox/ 内操作
 * - 不执行 rm -rf / 或类似危险命令
 * - 不访问 ~/.ssh /etc/secrets 等敏感路径
 * - 超时保护：每个测试最多60秒
 */

const fs = require('fs');
const path = require('path');
const { execSync, spawn } = require('child_process');

const SANDBOX_DIR = '/workspace/evolve/sandbox';
const REPORT_FILE = '/workspace/evolve/sandbox-test-report.json';

if (!fs.existsSync(SANDBOX_DIR)) {
  fs.mkdirSync(SANDBOX_DIR, { recursive: true });
}

// ===== 危险行为检测规则 =====
const DANGEROUS_PATTERNS = [
  // 文件系统危险操作
  { pattern: /rm\s+-[rf]+\s+\/(?!\s)|rm\s+-[rf]+\s+\*|del\s+\/[sf]\s/i, risk: 'HIGH', note: '试图删除系统文件' },
  { pattern: /chmod\s+777\s+\/|wget.*\|.*sh|curl.*\|.*sh/i, risk: 'HIGH', note: '远程代码执行' },
  { pattern: /eval\s*\(\s*process\.env|exec\s*\(\s*process\.env/i, risk: 'HIGH', note: '环境变量注入' },
  // 网络行为检测（可配置）
  { pattern: /http:\/\/localhost|http:\/\/127\.0\.0\.1/i, risk: 'LOW', note: '访问本地服务（非危险）' },
  // 加密货币/挖矿
  { pattern: /cryptojacking|coinbase|xmrig|mining|miner/i, risk: 'HIGH', note: '挖矿行为' },
  // 键盘记录/后门
  { pattern: /keylogger|keylog|record.*key/i, risk: 'HIGH', note: '键盘记录' },
];

// ===== 网络行为白名单（安全目的地）====
const SAFE_DOMAINS = [
  'api.github.com', 'github.com',           // GitHub
  'pypi.org', 'pip install',                 // Python包
  'npmjs.com', 'registry.npmjs.org',         // npm
  'clawhub.com', 'www.clawhub.com',          // Clawhub
  'eastmoney.com', 'push2.eastmoney.com',    // 东方财富（金融数据）
  'qq.com', '.weixin.qq.com',               // 腾讯（微信）
  'feishu.cn', 'open.feishu.cn',            // 飞书
];

const SUSPICIOUS_DOMAINS = [
  'pastebin.com', 'throwaway', 'anonfile',  // 数据外泄风险
  'crypto', 'mining', 'darkweb',            // 加密货币/黑市
];

// ===== 静态分析：检测危险模式 =====
function staticAnalysis(fileContent, filePath) {
  const findings = [];
  const ext = path.extname(filePath).toLowerCase();

  for (const rule of DANGEROUS_PATTERNS) {
    if (rule.pattern.test(fileContent)) {
      findings.push({ risk: rule.risk, type: 'pattern', note: rule.note, matched: fileContent.match(rule.pattern)?.[0] });
    }
  }

  // Python: 检测 __import__('os').system 等危险调用
  if (ext === '.py') {
    const pyDangerous = [
      { pattern: /__import__\s*\(\s*['"]os['"]\s*\)/, note: '动态导入os模块' },
      { pattern: /__import__\s*\(\s*['"]subprocess['"]\s*\)/, note: '动态导入subprocess' },
      { pattern: /eval\s*\(/, note: '使用eval()' },
      { pattern: /exec\s*\(\s*(?!import)/, note: '使用exec()' },
      { pattern: /open\s*\([^)]*['"]w['"]/, note: '写文件操作（需确认路径）' },
      { pattern: /subprocess\.run\s*\(\s*\[.*\]\s*,\s*shell\s*=\s*True/, note: 'shell=True命令执行' },
    ];
    for (const rule of pyDangerous) {
      if (rule.pattern.test(fileContent)) {
        findings.push({ risk: 'MEDIUM', type: 'python', note: rule.note, matched: fileContent.match(rule.pattern)?.[0] });
      }
    }
  }

  // Node.js: 检测 child_process.exec 等
  if (ext === '.js' || ext === '.ts') {
    const jsDangerous = [
      { pattern: /child_process\.exec\s*\(/, note: 'child_process.exec调用' },
      { pattern: /eval\s*\(/, note: '使用eval()' },
      { pattern: /process\.exit\s*\(/, note: '强制退出进程' },
      { pattern: /\.env.*=.*process\.env/, note: '读取环境变量（需确认用途）' },
    ];
    for (const rule of jsDangerous) {
      if (rule.pattern.test(fileContent)) {
        findings.push({ risk: 'MEDIUM', type: 'javascript', note: rule.note, matched: fileContent.match(rule.pattern)?.[0] });
      }
    }
  }

  return findings;
}

// ===== 克隆仓库到沙盒 =====
function cloneToSandbox(repoUrl, targetDir) {
  const fullPath = path.join(SANDBOX_DIR, targetDir);
  if (fs.existsSync(fullPath)) {
    fs.rmSync(fullPath, { recursive: true, force: true });
  }
  try {
    execSync(`git clone --depth=1 ${repoUrl} ${fullPath}`, { timeout: 60, stdio: 'pipe' });
    return { success: true, path: fullPath };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

// ===== 依赖分析 =====
function analyzeDependencies(sandboxPath) {
  const deps = [];
  const checks = [
    { file: 'requirements.txt', type: 'pip' },
    { file: 'pyproject.toml', type: 'python' },
    { file: 'package.json', type: 'npm' },
    { file: 'setup.py', type: 'python' },
    { file: 'Dockerfile', type: 'docker' },
  ];
  
  for (const check of checks) {
    const fp = path.join(sandboxPath, check.file);
    if (fs.existsSync(fp)) {
      const content = fs.readFileSync(fp, 'utf-8');
      deps.push({ file: check.file, type: check.type, size: content.length });
    }
  }
  return deps;
}

// ===== Python脚本安全测试 =====
function testPythonScript(scriptPath) {
  const results = { safe: false, test_passed: false, issues: [], networkCalls: [] };
  
  // 1. 静态分析
  const content = fs.readFileSync(scriptPath, 'utf-8');
  results.issues = staticAnalysis(content, scriptPath);
  
  // 检查是否有网络请求代码（requests, urllib, httpx等）
  const hasNetworkLib = /^(import|from)\s+(requests|urllib|httpx|aiohttp|curlpy)/m.test(content);
  results.hasNetworkCode = hasNetworkLib;
  
  // 2. 资源占用测试（小规模）
  const testCode = `
import sys, time, traceback
sys.path.insert(0, '${path.dirname(scriptPath)}')
script_name = '${path.basename(scriptPath)}'
module_name = script_name.replace('.py', '')
try:
    import importlib.util
    spec = importlib.util.spec_from_file_location(module_name, '${scriptPath}')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    print('TEST_PASSED')
except Exception as e:
    print(f'TEST_ERROR:{e.__class__.__name__}:{e}')
`;
  
  try {
    const output = execSync(`cd /workspace/evolve/sandbox && timeout 20 /workspace/evolve/venv/bin/python -c "${testCode.replace(/"/g, '\\"').replace(/\n/g, '; ')}" 2>&1`, { timeout: 25, encoding: 'utf-8' });
    results.test_passed = output.includes('TEST_PASSED');
    if (output.includes('TEST_ERROR')) {
      results.issues.push({ risk: 'LOW', type: 'runtime', note: '模块加载测试：' + output.split('TEST_ERROR:')[1] });
    }
  } catch (e) {
    const err = e.stdout || e.message || '';
    if (err.includes('TEST_ERROR')) {
      results.issues.push({ risk: 'LOW', type: 'runtime', note: '运行错误：' + err.split('TEST_ERROR:')[1] });
      results.test_passed = false;
    } else {
      results.test_passed = false;
      results.issues.push({ risk: 'LOW', type: 'timeout', note: '执行超时或被拒绝' });
    }
  }

  // 3. 综合判断
  const highRisk = results.issues.filter(i => i.risk === 'HIGH');
  results.safe = highRisk.length === 0;
  
  return results;
}

// ===== Node.js脚本安全测试 =====
function testNodeScript(scriptPath) {
  const results = { safe: false, test_passed: false, issues: [], networkCalls: [] };
  const content = fs.readFileSync(scriptPath, 'utf-8');
  results.issues = staticAnalysis(content, scriptPath);
  
  const hasDangerous = results.issues.some(i => i.risk === 'HIGH');
  results.safe = !hasDangerous;
  
  // 尝试 require 该脚本
  try {
    execSync(`timeout 10 node -e "require('${scriptPath}')" 2>&1`, { timeout: 15, encoding: 'utf-8', cwd: path.dirname(scriptPath) });
    results.test_passed = true;
  } catch (e) {
    // require失败不等于不安全，可能只是没有module.exports
    results.test_passed = !e.message.includes('Error:') || e.status !== 1;
  }
  
  return results;
}

// ===== 主测试流程 =====
function runSandboxTest(repoUrl, repoName) {
  console.log(`[沙盒] 开始测试：${repoName}`);
  const safeName = repoName.toLowerCase().replace(/[^a-z0-9-]/g, '-');
  const result = {
    repo: repoName,
    url: repoUrl,
    timestamp: new Date().toISOString(),
    safe: false,
    test_passed: false,
    issues: [],
    dependencies: [],
    summary: ''
  };

  // 1. 克隆
  console.log('[沙盒] 克隆仓库...');
  const clone = cloneToSandbox(repoUrl, safeName);
  if (!clone.success) {
    result.summary = '克隆失败：' + clone.error;
    return result;
  }

  // 2. 依赖分析
  result.dependencies = analyzeDependencies(clone.path);
  console.log(`[沙盒] 依赖：${result.dependencies.map(d => d.file).join(', ') || '无'}`);

  // 3. 查找主脚本
  const pyFiles = execSync(`find "${clone.path}" -name "*.py" -not -path "*/.*" | head -10`, { encoding: 'utf-8' }).trim().split('\n').filter(Boolean);
  const jsFiles = execSync(`find "${clone.path}" -name "*.js" -not -path "*/.*" | head -10`, { encoding: 'utf-8' }).trim().split('\n').filter(Boolean);

  // 4. 优先测试主入口文件
  const mainFiles = [
    path.join(clone.path, 'main.py'),
    path.join(clone.path, 'run.py'),
    path.join(clone.path, 'cli.py'),
    path.join(clone.path, 'index.js'),
    path.join(clone.path, 'main.js'),
    ...pyFiles.slice(0, 3),
  ].filter(f => fs.existsSync(f));

  let allResults = { safe: true, test_passed: true, issues: [] };
  for (const file of mainFiles) {
    const ext = path.extname(file).toLowerCase();
    const testResult = ext === '.py' ? testPythonScript(file) : testNodeScript(file);
    allResults.issues.push(...testResult.issues);
    if (!testResult.safe) allResults.safe = false;
    if (!testResult.test_passed) allResults.test_passed = false;
  }

  result.safe = allResults.safe;
  result.test_passed = allResults.test_passed;
  result.issues = allResults.issues;
  
  // 5. 判断
  const highRisk = result.issues.filter(i => i.risk === 'HIGH');
  if (highRisk.length > 0) {
    result.summary = `⚠️ 发现高风险：${highRisk.map(i => i.note).join('; ')}`;
  } else if (result.test_passed) {
    result.summary = '✅ 安全，测试通过';
  } else {
    result.summary = '⚠️ 安全但测试未完全通过';
  }

  console.log(`[沙盒] ${result.summary}`);
  
  // 6. 清理沙盒
  fs.rmSync(clone.path, { recursive: true, force: true });

  return result;
}

// ===== CLI入口 =====
function main() {
  const args = process.argv.slice(2);
  
  if (args[0] === 'test' && args[1]) {
    const url = args[1];
    const name = url.split('/').pop().replace('.git', '');
    const result = runSandboxTest(url, name);
    fs.writeFileSync(REPORT_FILE, JSON.stringify(result, null, 2));
    console.log(`\n📋 结果：${result.summary}`);
    console.log(`   safe=${result.safe} | test_passed=${result.test_passed}`);
    console.log(`   详细报告：${REPORT_FILE}`);
    return;
  }

  // 默认：显示帮助
  console.log(`
🧪 沙盒验证器 | MSOP SANDBOX_TEST

用法：
  node sandbox-tester.js test <repo-url>

示例：
  node sandbox-tester.js test https://github.com/akfamily/akshare
  node sandbox-tester.js test https://github.com/microsoft/playwright

检测内容：
  - 静态代码分析（危险函数检测）
  - 资源占用测试（限时运行）
  - 依赖清单分析
  - shell注入检测

输出：
  - 结果打印到stdout
  - 详细报告写入 ${REPORT_FILE}
`);
}

main();
