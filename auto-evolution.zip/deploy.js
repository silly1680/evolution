/**
 * MSOP DEPLOY 模块
 * 职责：
 *  - 将生成的 skill 注册到 OpenClaw 实际 skill registry
 *  - 处理 skill 目录创建、元数据写入
 *  - 发布状态追踪
 */

const fs = require('fs');
const path = require('path');

const WORKSPACE = '/workspace/evolve';
const OPENCLAW_SKILLS_DIR = '/app/openclaw/skills';   // OpenClaw 实际读取位置
const LOCAL_SKILLS_DIR = path.join(WORKSPACE, 'skills'); // 本地MSOP仓库
const DEPLOY_LOG = path.join(WORKSPACE, 'deploy-log.json');
const REGISTRY_FILE = path.join(WORKSPACE, 'capability-registry.json');

// ===== 日志 =====

function loadDeployLog() {
  if (!fs.existsSync(DEPLOY_LOG)) return [];
  return JSON.parse(fs.readFileSync(DEPLOY_LOG, 'utf-8'));
}

function saveDeployLog(log) {
  fs.writeFileSync(DEPLOY_LOG, JSON.stringify(log, null, 2), 'utf-8');
}

function loadRegistry() {
  if (!fs.existsSync(REGISTRY_FILE)) return {};
  return JSON.parse(fs.readFileSync(REGISTRY_FILE, 'utf-8'));
}

// ===== 检测目标部署位置 =====

function detectSkillRegistry() {
  const locations = [
    '/app/openclaw/skills',
    '/workspace/skills',
    '/app/openclaw/extensions/skills',
  ];

  for (const loc of locations) {
    if (fs.existsSync(loc)) {
      return { writable: fs.existsSync(loc) && fs.statSync(loc).isDirectory(), path: loc };
    }
  }

  // 默认回退到 workspace/skills
  if (!fs.existsSync(LOCAL_SKILLS_DIR)) {
    fs.mkdirSync(LOCAL_SKILLS_DIR, { recursive: true });
  }
  return { writable: true, path: LOCAL_SKILLS_DIR, fallback: true };
}

// ===== SKILL.md 格式化（确保符合OpenClaw规范）=====

function formatSkillMd(skillId, meta) {
  const title = meta.name || skillId.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  const description = meta.description || `${title} - MSOP自动生成的OpenClaw技能`;

  return `# ${title}

> **MSOP Skill** | Version: ${meta.version} | Score: ${meta.score}  
> ID: \`${skillId}\` | Source: ${meta.source || 'auto-generated'}  
> Generated: ${new Date().toISOString().slice(0, 10)}

## 描述

${description}

## DNA 能力标签

${(meta.dna || meta.capabilities || []).map(d => `- \`${d}\``).join('\n')}

## 使用场景

${meta.usage || '通过 MSOP 系统自动注册，运行时调用。'}

## 评分信息

| 指标 | 值 |
|------|-----|
| MSOP评分 | ${meta.score || '?'} |
| 进化模式 | ${meta.evolutionMode || 'balanced'} |
| 来源 | ${meta.source || 'unknown'} |

## ⚠️ 注意

本技能由 MSOP SKILL_GENERATION 自动生成。如发现问题请回滚或删除。
`;
}

// ===== DEPLOY 主函数 =====

/**
 * 部署单个 skill 到 OpenClaw registry
 * @param {string} skillId - 技能ID
 * @param {Object} options
 * @returns {Object} 部署结果
 */
function deploySkill(skillId, options = {}) {
  const { force = false } = options;
  
  const registry = loadRegistry();
  const skillMeta = registry[skillId];

  if (!skillMeta && !options.name) {
    return { success: false, reason: `Skill ${skillId} 不存在于 capability-registry` };
  }

  const skillDir = path.join(LOCAL_SKILLS_DIR, skillId);
  const localSkillMd = path.join(skillDir, 'SKILL.md');
  const localMeta = path.join(skillDir, 'meta.json');

  // 确定部署目标
  const target = detectSkillRegistry();
  console.log(`[DEPLOY] 部署目标: ${target.path}${target.fallback ? ' (fallback)' : ''}`);

  if (!target.writable) {
    console.log(`[DEPLOY] ⚠️ 目标目录不可写: ${target.path}`);
    console.log(`[DEPLOY] 将部署到备用位置: ${LOCAL_SKILLS_DIR}`);
  }

  const deployDir = target.writable && !target.fallback ? target.path : LOCAL_SKILLS_DIR;
  const deploySkillDir = path.join(deployDir, skillId);
  const deploySkillMd = path.join(deploySkillDir, 'SKILL.md');
  const deployMeta = path.join(deploySkillDir, 'meta.json');

  // 检查是否已部署
  if (fs.existsSync(deploySkillMd) && !force) {
    console.log(`[DEPLOY] ${skillId} 已存在，使用 --force 强制更新`);
    return {
      success: true,
      skillId,
      action: 'already_deployed',
      path: deploySkillMd,
      message: 'Skill已部署，无需重复操作'
    };
  }

  // 读取本地生成的 skill 内容
  let skillMdContent, metaContent;
  
  if (fs.existsSync(localSkillMd)) {
    skillMdContent = fs.readFileSync(localSkillMd, 'utf-8');
    metaContent = fs.existsSync(localMeta) ? JSON.parse(fs.readFileSync(localMeta, 'utf-8')) : skillMeta;
  } else {
    // 如果本地没有，从 registry 构造
    const meta = skillMeta || options;
    skillMdContent = formatSkillMd(skillId, meta);
    metaContent = { ...meta, skillId, deployedAt: new Date().toISOString() };
  }

  // 创建目标目录
  if (!fs.existsSync(deploySkillDir)) {
    fs.mkdirSync(deploySkillDir, { recursive: true });
  }

  // 写入文件
  fs.writeFileSync(deploySkillMd, skillMdContent, 'utf-8');
  fs.writeFileSync(deployMeta, JSON.stringify(metaContent, null, 2), 'utf-8');

  console.log(`[DEPLOY] ✅ 部署成功: ${skillId}`);
  console.log(`         路径: ${deploySkillMd}`);

  // 更新 registry 中的部署状态
  if (registry[skillId]) {
    registry[skillId].deployedAt = new Date().toISOString();
    registry[skillId].deployedPath = deploySkillMd;
    registry[skillId].status = 'deployed';
    fs.writeFileSync(REGISTRY_FILE, JSON.stringify(registry, null, 2), 'utf-8');
  }

  // 记录部署日志
  const log = loadDeployLog();
  log.unshift({
    skillId,
    deployedAt: new Date().toISOString(),
    deployedPath: deploySkillMd,
    deployDir,
    version: metaContent?.version || '1.0.0',
    source: metaContent?.source || 'local',
    force,
  });
  if (log.length > 200) log.splice(200);
  saveDeployLog(log);

  return {
    success: true,
    skillId,
    deployedPath: deploySkillMd,
    deployDir,
    version: metaContent?.version || '1.0.0',
  };
}

/**
 * 部署所有已生成但未部署的 skills
 */
function deployAllPending() {
  const registry = loadRegistry();
  const pending = Object.values(registry).filter(
    c => c.status !== 'deployed' && c.status !== 'retired'
  );

  console.log(`[DEPLOY] 待部署技能: ${pending.length} 个`);
  
  const results = [];
  for (const skill of pending) {
    const r = deploySkill(skill.id);
    results.push(r);
  }
  
  const summary = {
    total: results.length,
    success: results.filter(r => r.success).length,
    failed: results.filter(r => !r.success).length,
  };
  
  console.log(`\n[DEPLOY SUMMARY] 成功=${summary.success} 失败=${summary.failed}`);
  return { results, summary };
}

/**
 * 列出所有已部署的 skills
 */
function listDeployed() {
  const target = detectSkillRegistry();
  console.log(`\n📦 OpenClaw Skill Registry: ${target.path}`);
  console.log('='.repeat(50));
  
  if (!fs.existsSync(target.path)) {
    console.log('（目录为空）'); return;
  }

  const entries = fs.readdirSync(target.path).filter(
    d => !d.startsWith('.') && fs.statSync(path.join(target.path, d)).isDirectory()
  );

  if (entries.length === 0) {
    console.log('（暂无已部署技能）');
  }

  entries.forEach(skillId => {
    const skillDir = path.join(target.path, skillId);
    const metaPath = path.join(skillDir, 'meta.json');
    const skillMdPath = path.join(skillDir, 'SKILL.md');
    
    let meta = {};
    if (fs.existsSync(metaPath)) {
      try { meta = JSON.parse(fs.readFileSync(metaPath, 'utf-8')); } catch {}
    }
    
    const version = meta.version || '?';
    const name = meta.name || skillId;
    const score = meta.score || '?';
    
    console.log(`  📁 ${skillId}`);
    console.log(`     名称: ${name}`);
    console.log(`     版本: v${version} | 评分: ${score}`);
    if (fs.existsSync(skillMdPath)) {
      console.log(`     ✅ SKILL.md 存在`);
    }
    console.log('');
  });

  console.log(`总计: ${entries.length} 个已部署技能`);
  console.log(`\n本地 MSOP 仓库: ${LOCAL_SKILLS_DIR}`);
  const localEntries = fs.readdirSync(LOCAL_SKILLS_DIR).filter(
    d => !d.startsWith('.') && fs.statSync(path.join(LOCAL_SKILLS_DIR, d)).isDirectory()
  );
  console.log(`本地技能: ${localEntries.length} 个`);
}

// ===== CLI 入口 =====

function main() {
  const args = process.argv.slice(2);

  if (args.includes('--list') || args.includes('-l')) {
    listDeployed();
    return;
  }

  if (args.includes('--pending')) {
    deployAllPending();
    return;
  }

  if (args.includes('--deploy') || args.includes('-d')) {
    const skillId = args[args.indexOf('--deploy') + 1] || args[args.indexOf('-d') + 1];
    if (!skillId) { console.log('用法: node deploy.js --deploy <skill-id> [--force]'); process.exit(1); }
    const force = args.includes('--force') || args.includes('-f');
    const r = deploySkill(skillId, { force });
    console.log(JSON.stringify(r, null, 2));
    return;
  }

  if (args.includes('--status')) {
    const log = loadDeployLog();
    console.log(`\n部署历史（共${log.length}条）:`);
    log.slice(0, 15).forEach(e => {
      console.log(`  ${e.deployedAt?.slice(0, 10)} | ${e.skillId} | v${e.version} | ${e.deployedPath}`);
    });
    return;
  }

  if (args.includes('--unregister')) {
    const skillId = args[args.indexOf('--unregister') + 1];
    if (!skillId) { console.log('用法: node deploy.js --unregister <skill-id>'); process.exit(1); }
    const r = unregisterSkill(skillId);
    console.log(JSON.stringify(r, null, 2));
    return;
  }

  console.log(`
DEPLOY 模块 | 部署 Skill 到 OpenClaw Registry

用法：
  node deploy.js --list                    列出已部署的skills
  node deploy.js --pending                 部署所有待部署的skills
  node deploy.js --deploy <skill-id>       部署单个skill
  node deploy.js --deploy <skill-id> --force  强制重新部署
  node deploy.js --status                  查看部署历史
  node deploy.js --unregister <skill-id>   取消注册skill
`);
}

module.exports = { deploySkill, deployAllPending, listDeployed, detectSkillRegistry };

if (require.main === module) main();
