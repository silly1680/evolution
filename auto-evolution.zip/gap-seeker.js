#!/usr/bin/env node
/**
 * 精准缺口搜索器 - Gap Seeker
 * 职责：定向搜索 P0 缺口的能力来源
 * MSOP: TARGET_SELECTION + EVALUATION
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

const WORKSPACE = process.env.EVOLVE_WORKSPACE || __dirname;
const REPORT_FILE = path.join(WORKSPACE, 'capability-hunt-report.md');
const RESULTS_FILE = path.join(WORKSPACE, 'gap-seeker-results.json');

// ===== 定向搜索配置 =====
const GAP_SOURCES = [
  {
    gapId: 'fin-data-api',
    gapName: '实时行情/财务数据',
    priority: 'P0',
    searchQueries: [
      'akshare A股 Python 金融数据',
      'tushare 股票数据 API github',
      'efinance python 实时行情 github',
      'mootdx 量化数据 github'
    ],
    knownRepos: [
      { name: 'akshare', url: 'https://github.com/akfamily/akshare', desc: 'AKShare: Python金融数据接口，涵盖A股、期货、期权等', matchKw: 'A股/期货/宏观数据' },
      { name: 'tushare', url: 'https://github.com/tencent-nvgtag/tushare-python', desc: 'TuShare ProA股数据接口', matchKw: '基本面/财务/实时' },
      { name: 'efinance', url: 'https://github.com/Mcedar-PKU/efinance', desc: 'Python原生A股数据获取工具', matchKw: '实时行情/东方财富' },
      { name: 'mootdx', url: 'https://github.com/mpquant/mootdx', desc: '通达信/同花顺数据读取', matchKw: 'Level2/通达信' },
    ]
  },
  {
    gapId: 'cross-platform-docs',
    gapName: '跨平台文档',
    priority: 'P0',
    searchQueries: [
      'Notion API github python',
      'github readme editor github stars',
      'obsidian vault API github'
    ],
    knownRepos: [
      { name: 'notion-sdk-py', url: 'https://github.com/ramnes/notion-sdk-py', desc: 'Notion API Python SDK', matchKw: 'Notion/数据库/页面' },
      { name: 'python-docx', url: 'https://github.com/python-openxml/python-docx', desc: 'Word文档Python处理', matchKw: 'Word/自动化报告' },
      { name: 'docx-templates', url: 'https://github.com/oxfordfn/docx-templates', desc: 'Python生成Word模板报告', matchKw: '模板化报告' },
      { name: 'docuseal', url: 'https://github.com/docuseal/docuseal', desc: '开源文档电子签章平台', matchKw: '文档签署/自动化' },
    ]
  },
  {
    gapId: 'browser-auto',
    gapName: '浏览器自动化',
    priority: 'P1',
    searchQueries: [
      'playwright python github 2025',
      'drissionpage github 2025',
      'github trending 2025 automation browser'
    ],
    knownRepos: [
      { name: 'playwright', url: 'https://github.com/microsoft/playwright', desc: '微软浏览器自动化，支持 Chromium/Firefox/WebKit', matchKw: '无头浏览器/抓取' },
      { name: 'DrissionPage', url: 'https://github.com/go-training/DrissionPage', desc: '国产轻量级浏览器自动化工具', matchKw: '简单/轻量/反爬' },
      { name: 'selenium', url: 'https://github.com/SeleniumHQ/selenium', desc: '老牌浏览器自动化', matchKw: 'Web测试/抓取' },
      { name: 'puppeteer', url: 'https://github.com/puppeteer/puppeteer', desc: 'Chrome无头模式控制', matchKw: 'Node.js/截图/PDF' },
    ]
  },
  {
    gapId: 'voice-understand',
    gapName: '音频语音理解',
    priority: 'P1',
    searchQueries: [
      'faster-whisper github stars',
      'Cosmos-TTS github stars',
      'FunAudioLLM github 2025'
    ],
    knownRepos: [
      { name: 'faster-whisper', url: 'https://github.com/SYSTRAN/faster-whisper', desc: 'Whisper高速版，支持多语言实时语音转文字', matchKw: '语音识别/ASR/字幕' },
      { name: 'Cosmos-TTS', url: 'https://github.com/Epochlab/Cosmos-TTS', desc: '高质量语音合成', matchKw: 'TTS/语音生成' },
      { name: 'FunAudioLLM', url: 'https://github.com/FunAudioLLM', desc: '蚂蚁语音大模型，支持情感/超拟人', matchKw: '情感语音/对话' },
    ]
  },
  {
    gapId: 'data-viz',
    gapName: '数据可视化',
    priority: 'P2',
    searchQueries: [
      'python plotly dash github trending 2025',
      'echarts python github',
      'recharts python github'
    ],
    knownRepos: [
      { name: 'plotly-dash', url: 'https://github.com/plotly/dash', desc: 'Plotly交互式Dashboard框架', matchKw: '交互图表/金融Dashboard' },
      { name: 'pyecharts', url: 'https://github.com/pyecharts/pyecharts', desc: '百度ECharts中文图表库Python版', matchKw: '中国风图表/易用' },
      { name: 'panel-holoviz', url: 'https://github.com/holoviz/panel', desc: 'HoloViz交互面板', matchKw: '数据探索/可交互' },
    ]
  },
  {
    gapId: 'email-operate',
    gapName: '邮件收发',
    priority: 'P2',
    searchQueries: [
      'yagmail github python email',
      'imap-tools github python email'
    ],
    knownRepos: [
      { name: 'yagmail', url: 'https://github.com/kootenpv/yagmail', desc: '超简洁Python Gmail发送库', matchKw: 'Gmail/SMTP/简单API' },
      { name: 'imap-tools', url: 'https://github.com/ikvk/imap_tools', desc: 'Python IMAP邮件读写/管理', matchKw: 'IMAP/邮件归档' },
    ]
  }
];

// ===== GitHub API 精确查询 =====
function fetchGitHubInfo(repoPath) {
  return new Promise((resolve) => {
    const [owner, repo] = repoPath.replace('https://github.com/', '').split('/');
    if (!repo) { resolve(null); return; }
    const options = {
      hostname: 'api.github.com',
      path: `/repos/${owner}/${repo}`,
      headers: { 'User-Agent': 'OpenClaw-Evolve/1.0', 'Accept': 'application/vnd.github.v3+json' }
    };
    let data = '';
    https.get(options, res => {
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch { resolve(null); }
      });
    }).on('error', () => resolve(null));
  });
}

// ===== MSOP评分 =====
function scoreTarget(repo, gapId) {
  const stars = repo?.stargazers_count || 0;
  const innovation = stars > 10000 ? 9 : stars > 1000 ? 7 : stars > 100 ? 5 : 3;
  const integration = 7; // 明确针对缺口
  const gap_match = 8; // 定向匹配
  const popularity = Math.min(10, stars / 2000);
  const risk = repo?.license?.name ? 1 : 3;

  const score = innovation * 0.35 + integration * 0.25 + gap_match * 0.2 + popularity * 0.1 - risk * 0.3;
  return Math.round(score * 10) / 10;
}

// ===== 主流程 =====
async function main() {
  console.log('[缺口] 开始定向搜索...\n');
  const allResults = [];
  const allCandidates = [];

  for (const source of GAP_SOURCES) {
    console.log(`🎯 ${source.gapName}（${source.priority}）`);
    console.log(`   搜索：${source.searchQueries.join(', ')}`);

    // 获取known repos的GitHub信息
    const repoPromises = source.knownRepos.map(r =>
      fetchGitHubInfo(r.url).then(info => ({ ...r, info }))
    );
    const repos = await Promise.all(repoPromises);

    const scored = repos
      .map(r => {
        const score = r.info ? scoreTarget(r.info, source.gapId) : 5;
        return { ...r, stars: r.info?.stargazers_count || 0, score, license: r.info?.license?.name || '无' };
      })
      .sort((a, b) => b.score - a.score);

    allResults.push({ gapId: source.gapId, gapName: source.gapName, priority: source.priority, targets: scored });

    scored.forEach(r => {
      allCandidates.push({
        gapId: source.gapId,
        gapName: source.gapName,
        priority: source.priority,
        ...r
      });
    });

    scored.forEach(r => {
      const badge = r.score >= 7 ? '🟢' : r.score >= 6 ? '🟡' : '🔴';
      console.log(`   ${badge} ${r.name} — score:${r.score} ⭐${r.stars} — ${r.desc} | 匹配:${r.matchKw}`);
    });
    console.log('');
  }

  // 保存结果
  const sorted = allCandidates.sort((a, b) => b.score - a.score);
  fs.writeFileSync(RESULTS_FILE, JSON.stringify(allResults, null, 2));

  // 生成整合报告
  let report = fs.readFileSync(REPORT_FILE, 'utf-8');
  
  // 在报告末尾追加精准搜索结果
  let addendum = `\n\n---\n\n## 🎯 精准缺口搜索结果（P0缺口专项）\n`;
  addendum += `> 由 Gap Seeker 定向搜索生成 | ${new Date().toISOString().slice(0, 10)}\n`;

  allResults.forEach(group => {
    const badge = group.priority === 'P0' ? '🔴' : group.priority === 'P1' ? '🟡' : '🟢';
    addendum += `\n### ${badge} [${group.priority}] ${group.gapName}\n\n`;
    addendum += `| 候选 | 评分 | Stars | 许可证 | 匹配点 | 链接 |\n`;
    addendum += `|------|------|-------|--------|--------|------|\n`;
    group.targets.forEach(t => {
      const b = t.score >= 7 ? '🟢' : t.score >= 6 ? '🟡' : '🔴';
      addendum += `| ${t.name} | ${b}${t.score} | ${t.stars} | ${t.license} | ${t.matchKw} | [🔗](${t.url}) |\n`;
    });
  });

  addendum += `\n## 🐺 进化优先级队列\n\n`;
  const topCandidates = sorted.filter(c => c.score >= 6).slice(0, 6);
  addendum += `按照 MSOP 评分公式，以下目标建议优先吞噬评估：\n\n`;
  topCandidates.forEach((c, i) => {
    addendum += `${i + 1}. **[${c.name}](${c.url})** \`${c.score}/10\` — 填补 \`${c.gapName}\` | ⭐${c.stars} | 行动：\`git clone 或 clawhub install ${c.name}\`\n`;
  });

  fs.writeFileSync(REPORT_FILE, report + addendum, 'utf-8');
  console.log(`\n[缺口] 结果已保存到 ${RESULTS_FILE}`);
  console.log(`[缺口] 报告已追加到 ${REPORT_FILE}`);
}

main().catch(console.error);
