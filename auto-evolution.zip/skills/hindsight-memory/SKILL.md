# Hindsight Memory - 仿生记忆系统

## 能力定义

**名称**: hindsight-memory  
**类型**: Agent Memory System (Biomimetic Memory)  
**来源**: vectorize-io/hindsight (MIT, 9,186⭐)  
**Score**: 7.78 | **替代**: reme-lite  

---

## 核心能力

### 三大操作

| 操作 | 功能 |
|------|------|
| **Retain** | 存储记忆，自动提取实体/关系/时序 |
| **Recall** | 语义检索，动态注入上下文到 system prompt |
| **Reflect** | 从原始记忆生成洞察，更新心智模型 |

### 记忆类型（三层仿生结构）

- **World Facts**: 世界知识（通用事实）
- **Experiences**: 智能体亲身经历
- **Mental Models**: 反思形成的理解

### 部署模式

| 模式 | 依赖 | API Key |
|------|------|---------|
| Cloud | 网络 | Hindsight API Token |
| Embedded Daemon | pip install hindsight-all | OpenAI/Anthropic |
| **Claude Code** ⭐ | Claude Code CLI | **无需API Key**（推荐）|

---

## 安装配置

### 方式一：OpenClaw 原生插件（推荐）

```bash
# 安装插件
openclaw plugins install @vectorize-io/hindsight-openclaw

# 运行安装向导（选择 Claude Code 模式可免 Key）
npx --package @vectorize-io/hindsight-openclaw hindsight-openclaw-setup

# 验证
openclaw config validate
```

### 方式二：Python 嵌入式

```bash
pip install hindsight-all -U
```

```python
from hindsight import HindsightServer, HindsightClient
import os

with HindsightServer(llm_provider="openai",
                     llm_model="gpt-4o-mini",
                     llm_api_key=os.environ["OPENAI_API_KEY"]) as server:
    client = HindsightClient(base_url=server.url)
    client.retain(bank_id="my-bank", content="用户老梅喜欢A股投资")
    results = client.recall(bank_id="my-bank", query="老梅的爱好是什么")
```

---

## OpenClaw 插件关键配置项

配置路径: plugins.entries.hindsight-openclaw.config

| 配置项 | 默认 | 说明 |
|--------|------|------|
| llmProvider | - | claude-code（免Key）/ openai / anthropic |
| dynamicBankId | true | 按 agent/channel/user 隔离记忆银行 |
| autoRecall | true | 每轮自动注入相关记忆 |
| autoRetain | true | 每轮自动存储对话 |
| recallBudget | mid | low/mid/high，检索深度 |
| recallMaxTokens | 1024 | 单次注入最大 token 数 |
| retainRoles | user,assistant | 存储哪些角色的消息 |
| excludeProviders | heartbeat | 跳过的消息来源 |

---

## 记忆银行隔离

Bank ID 格式: agent:main:user:ou_xxx  
老梅专属银行: agent:main:user:ou_8cf0553c3cc9ba3fa15fc3c36869a3b6

---

## 技术规格

- **Benchmark**: LongMemEval SOTA（91.4%）  
- **独立复现**: Virginia Tech + The Washington Post  
- **生产用户**: Fortune 500 企业 + 多个 AI 创业公司  
- **支持集成**: AutoGen, Claude Code, Cursor, CrewAI, LangGraph, LlamaIndex, **OpenClaw**  
- **License**: MIT  
- **GitHub**: https://github.com/vectorize-io/hindsight
