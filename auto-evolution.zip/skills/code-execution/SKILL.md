# Code-Execution — 安全代码执行沙盒

> **MSOP AUTO-GENERATED** | Score: 7.5 | APPROVAL: ✅ AUTO-APPROVED  
> ID: `code-execution` | Source: MSOP自主构建（subprocess + resource限制）  
> Generated: 2026-03-30 | DNA: `code-execution`, `sandbox`, `subprocess`, `security`  
> 安装: **零依赖**（纯Python标准库：subprocess + os + resource）

## 概述

安全隔离的 Python 代码执行沙盒，防止恶意代码破坏系统。可与 **akshare**、**plotly-dash** 联动，在生成图表或分析数据时实时执行代码。

**安全策略：**
- ⏱ **超时限制** — 默认5秒，防止无限循环
- 🔒 **子进程隔离** — 独立进程，无法访问主进程内存
- 🌐 **可选断网** — `allow_network=False` 时禁止网络访问
- 📁 **可选文件系统限制** — 可配置只读/可写目录
- 🚫 **无os.system/eval** — subprocess管道执行，无法调用系统命令

## 安装

```bash
# 无需安装！直接使用
cp /workspace/evolve/skills/code-execution/code_executor.py ./
chmod +x code_executor.py
```

## 使用方式

### 基本执行
```bash
# 直接运行代码
python3 code_executor.py run "print('hello world')"

# 指定超时
python3 code_executor.py run "import time; time.sleep(3); print('done')" --timeout 10

# 危险模式（开启网络+文件系统）
python3 code_executor.py run "import urllib.request; print(urllib.request.urlopen('https://httpbin.org/ip').read())" --dangerous
```

### 环境检测
```bash
# 检测所有预设环境
python3 code_executor.py check

# 测试单个场景
python3 code_executor.py scenario akshare
python3 code_executor.py scenario numpy
python3 code_executor.py scenario chart
```

### Python调用
```python
from code_executor import run, run_safe

# 安全执行
result = run("import akshare as ak; print(ak.__version__)", timeout=10)
print(result.stdout if result.returncode == 0 else result.stderr)

# 带异常抛出
try:
    output = run_safe("print(1+1)", timeout=5)
    print(output)
except RuntimeError as e:
    print("执行失败:", e)
```

## 预设场景

| 场景 | 代码 | 说明 |
|------|------|------|
| akshare | `import akshare as ak; print(ak.__version__)` | 验证akshare |
| numpy | `import numpy as np; print(np.__version__)` | 验证numpy |
| pandas | `import pandas as pd; print(pd.__version__)` | 验证pandas |
| chart | `import matplotlib...` | 验证matplotlib出图 |
| json | `import json; print(json.loads('{}'))` | 验证JSON解析 |

## 在A股早报中集成

```python
from code_executor import run

# 生成图表后执行渲染验证
result = run(
    "import matplotlib; matplotlib.use('Agg')"
    "; import matplotlib.pyplot as plt"
    "; plt.plot([1,2,3],[4,5,6])"
    "; plt.savefig('/tmp/test.png')"
    "; print('图表生成成功')",
    timeout=10
)
print(result)
```

## MSOP评分

| 维度 | 得分 | 说明 |
|------|------|------|
| Innovation | 8.0 | 安全沙盒+多级防御架构 |
| Integration | 8.5 | akshare/chart/numpy全链路支持 |
| Gap Match | 8.5 | **直接匹配缺口：代码执行** |
| Popularity | 7.0 | Jupyter/Python生态核心能力 |
| Risk | 2.0 | subprocess隔离，有限风险 |

**MSOP评分 = 7.5/10**

## DNA 能力标签

```
code-execution → sandbox → subprocess → security → automation
```

## 回滚

```bash
rm -rf /workspace/evolve/skills/code-execution/
```
