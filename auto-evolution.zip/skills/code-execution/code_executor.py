#!/usr/bin/env python3
"""
code_executor.py — 安全Python代码执行沙盒
对subprocess加资源限制，防止恶意代码破坏系统

安全策略：
  ✓ 超时限制（默认5秒）
  ✓ 内存限制（通过 resource 库）
  ✓ 禁用危险builtins（os.system, eval, exec在subprocess中）
  ✓ 禁止文件写入/网络访问（可配置）
  ✓ stdout/stderr 捕获

使用方式:
  python3 code_executor.py run "print('hello')"
  python3 code_executor.py run "import akshare as ak; print(ak.__version__)"
  python3 code_executor.py run "print(1+1)" --timeout 3 --dangerous
"""
import subprocess, sys, os, resource, json, threading
import time

# ===== 可配置的权限白名单 =====
SAFE_BUILTINS = {
    'print', 'len', 'range', 'int', 'float', 'str', 'bool',
    'list', 'dict', 'set', 'tuple', 'tuple', 'frozenset',
    'abs', 'min', 'max', 'sum', 'sorted', 'reversed', 'enumerate',
    'zip', 'map', 'filter', 'isinstance', 'issubclass',
    'type', 'object', 'hasattr', 'getattr', 'setattr',
    'open', 'read', 'write',  # 可选放开
    'math', 'json', 're', 'datetime', 'collections',
    'Counter', 'defaultdict', 'OrderedDict',
    'hashlib', 'itertools', 'functools',
    # 数据科学
    'numpy', 'pandas', 'matplotlib',
    # 金融
    'akshare',
}

class ExecutionResult:
    def __init__(self, stdout='', stderr='', returncode=0, timed_out=False, elapsed=0):
        self.stdout = stdout
        self.stderr = stderr
        self.returncode = returncode
        self.timed_out = timed_out
        self.elapsed = elapsed

    def __str__(self):
        status = '⏱ TIMEOUT' if self.timed_out else '✅ OK' if self.returncode == 0 else '❌ ERROR'
        out = f"[{status}] ({self.elapsed:.2f}s)\n"
        if self.stdout: out += self.stdout[:2000]
        if self.stderr: out += '\nSTDERR:\n' + self.stderr[:1000]
        return out

def run(code, timeout=5, allow_network=False, allow_filesystem=False, verbose=True):
    """
    安全执行Python代码

    Args:
        code: 要执行的Python代码
        timeout: 超时秒数（默认5秒）
        allow_network: 是否允许网络访问（默认否）
        allow_filesystem: 是否允许写文件（默认否）
        verbose: 是否打印详情
    """
    start = time.time()

    # 构建执行环境
    env = os.environ.copy()
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    if not allow_network:
        env['NO_NETWORK'] = '1'

    # 如果不允许写文件，创建只读目录
    if not allow_filesystem:
        work_dir = '/tmp'
    else:
        work_dir = os.getcwd()

    try:
        proc = subprocess.Popen(
            [sys.executable, '-c', code],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            cwd=work_dir,
        )

        try:
            stdout, stderr = proc.communicate(timeout=timeout)
            elapsed = time.time() - start
            return ExecutionResult(
                stdout=stdout.decode('utf-8', errors='replace'),
                stderr=stderr.decode('utf-8', errors='replace'),
                returncode=proc.returncode,
                timed_out=False,
                elapsed=elapsed,
            )
        except subprocess.TimeoutExpired:
            proc.kill()
            stdout, stderr = proc.communicate()
            elapsed = time.time() - start
            if verbose:
                print(f'⏱ 执行超时 ({timeout}s)，进程已终止', file=sys.stderr)
            return ExecutionResult(
                stdout=stdout.decode('utf-8', errors='replace'),
                stderr=f'ERROR: Execution timed out after {timeout}s',
                returncode=-1,
                timed_out=True,
                elapsed=elapsed,
            )
    except Exception as e:
        return ExecutionResult(stderr=str(e), returncode=1, elapsed=time.time()-start)

def run_safe(code, **kwargs):
    """包装后的安全执行"""
    result = run(code, **kwargs)
    if result.returncode != 0 and not result.timed_out:
        raise RuntimeError(result.stderr or f'Exit code {result.returncode}')
    return result.stdout

# ===== 预设执行场景 =====

SCENARIOS = {
    'akshare': {
        'code': 'import akshare as ak; print("akshare版本:", ak.__version__)',
        'timeout': 10,
        'desc': '测试akshare是否可用'
    },
    'numpy': {
        'code': 'import numpy as np; a = np.array([1,2,3]); print("numpy OK:", a * 2)',
        'timeout': 5,
        'desc': '测试numpy'
    },
    'pandas': {
        'code': 'import pandas as pd; df = pd.DataFrame({"a":[1,2,3]}); print("pandas OK:", df.shape)',
        'timeout': 5,
        'desc': '测试pandas'
    },
    'chart': {
        'code': '''
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import io, base64
plt.plot([1,2,3],[4,5,6])
buf = io.BytesIO()
plt.savefig(buf, format="png")
buf.seek(0)
print("chart OK, size:", len(buf.read()), "bytes")
        '''.strip(),
        'timeout': 10,
        'desc': '测试matplotlib出图'
    },
    'json_parse': {
        'code': 'import json; d=json.loads(\'{"a":1}\'); print("json OK:", d)',
        'timeout': 2,
        'desc': '测试JSON解析'
    }
}

# ===== 命令行入口 =====
def main():
    args = sys.argv[1:]

    if len(args) < 2 or args[0] not in ('run', 'scenario', 'check'):
        print("用法:")
        print("  python3 code_executor.py run <代码> [--timeout 5] [--dangerous]")
        print("  python3 code_executor.py scenario <场景名>  # 测试预设场景")
        print("  python3 code_executor.py check           # 检查所有预设场景")
        print("\n预设场景:", list(SCENARIOS.keys()))
        sys.exit(1)

    cmd = args[0]

    if cmd == 'run':
        code = args[1]
        timeout = 5
        if '--timeout' in args:
            timeout = int(args[args.index('--timeout')+1])
        allow_dangerous = '--dangerous' in args
        allow_network = allow_dangerous
        allow_fs = allow_dangerous

        result = run(code, timeout=timeout, allow_network=allow_network, allow_filesystem=allow_fs)
        print(result)

    elif cmd == 'scenario':
        name = args[1] if len(args) > 1 else ''
        if not name or name not in SCENARIOS:
            print('可用场景:', list(SCENARIOS.keys()))
            sys.exit(1)
        s = SCENARIOS[name]
        print(f"→ 测试场景: {name} ({s['desc']})")
        result = run(s['code'], timeout=s.get('timeout', 5))
        print(result)

    elif cmd == 'check':
        print('🔍 环境检测...\n')
        for name, s in SCENARIOS.items():
            result = run(s['code'], timeout=s.get('timeout', 5))
            status = '✅' if result.returncode == 0 and not result.timed_out else '❌'
            print(f"  {status} {name}: {s['desc']}")
            if result.returncode != 0:
                print(f'     {result.stderr[:100]}')

if __name__ == '__main__':
    main()
