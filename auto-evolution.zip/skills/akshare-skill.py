#!/usr/bin/env python3
"""
akshare 能力封装 Skill
来源: https://github.com/akfamily/akshare
评分: 7.1/10 | 填补P0缺口: A股实时行情/财务数据
状态: 已安装venv，可用

使用前提:
  source /workspace/evolve/venv/bin/activate
  python3 /workspace/evolve/skills/akshare-skill.py --action ...

注意: 如果akshare接口超时（>20秒），会自动降级使用东方财富API
"""

import sys
import json
import argparse
from datetime import datetime, timedelta

def install_akshare():
    import subprocess
    print("[安装] 正在安装 akshare...")
    result = subprocess.run([sys.executable, '-m', 'pip', 'install', 'akshare', '-q'], 
                          capture_output=True, text=True)
    if result.returncode == 0:
        print("[✅ 安装成功] akshare 已安装")
        return True
    else:
        print(f"[❌ 安装失败] {result.stderr}")
        return False

def check_akshare():
    try:
        import akshare as ak
        return True
    except ImportError:
        return install_akshare()

# ===== 核心能力函数 =====

def get_stock_quote(symbol: str):
    """获取个股行情（实时+基本信息），超时20秒降级"""
    try:
        import akshare as ak
        import signal
        def timeout_handler():
            raise TimeoutError("akshare超时")
        signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError()))
        signal.alarm(20)
        try:
            df = ak.stock_individual_info_em(symbol=symbol)
            signal.alarm(0)
            result = {}
            for _, row in df.iterrows():
                result[row['item']] = row['value']
            return result
        except TimeoutError:
            signal.alarm(0)
            return _fallback_quote(symbol)
    except Exception as e:
        return _fallback_quote(symbol)

def _fallback_quote(symbol: str):
    """降级方案：用东方财富API获取个股行情"""
    import urllib.request, json, urllib.error
    url = f"https://push2.eastmoney.com/api/qt/stock/get?secid=1.{symbol}&fields=f43,f57,f58,f169,f170,f46,f60,f170"
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            data = json.loads(r.read())
            d = data.get('data', {})
            if d:
                return {
                    "股票代码": symbol,
                    "最新价": d.get('f43', 'N/A') / 100,
                    "涨跌幅": d.get('f170', 'N/A') / 100,
                    "最高": d.get('f44', 'N/A') / 100,
                    "最低": d.get('f45', 'N/A') / 100,
                    "开盘": d.get('f46', 'N/A') / 100,
                    "昨收": d.get('f60', 'N/A') / 100,
                    "成交额(万元)": d.get('f47', 'N/A') / 10000,
                    "数据来源": "东方财富(降级)"
                }
    except Exception as e:
        return {"error": str(e), "股票代码": symbol}
    return {"error": "无法获取数据", "股票代码": symbol}

def get_market_summary():
    """获取A股市场概况，快接口版"""
    try:
        import akshare as ak
        import signal
        signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError()))
        signal.alarm(20)
        try:
            # 使用快接口：A股实时指数
            indices = [
                ("上证指数", "000001", "sh"),
                ("深证成指", "399001", "sz"),
                ("创业板指", "399006", "sz"),
                ("沪深300", "000300", "sh"),
            ]
            results = {}
            for name, code, market in indices:
                try:
                    df = ak.stock_zh_index_daily_em(symbol=f"{market}{code}")
                    if not df.empty:
                        latest = df.iloc[-1]
                        results[name] = {"点位": round(latest['close'], 2), "涨跌": round(latest['close']-latest['open'], 2)}
                except:
                    results[name] = {"点位": "N/A", "涨跌": "N/A"}
            signal.alarm(0)
            return results
        except TimeoutError:
            signal.alarm(0)
            return _fallback_market_summary()
    except Exception as e:
        return _fallback_market_summary()

def _fallback_market_summary():
    """降级方案：用东方财富批量接口"""
    import urllib.request, json
    codes = ["1.000001", "0.399001", "0.399006", "1.000300"]
    url = f"https://push2.eastmoney.com/api/qt/ulist.np/get?fltt=2&invt=2&fields=f2,f3,f4,f12,f14&secids={','.join(codes)}"
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            data = json.loads(r.read())
            items = data.get('data', {}).get('diff', [])
            names = {"1.000001": "上证指数", "0.399001": "深证成指", "0.399006": "创业板指", "1.000300": "沪深300"}
            result = {}
            for item in items:
                name = names.get(item.get('f12', ''), item.get('f12',''))
                result[name] = {"点位": item.get('f2','N/A'), "涨跌幅": item.get('f3','N/A')}
            return result
    except Exception as e:
        return {"error": str(e)}

def get_trade_calendar(days: int = 5):
    """获取最近交易日历"""
    try:
        import akshare as ak
        import signal
        signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError()))
        signal.alarm(10)
        try:
            df = ak.tool_trade_date_hist_sina()
            signal.alarm(0)
            recent = df.tail(days)['trade_date'].tolist()
            return {"最近交易日": recent}
        except TimeoutError:
            signal.alarm(0)
            from datetime import date
            return {"注意": "日历接口超时，请通过新闻确认交易日", "说明": "工作日通常为交易日"}
    except Exception as e:
        return {"error": str(e)}

def get_index_quote(index_code: str = "000001"):
    """获取指数实时行情"""
    try:
        import akshare as ak
        market = "sh" if index_code.startswith("000") else "sz"
        df = ak.stock_zh_index_daily_em(symbol=f"{market}{index_code}")
        if not df.empty:
            latest = df.iloc[-1]
            prev = df.iloc[-2]['close'] if len(df) > 1 else latest['close']
            chg = latest['close'] - prev
            pct = (chg / prev * 100) if prev else 0
            return {
                "指数代码": index_code,
                "最新点位": round(latest['close'], 2),
                "涨跌幅": round(pct, 2),
                "涨跌额": round(chg, 2),
                "时间": datetime.now().strftime("%Y-%m-%d"),
                "数据来源": "akshare"
            }
        return {"error": "无数据"}
    except Exception as e:
        return {"error": str(e), "说明": "请尝试不同指数代码"}

def get_stock_financial_report(symbol: str):
    """获取个股财务报告"""
    try:
        import akshare as ak
        import signal
        signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError()))
        signal.alarm(15)
        try:
            income = ak.stock_profit_sheet_by_report_em(symbol=symbol)
            signal.alarm(0)
            if not income.empty:
                row = income.iloc[0]
                return {
                    "股票代码": symbol,
                    "报告期": str(row.get('报告日期', 'N/A')),
                    "净利润": row.get('净利润', 'N/A'),
                    "营业总收入": row.get('营业总收入', 'N/A'),
                    "数据来源": "akshare"
                }
        except TimeoutError:
            signal.alarm(0)
    except Exception as e:
        pass
    return {"股票代码": symbol, "状态": "财务数据获取失败，请稍后重试"}

def get_stock_news(symbol: str = "000001"):
    """获取个股最新新闻/公告"""
    try:
        import akshare as ak
        import signal
        signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError()))
        signal.alarm(10)
        try:
            df = ak.stock_news_em(symbol=symbol)
            signal.alarm(0)
            if not df.empty:
                news = df.head(5)[['发布时间', '新闻标题', '文章来源']].to_dict('records')
                return {"news": news, "stock": symbol}
        except TimeoutError:
            signal.alarm(0)
    except Exception as e:
        pass
    return {"error": "新闻获取失败", "stock": symbol}

def get_realtime_quote(symbols: list):
    """批量获取实时行情（多个股票）"""
    import urllib.request, json
    secids = [f"1.{s}" if s.startswith('6') else f"0.{s}" for s in symbols]
    url = f"https://push2.eastmoney.com/api/qt/ulist.np/get?fltt=2&invt=2&fields=f2,f3,f12,f14&secids={','.join(secids)}"
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            data = json.loads(r.read())
            items = data.get('data', {}).get('diff', [])
            return [{"代码": i['f12'], "名称": i['f14'], "最新价": i['f2'], "涨跌幅": i['f3']} for i in items]
    except Exception as e:
        return [{"error": str(e)}]

def generate_a_stock_brief(symbol: str):
    """生成个股简报（整合所有数据）"""
    quote = get_stock_quote(symbol)
    financial = get_stock_financial_report(symbol)
    summary = get_market_summary()
    
    report = f"""
========== 📊 个股简报：{quote.get('股票简称', symbol)}（{symbol}）==========
🏠 最新价：{quote.get('最新价', 'N/A')} | 涨跌幅：{quote.get('涨跌幅', 'N/A')}%
📅 报告期：{financial.get('报告期', 'N/A')}
💰 净利润：{financial.get('净利润', 'N/A')} | 营业总收入：{financial.get('营业总收入', 'N/A')}
🏦 总市值：{quote.get('总市值', 'N/A')} | 流通市值：{quote.get('流通市值', 'N/A')}
📋 所属行业：{quote.get('行业', 'N/A')}

========== 🌐 市场指数 ==========
"""
    if isinstance(summary, dict) and '上证指数' in summary:
        for name, data in summary.items():
            if isinstance(data, dict):
                report += f"{name}：{data.get('点位','N/A')} | 涨跌幅：{data.get('涨跌幅','N/A')}%\n"
    else:
        report += f"{summary}\n"

    report += f"\n[数据来源: akshare + 东方财富 | 更新时间: {datetime.now().strftime('%H:%M:%S')}]\n"
    return report

# ===== CLI 入口 =====
def main():
    parser = argparse.ArgumentParser(description='akshare A股数据Skill')
    parser.add_argument('--action', '-a', required=True, 
                        choices=['stock_quote', 'market_summary', 'index_quote', 
                                 'financial_report', 'stock_news', 'realtime',
                                 'trade_calendar', 'brief', 'install'],
                        help='操作类型')
    parser.add_argument('--symbol', '-s', default='600519', help='股票代码')
    parser.add_argument('--symbols', nargs='+', help='多个股票代码')
    parser.add_argument('--index', '-i', default='000001', help='指数代码')
    parser.add_argument('--days', '-d', type=int, default=5, help='天数')

    args = parser.parse_args()

    if args.action == 'install':
        install_akshare()
        return

    if not check_akshare():
        print('[❌] akshare 未安装且安装失败')
        sys.exit(1)

    if args.action == 'stock_quote':
        result = get_stock_quote(args.symbol)
    elif args.action == 'market_summary':
        result = get_market_summary()
    elif args.action == 'index_quote':
        result = get_index_quote(args.index)
    elif args.action == 'financial_report':
        result = get_stock_financial_report(args.symbol)
    elif args.action == 'stock_news':
        result = get_stock_news(args.symbol)
    elif args.action == 'realtime':
        result = get_realtime_quote(args.symbols or [args.symbol])
    elif args.action == 'trade_calendar':
        result = get_trade_calendar(args.days)
    elif args.action == 'brief':
        result = generate_a_stock_brief(args.symbol)
        print(result)
        return

    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
