# Tavily Search - AI优化网络搜索

> **MSOP AUTO-GENERATED** | v0.7.23 | Score: 9.2  
> ID: `tavily-search` | Source: [tavily-ai/tavily-python](https://github.com/tavily-ai/tavily-python)  
> Generated: 2026-03-30 | DNA: `ai-search`, `web-scraping`, `real-time-data`, `news-aggregation`  
> 吞噬评估: 9.2/10 | APPROVAL: ✅ AUTO-APPROVED | 依赖: 仅Python标准库（urllib）

## 概述

Tavily Search 是专为 LLM 优化的 AI 搜索引擎，提供实时、相关、去噪的网络搜索结果。与普通搜索不同，Tavily 返回结构化结果 + AI 生成的摘要（answer），可直接用于增强 LLM 的上下文。

**核心能力：**
- 🔍 **实时网络搜索** — 支持新闻、财经、技术等多领域
- 🤖 **AI生成摘要** — 每个搜索返回 LLM 友好的 answer 字段
- 📊 **结构化结果** — title + url + content + score
- ⚡ **快速响应** — 通常 <2 秒

## 安装

```bash
# 无需安装！直接使用（仅需Python 3 标准库）
cp /workspace/evolve/skills/tavily-search/tavily_search.py ./

# 设置API Key
export TAVILY_API_KEY="your-key-here"
```

**获取 API Key：**
1. 访问 https://tavily.com 注册（免费账户每月1000次）
2. Dashboard → API Key
3. 设置环境变量

## 使用方式

### 命令行
```bash
# 基本搜索（默认10条）
python3 tavily_search.py "英伟达最新财报"

# 指定结果数
python3 tavily_search.py "A股今日行情" 20

# 指定API Key（命令行传入）
python3 tavily_search.py "美联储加息" 10 "sk-xxx"
```

### Python脚本内调用
```python
from tavily_search import search, format_results

data = search("英伟达财报分析", max_results=10, api_key="sk-xxx")
results = data["results"]  # list of {title, url, content, score}
answer = data["answer"]      # AI生成的摘要
```

### 在A股早报中集成
```python
# 在早报生成前获取隔夜重要新闻
news = search("昨夜美股 A股 宏观要闻", max_results=15, api_key=os.getenv("TAVILY_API_KEY"))
headlines = [(r['title'], r['url']) for r in news['results'][:5]]
ai_summary = news.get('answer', '')  # 直接插入早报
```

## 能力参数

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| query | string | 必填 | 搜索词 |
| max_results | int | 10 | 返回结果数（建议≤20） |
| api_key | string | 环境变量 | Tavily API Key |
| timeout | int | 15 | 请求超时（秒） |

## 评分记录（MSOP）

| 维度 | 得分 | 说明 |
|------|------|------|
| Innovation | 9.0 | LLM专用搜索，answer字段直出摘要 |
| Integration | 8.5 | 零依赖，urllib即可，秒级集成 |
| Gap Match | 9.0 | **强烈匹配 P0 缺口：实时行情/宏观新闻** |
| Popularity | 8.5 | GitHub 3k+ stars，持续活跃 |
| Risk | 2.0 | 仅读请求，MIT许可，零风险 |

**MSOP评分 = 9.2/10**

## DNA 能力标签

```
ai-search → web-scraping → real-time-data → news-aggregation → finance-data
```

## 当前限制

- ⚠️ **需要 API Key** — 免费额度1000次/月，超出需付费
- ⚠️ **无API Key时不可用** — 建议备用 DuckDuckGo/Bing 搜索

## 回滚

```bash
rm -rf /workspace/evolve/skills/tavily-search/
```
