#!/usr/bin/env python3
"""
Tavily Search - AI优化搜索引擎 Python包装器
使用内置urllib（无需安装requests/httpx）
用法: python3 tavily_search.py "英伟达财报" 1000
"""
import json, os, sys, urllib.request, urllib.parse

API_KEY = os.getenv("TAVILY_API_KEY", "")
BASE_URL = "https://api.tavily.com"

def search(query, max_results=10, api_key=None, timeout=15):
    """执行Tavily搜索"""
    key = api_key or API_KEY
    if not key:
        raise ValueError("需要 Tavily API Key，请设置环境变量 TAVILY_API_KEY")

    payload = json.dumps({
        "query": query,
        "max_results": max_results,
        "include_answer": True,
        "include_raw_content": False,
        "include_images": False,
    }).encode()

    req = urllib.request.Request(
        f"{BASE_URL}/search",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {key}",
            "X-Client-Source": "openclaw-msop-skill",
        },
        method="POST"
    )

    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode())

def format_results(data):
    """格式化输出"""
    results = data.get("results", [])
    answer = data.get("answer", "")
    print(f"\n🔍 查询: {data.get('query', '')}")
    print(f"📰 结果: {len(results)} 条")
    if answer:
        print(f"\n💬 AI摘要: {answer}\n")
    print("-" * 60)
    for i, r in enumerate(results, 1):
        print(f"{i}. {r.get('title', '无标题')}")
        print(f"   📎 {r.get('url', '')}")
        if r.get('content'):
            print(f"   {r.get('content')[:200]}...")
        print()
    return results

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3 tavily_search.py <搜索词> [max_results] [api_key]")
        print("示例: python3 tavily_search.py '英伟达财报' 10 sk-xxx")
        sys.exit(1)

    query = sys.argv[1]
    max_r = int(sys.argv[2]) if len(sys.argv) > 2 else 10
    key = sys.argv[3] if len(sys.argv) > 3 else None

    try:
        data = search(query, max_r, key)
        format_results(data)
    except Exception as e:
        print(f"❌ 搜索失败: {e}")
        sys.exit(1)
