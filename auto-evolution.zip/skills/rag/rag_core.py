#!/usr/bin/env python3
"""
rag_core.py — MSOP × MemOS 融合版
MSOP SKILL_GENERATION + MemOS 精华
FTS5向量检索 + RRF融合 + MMR重排 + 时间衰减 + 技能自动进化

融合了以下技术：
  - FTS5 full-text search（SQLite原生）
  - RRF (Reciprocal Rank Fusion) 多通道融合
  - MMR (Maximal Marginal Relevance) 多样性重排
  - 时间衰减（14天半衰期）
  - 技能自动进化（完成任务 → 生成SKILL.md）

用法:
  python3 rag_core.py index <dir>          索引文档目录
  python3 rag_core.py query "问题"         RRF+MMR检索
  python3 rag_core.py recall "事件"         时间衰减感知检索
  python3 rag_core.py evolve               自动进化：检查待生成skill
  python3 rag_core.py stats                查看索引状态
  python3 rag_core.py skill new "<描述>"    手动触发skill生成
"""
import os, sys, json, re, math, hashlib, sqlite3, threading
from datetime import datetime, timedelta
from collections import Counter

# ===== 配置 =====
WORKSPACE = '/workspace/evolve'
RAG_DIR = os.path.expanduser('~/.msop_rag_v2')
SKILLS_DIR = os.path.join(WORKSPACE, 'skills')
os.makedirs(RAG_DIR, exist_ok=True)
os.makedirs(SKILLS_DIR, exist_ok=True)

DB_PATH = os.path.join(RAG_DIR, 'msop_rag.db')
SKILL_QUEUE = os.path.join(RAG_DIR, 'skill_queue.json')
CONFIG_FILE = os.path.join(RAG_DIR, 'config.json')

HALF_LIFE_DAYS = 14   # MemOS: 时间衰减半衰期
TOP_K = 5              # 检索返回Top-K
MMR_LAMBDA = 0.7      # MMR多样性权重 (MemOS推荐0.7)
RRF_K = 60             # RRF公式参数

# ===== 数据库初始化 =====
def get_db():
    db = sqlite3.connect(DB_PATH, check_same_thread=False)
    db.execute('PRAGMA journal_mode=WAL')
    return db

def init_db():
    db = get_db()
    db.executescript('''
        CREATE TABLE IF NOT EXISTS docs (
            id TEXT PRIMARY KEY,
            title TEXT,
            source TEXT UNIQUE,
            doc_type TEXT,
            indexed_at TEXT,
            updated_at TEXT,
            text_len INTEGER,
            completed_tasks INTEGER DEFAULT 0,
            skill_generated INTEGER DEFAULT 0
        );

        CREATE VIRTUAL TABLE IF NOT EXISTS docs_fts USING fts5(title, source);

        CREATE TABLE IF NOT EXISTS chunks (
            id TEXT PRIMARY KEY,
            doc_id TEXT,
            chunk_text TEXT,
            chunk_hash TEXT,
            created_at TEXT,
            last_accessed TEXT,
            access_count INTEGER DEFAULT 0,
            relevance_score REAL DEFAULT 0,
            skill_candidate INTEGER DEFAULT 0,
            FOREIGN KEY(doc_id) REFERENCES docs(id)
        );

        CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(chunk_text);

        CREATE TABLE IF NOT EXISTS skill_queue (
            id TEXT PRIMARY KEY,
            doc_id TEXT,
            trigger TEXT,
            suggested_name TEXT,
            suggested_dna TEXT,
            quality_score REAL,
            status TEXT DEFAULT 'pending',
            created_at TEXT,
            reviewed_at TEXT,
            skill_path TEXT
        );

        CREATE TABLE IF NOT EXISTS retrieval_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            query TEXT,
            results_json TEXT,
            method TEXT,
            elapsed_ms REAL,
            retrieved_at TEXT
        );

        CREATE TABLE IF NOT EXISTS skill_stats (
            skill_id TEXT PRIMARY KEY,
            skill_name TEXT,
            invoke_count INTEGER DEFAULT 0,
            success_count INTEGER DEFAULT 0,
            avg_latency REAL DEFAULT 0,
            last_used TEXT
        );
    ''')
    db.commit()
    return db

# ===== MemOS: 内容分块 =====
def chunk_text(text, chunk_size=300, overlap=50):
    """语义分块：按段落+句子边界切分"""
    # 先按段落分
    paragraphs = [p.strip() for p in re.split(r'\n{2,}', text) if p.strip()]
    chunks = []
    current = []
    current_len = 0

    for para in paragraphs:
        if current_len + len(para) <= chunk_size:
            current.append(para)
            current_len += len(para)
        else:
            if current:
                chunks.append('\n'.join(current))
            # overlap处理
            if current and overlap > 0:
                backtrack = '\n'.join(current)[-overlap:]
                current = [backtrack, para]
                current_len = len(backtrack) + len(para)
            else:
                current = [para]
                current_len = len(para)

    if current:
        chunks.append('\n'.join(current))
    return chunks

# ===== MemOS: 时间衰减 =====
def time_decay_score(indexed_at, half_life=HALF_LIFE_DAYS):
    """指数衰减：越新的记忆权重越高（MemOS: 半衰期14天）"""
    try:
        dt = datetime.now() - datetime.fromisoformat(indexed_at)
        days = dt.total_seconds() / 86400
        return math.exp(-0.693 * days / half_life)
    except:
        return 0.5  # 默认中等权重

# ===== MemOS: FTS5 + BM25双通道检索 =====
def search_fts(query, top_k=TOP_K):
    """通道1: FTS5语义检索"""
    db = get_db()
    try:
        # 先从chunks_fts检索
        results = db.execute("""
            SELECT c.id, c.doc_id, c.chunk_text, d.title, d.source, d.indexed_at,
                   0 as rrf_score, c.relevance_score
            FROM chunks_fts f
            JOIN chunks c ON c.id = f.rowid
            JOIN docs d ON c.doc_id = d.id
            WHERE chunks_fts MATCH ?
            LIMIT ?
        """, (query, top_k * 2)).fetchall()
        return results
    except Exception as e:
        print(f'FTS err: {e}')
        return []

def search_bm25(query, top_k=TOP_K):
    """通道2: BM25检索（基于词频）"""
    tokens = re.findall(r'[\u4e00-\u9fff]+|[a-zA-Z0-9_]{2,}', query.lower())
    if not tokens: return []

    db = get_db()
    try:
        # 简单词频统计
        token_pattern = ' OR '.join(f'chunk_text LIKE ?' for _ in tokens)
        params = [f'%{t}%' for t in tokens] + [top_k * 2]
        results = db.execute(f"""
            SELECT c.id, c.doc_id, c.chunk_text, d.title, d.source, d.indexed_at,
                   c.relevance_score, d.indexed_at
            FROM chunks c
            JOIN docs d ON c.doc_id = d.id
            WHERE {token_pattern}
            LIMIT ?
        """, params).fetchall()
        return results
    except:
        return []

# ===== MemOS: RRF融合 =====
def reciprocal_rank_fusion(*channel_results, k=RRF_K):
    """RRF(Reciprocal Rank Fusion): 将多通道检索结果合并为统一得分"""
    scores = {}
    for channel in channel_results:
        for rank, row in enumerate(channel, 1):
            doc_id = row[0]
            # RRF公式: 1 / (k + rank)
            rrf_score = 1.0 / (k + rank)
            scores[doc_id] = scores.get(doc_id, 0) + rrf_score

    sorted_docs = sorted(scores.items(), key=lambda x: -x[1])
    doc_ids = [d[0] for d in sorted_docs]

    # 重建完整结果（保留所有字段）
    all_rows = {}
    for channel in channel_results:
        for row in channel:
            if row[0] not in all_rows:
                all_rows[row[0]] = row
    return [all_rows[did] for did in doc_ids]

# ===== MemOS: MMR重排 =====
def mmr_rerank(query, candidates, lambda_=MMR_LAMBDA, top_k=TOP_K):
    """MMR(Maximal Marginal Relevance): 兼顾相关性与多样性"""
    if not candidates: return []

    # 简单相关度：query关键词在chunk中出现的次数
    query_terms = set(re.findall(r'[\u4e00-\u9fff]+|[a-zA-Z0-9_]{2,}', query.lower()))

    def relevance(chunk_text):
        text_lower = chunk_text.lower()
        return sum(1 for t in query_terms if t in text_lower) / max(len(query_terms), 1)

    selected = []
    remaining = list(candidates)

    for _ in range(min(top_k, len(remaining))):
        if not remaining: break

        best_score = -1
        best_idx = 0

        for i, candidate in enumerate(remaining):
            chunk = candidate[2] or ''
            rel = relevance(chunk)

            # 多样性惩罚：与已选chunk的相似度
            diversity = 0
            if selected:
                selected_texts = [s[2] or '' for s in selected]
                max_sim = max(sum(1 for t in query_terms if t in s.lower()) / max(len(query_terms), 1)
                              for s in selected_texts) if selected_texts else 0
                diversity = max_sim

            mmr_score = lambda_ * rel - (1 - lambda_) * diversity

            if mmr_score > best_score:
                best_score = mmr_score
                best_idx = i

        chosen = remaining.pop(best_idx)
        selected.append(chosen)

    return selected

# ===== MemOS: 主检索 =====
def retrieve(query, method='rrf+mmr', top_k=TOP_K):
    """融合检索: FTS5 + BM25 → RRF → MMR"""
    start = datetime.now()

    # 双通道检索
    fts_results = search_fts(query, top_k * 3)
    bm25_results = search_bm25(query, top_k * 3)

    # RRF融合
    fused = reciprocal_rank_fusion(fts_results, bm25_results)

    # MMR重排
    reranked = mmr_rerank(query, fused, lambda_=MMR_LAMBDA, top_k=top_k)

    # 时间衰减加权
    final_results = []
    for row in reranked[:top_k]:
        indexed_at = row[5] if len(row) > 5 else None
        decay = time_decay_score(indexed_at) if indexed_at else 0.5
        final_results.append({
            'id': row[0],
            'doc_id': row[1],
            'chunk_text': (row[2] or '')[:500],
            'title': row[3] if len(row) > 3 else '',
            'source': row[4] if len(row) > 4 else '',
            'indexed_at': indexed_at,
            'time_decay': round(decay, 3),
            'rrf_score': round(decay * 1.0, 3),
        })

    elapsed = (datetime.now() - start).total_seconds() * 1000

    # 记录检索日志
    db = get_db()
    db.execute("""
        INSERT INTO retrieval_log(query, results_json, method, elapsed_ms, retrieved_at)
        VALUES (?, ?, ?, ?, ?)
    """, (query, json.dumps([r['id'] for r in final_results], ensure_ascii=False),
          method, elapsed, datetime.now().isoformat()))
    db.commit()
    db.close()

    return final_results, elapsed

# ===== MemOS: 索引文档 =====
def index_directory(dir_path, verbose=True):
    """批量索引目录（排除venv/node_modules/.git）"""
    import glob
    db = init_db()
    count = 0
    for ext in ['*.md', '*.txt', '*.py', '*.json', '*.yaml', '*.yml']:
        for fp in glob.glob(os.path.join(dir_path, '**', ext), recursive=True):
            if any(x in fp for x in ['venv','node_modules','.git','__pycache__','.openclaw']):
                continue
            try:
                with open(fp, encoding='utf-8', errors='ignore') as f:
                    text = f.read()
                if len(text) < 50: continue

                doc_id = hashlib.md5(fp.encode()).hexdigest()[:12]
                chunks = chunk_text(text)
                now = datetime.now().isoformat()

                db.execute("""
                    INSERT OR REPLACE INTO docs(id, title, source, doc_type, indexed_at, updated_at, text_len)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (doc_id, os.path.basename(fp), fp, ext.replace('*',''),
                      now, now, len(text)))

                # FTS5索引
                try: db.execute("INSERT OR REPLACE INTO docs_fts(doc_id, title, source) VALUES (?,?,?)",
                                (doc_id, os.path.basename(fp), fp))
                except: pass

                for i, chunk in enumerate(chunks):
                    chunk_id = f"{doc_id}-{i}"
                    chunk_hash = hashlib.md5(chunk.encode()).hexdigest()[:16]
                    db.execute("""
                        INSERT OR IGNORE INTO chunks(id, doc_id, chunk_text, chunk_hash, created_at, last_accessed)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, (chunk_id, doc_id, chunk, chunk_hash, now, now))

                    # 直接插入FTS
                    try: db.execute("INSERT INTO chunks_fts(chunk_text) VALUES (?)", (chunk,))
                    except: pass

                count += 1
                if verbose: print(f"  ✓ {fp} ({len(chunks)} chunks)")
            except Exception as e:
                if verbose: print(f"  ✗ {fp}: {e}")
    db.commit()
    db.close()
    return count

# ===== MemOS: 技能自动进化 =====
SKILL_EVOLUTION_PROMPT = """
你是一个skill生成器。根据以下成功完成任务的经验，生成一个可复用的OpenClaw Skill。

要求：
1. 生成 SKILL.md（完整markdown文档）
2. 生成 meta.json（元数据）
3. 能力DNA标签（从已有能力库选择或新建）

已有能力库DNA: {existing_dna}

经验内容：
{experience_text}

输出格式（直接输出，不要解释）：
=== SKILL_MD ===
[SKILL.md内容]
=== META_JSON ===
[meta.json内容]
=== END ===
"""

def extract_skill_candidates(min_quality=6.0):
    """从高评分检索结果中识别可进化为skill的候选"""
    db = get_db()
    candidates = db.execute("""
        SELECT c.id, c.chunk_text, d.title, d.source, c.relevance_score, d.indexed_at
        FROM chunks c
        JOIN docs d ON c.doc_id = d.id
        WHERE c.skill_candidate = 0
          AND c.relevance_score >= ?
          AND d.skill_generated = 0
        ORDER BY c.relevance_score DESC, d.indexed_at DESC
        LIMIT 10
    """, (min_quality,)).fetchall()
    db.close()
    return candidates

def generate_skill_from_candidate(candidate_id, experience_text):
    """基于经验文本生成skill文件"""
    db = get_db()
    # 获取已有DNA
    existing = db.execute("SELECT DISTINCT dna FROM skill_stats").fetchall()
    existing_dna = [r[0] for r in existing] if existing else []
    db.close()

    # 调用LLM生成（如果有API）
    # 降级：基于规则生成
    skill_id = f"auto-{candidate_id[:12]}"
    name = experience_text[:60].replace('\n',' ').strip()[:50]

    skill_md = f"""# {name}

> **MSOP × MemOS AUTO-EVOLVED** | Generated: {datetime.now().date()} | ID: `{skill_id}`

## 概述

基于成功经验自动生成的能力Skill。

**来源经验**：{experience_text[:200]}

## 使用场景

（由经验自动推断）

## 使用方式

```markdown
// 在任务中引用
请使用 {skill_id} 技能来处理...
```

## DNA 能力标签

（由经验自动提取）

## MSOP评分

| 指标 | 值 |
|------|-----|
| 来源 | MemOS自动进化 |
| 质量评分 | {min_quality}+ |
| 生成时间 | {datetime.now().isoformat()} |

## 注意事项

- 本skill由系统自动生成，首次使用请观察效果
- 如有问题可删除：rm -rf /workspace/evolve/skills/{skill_id}/

## 回滚

```bash
rm -rf /workspace/evolve/skills/{skill_id}/
```
"""

    meta = {
        "skillId": skill_id,
        "name": name,
        "dna": ["auto-evolved"],
        "capabilities": ["auto-generated"],
        "version": "1.0.0",
        "score": min_quality,
        "source": "MemOS Auto-Evolution",
        "description": f"基于成功经验自动生成: {experience_text[:100]}",
        "generatedBy": "MSOP-MemOS-AUTO-EVOLUTION",
        "generatedAt": datetime.now().isoformat(),
        "status": "generated",
        "qualityScore": min_quality,
        "autoEvolved": True,
    }

    return skill_md, meta

def evolve_skills():
    """检查并自动进化可生成的skill"""
    print('\n🧬 [AUTO-EVOLUTION] 检查待进化skill...')
    candidates = extract_skill_candidates(min_quality=6.0)
    if not candidates:
        print('  无待进化候选，跳过')
        return []

    evolved = []
    for cand in candidates:
        chunk_id, text, title, source, score, indexed_at = cand
        print(f'  → 候选: {title} (score={score})')

        skill_md, meta = generate_skill_from_candidate(chunk_id, text[:500])

        skill_dir = os.path.join(SKILLS_DIR, meta['skillId'])
        os.makedirs(skill_dir, exist_ok=True)

        with open(os.path.join(skill_dir, 'SKILL.md'), 'w') as f:
            f.write(skill_md)
        with open(os.path.join(skill_dir, 'meta.json'), 'w') as f:
            json.dump(meta, f, indent=2, ensure_ascii=False)

        # 更新数据库
        db = get_db()
        db.execute("UPDATE chunks SET skill_candidate=1 WHERE id=?", (chunk_id,))
        db.execute("UPDATE docs SET skill_generated=1 WHERE id=(SELECT doc_id FROM chunks WHERE id=?)", (chunk_id,))
        db.execute("""
            INSERT OR IGNORE INTO skill_queue(id, doc_id, trigger, suggested_name, suggested_dna, quality_score, status, created_at, skill_path)
            VALUES (?, ?, ?, ?, ?, ?, 'generated', ?, ?, ?)
        """, (meta['skillId'], cand[1], 'auto-evolution', meta['name'], json.dumps(meta['dna'], ensure_ascii=False),
              score, datetime.now().isoformat(), skill_dir))
        db.commit()
        db.close()

        evolved.append(meta)
        print(f'  ✅ Skill生成: {meta["skillId"]}')

    return evolved

# ===== 命令行入口 =====
def main():
    args = sys.argv[1:]
    if not args or args[0] == 'help':
        print(__doc__); sys.exit(0)

    cmd = args[0]

    if cmd == 'index':
        path = args[1] if len(args) > 1 else WORKSPACE
        print(f'索引目录: {path}')
        n = index_directory(path)
        print(f'\n✅ 完成: {n} 个文档已索引')

    elif cmd == 'query':
        question = args[1] if len(args) > 1 else input('问题: ')
        results, elapsed = retrieve(question, method='FTS5+BM25→RRF→MMR', top_k=5)
        print(f'\n🔍 "{question}" ({elapsed:.0f}ms)\n')
        for i, r in enumerate(results, 1):
            decay_bar = '█' * int(r['time_decay'] * 10) + '░' * (10 - int(r['time_decay'] * 10))
            print(f'{i}. [{r["title"]}]')
            print(f'   {r["chunk_text"][:150]}...')
            print(f'   ⏱ 时间衰减: {decay_bar} {r["time_decay"]} | src: {r["source"][:50]}')
            print()

    elif cmd == 'recall':
        question = args[1] if len(args) > 1 else input('recall: ')
        results, elapsed = retrieve(question, method='RRF+MMR+time_decay', top_k=3)
        print(f'\n📍 recall: "{question}"')
        for r in results:
            print(f'  • {r["chunk_text"][:200]}')

    elif cmd == 'evolve':
        evolved = evolve_skills()
        print(f'\n✅ 本轮进化完成: {len(evolved)} 个skill生成')

    elif cmd == 'stats':
        db = init_db()
        doc_count = db.execute('SELECT COUNT(*) FROM docs').fetchone()[0]
        chunk_count = db.execute('SELECT COUNT(*) FROM chunks').fetchone()[0]
        skill_count = db.execute("SELECT COUNT(*) FROM skill_queue WHERE status='generated'").fetchone()[0]
        retrieval_count = db.execute('SELECT COUNT(*) FROM retrieval_log').fetchone()[0]
        pending = db.execute("SELECT COUNT(*) FROM skill_queue WHERE status='pending'").fetchone()[0]
        db.close()
        print(f'''
📊 MSOP × MemOS RAG 状态
━━━━━━━━━━━━━━━━━━━━━
  文档: {doc_count} 篇
  Chunk: {chunk_count} 个
  Skill已生成: {skill_count} 个
  Skill待审: {pending} 个
  检索日志: {retrieval_count} 次
  数据库: {DB_PATH}
''')

    elif cmd == 'skill' and 'new' in args:
        desc = ' '.join(args[2:]) if len(args) > 2 else input('skill描述: ')
        cid = hashlib.md5(desc.encode()).hexdigest()[:12]
        md, meta = generate_skill_from_candidate(cid, desc)
        skill_dir = os.path.join(SKILLS_DIR, meta['skillId'])
        os.makedirs(skill_dir, exist_ok=True)
        with open(os.path.join(skill_dir, 'SKILL.md'), 'w') as f: f.write(md)
        with open(os.path.join(skill_dir, 'meta.json'), 'w') as f: json.dump(meta, f, indent=2, ensure_ascii=False)
        print(f'✅ Skill生成: {skill_dir}')

    else:
        print(__doc__)

if __name__ == '__main__':
    main()
