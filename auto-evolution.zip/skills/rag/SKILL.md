# RAG — 检索增强生成知识库

> **MSOP AUTO-GENERATED** | Score: 8.0 | APPROVAL: ✅ AUTO-APPROVED  
> ID: `rag` | Source: MSOP自主构建（基于TF-IDF + BM25原理）  
> Generated: 2026-03-30 | DNA: `rag`, `vector-search`, `knowledge-base`, `nlp`  
> 安装: **零依赖**（纯Python标准库：re + math + json + collections）

## 概述

轻量级 RAG（检索增强生成）知识库系统，无需外部向量库，直接用 **TF-IDF + 余弦相似度** 实现语义检索。

**核心能力：**
- 📚 **文档索引** — 批量索引目录（md/txt/py/json/html）
- 🔍 **语义检索** — TF-IDF向量化 + 余弦相似度搜索Top-K相关块
- 🤖 **答案生成** — 基于检索片段拼接上下文，支持Tavily二次增强
- 💾 **持久化存储** — JSONL格式，追加写入

## 安装

```bash
# 无需安装！直接使用
cp /workspace/evolve/skills/rag/rag_core.py ./
```

## 使用方式

### ① 索引文档
```bash
# 索引整个目录
python3 rag_core.py index /workspace/早报/

# 索引单个文件
python3 rag_core.py index /workspace/早报模板.md
```

### ② 查询
```bash
python3 rag_core.py query "今日A股市场整体走势如何"
python3 rag_core.py query "哪些板块涨幅居前" --top-k 3
```

### ③ 查看状态
```bash
python3 rag_core.py stats
```

### Python调用
```python
from rag_core import query_rag, generate_answer, index_directory

# 查询
results, _ = query_rag("美联储加息对A股影响", top_k=3)
answer = generate_answer("美联储加息对A股影响", results)
print(answer)

# 索引
count = index_directory("/workspace/我的文档/")
print(f"已索引: {count} 个文档")
```

## 在MSOP中集成

```python
# 结合tavily-search：先本地RAG检索，再网络增强
from rag_core import query_rag, generate_answer

# Step1: 本地知识库检索
results = query_rag("公司财报分析方法", top_k=3)
local_context = "\n".join([r[1]['text'][:500] for r in results])

# Step2: Tavily网络增强
import subprocess
web_info = subprocess.check_output([
    'python3', 'skills/tavily-search/tavily_search.py',
    '公司财报分析方法', '5'
]).decode()

# Step3: 合并上下文
full_context = f"[本地知识]\n{local_context}\n\n[网络检索]\n{web_info}"
print("综合分析上下文准备完毕")
```

## MSOP评分

| 维度 | 得分 | 说明 |
|------|------|------|
| Innovation | 8.5 | 零外部依赖的RAG实现 |
| Integration | 8.0 | 与tavily/akshare天然互补 |
| Gap Match | 8.5 | **直接匹配P0缺口：RAG知识库** |
| Popularity | 7.0 | RAG是LLM落地核心技术 |
| Risk | 1.0 | 纯本地，零风险 |

**MSOP评分 = 8.0/10**

## DNA 能力标签

```
rag → vector-search → knowledge-base → nlp → context-augmentation
```

## 回滚

```bash
rm -rf /workspace/evolve/skills/rag/
```
