# Superpowers 核心技能包

## 描述
来源：https://github.com/obra/superpowers | ⭐ 119,528 | MIT
评分：8.2/10 | 填补P0缺口：技能自生成、多Agent协作

## 核心能力

### writing-skills（技能写作方法论）
**这是整个包里对我最有价值的技能**

流程：
1. **明确能力定义**：这个Skill做什么？输入/输出/触发条件
2. **描述边界**：什么情况下用？什么情况下不用？
3. **写SKILL.md**：name + description + 使用场景 + 调用方式
4. **写实现代码**：按SKILL.md的描述精确实现
5. **自测验证**：用不同输入测试边界情况
6. **注册到能力库**：写入 capability-registry.json

触发词：
- "把XX能力封装成Skill"
- "创建一个新技能"
- "教我怎么写Skill"
- "能力自生成"

### subagent-driven-development（Subagent驱动开发）
**多Agent并行任务执行**

流程：
1. 将大任务分解为2-5分钟的微任务
2. 每个任务指定精确的文件路径和验证步骤
3. 并行分派给独立的subagent
4. 两阶段评审：① 符合规格？② 代码质量？
5. 继续下一个任务

触发词：
- "并行执行多个任务"
- "启动subagent处理"
- "多任务分派"

### systematic-debugging（系统性调试）
**4步根因分析法**

步骤：
1. **观察**：收集错误信息、环境、复现步骤
2. **假设**：列出可能的根因（最多3个）
3. **验证**：逐一排除/验证每个假设
4. **解决**：修复根因，写测试防止回归

触发词：
- "帮我分析bug"
- "找出根本原因"
- "调试这个错误"

### brainstorming（设计头脑风暴）
**Socratic需求分析**

流程：
1. 提出问题，理解用户真正想要什么
2. 探索替代方案
3. 分段呈现设计供用户确认
4. 保存设计文档

触发词：
- "帮我分析需求"
- "设计一个系统"
- "我需要做XX，应该怎么做"

### test-driven-development（红绿重构TDD）
**强制测试先行**

规则：
1. RED：先写一个失败的测试
2. GREEN：写最少量代码让它通过
3. REFACTOR：重构代码，保持测试通过
4. 删除测试前写的任何代码

---

## 调用方式

```bash
# 注册新能力（用writing-skills方法论）
node /workspace/evolve/evolution-controller.js deploy <id> <name> <dna,comma> <score> <source>

# 运行完整进化周期（包含subagent-driven概念）
node /workspace/evolve/evolution-controller.js run-cycle

# 记录能力调用（用于OBSERVE）
node /workspace/evolve/evolution-controller.js --call <capability-id>

# 自我反思（brainstorming式分析）
node /workspace/evolve/evolution-controller.js reflect
```

---

## 进化模式配置

在 `evolution-controller.js` 里调整：
```js
CONFIG.evolution_mode = 'balanced' // balanced | aggressive | safe
```
- **balanced**：评分>=7自动通过
- **aggressive**：>=6.5就尝试集成
- **safe**：>=7.5才自动通过
