# Agency Multi-Agent System

> **MSOP Auto-Generated Skill** | Version: 1.0.0 | Score: 9.2  
> ID: `agency-multi-agent` | Source: [msitarzewski/agency-agents](https://github.com/msitarzewski/agency-agents)  
> Generated: 2026-03-30 | DNA: 7 capabilities

## 概述

65.5k星的多智能体AI团队系统，提供全套专业智能体（前端/后端/DevOps/AI/移动端/安全等），支持Claude Code/Cursor/Aider等工具集成。MIT许可，持续活跃更新（最后更新2026-03-27）。

**GitHub**: 65,565 Stars | License: MIT

## 🎯 核心能力（DNA）

- `multi-agent` — 多智能体协作架构
- `claude-integration` — Claude Code深度集成
- `cursor-integration` — Cursor IDE集成
- `agentic-ai` — 自主执行型AI Agent
- `devops-automation` — DevOps自动化
- `frontend-engineering` — 前端工程
- `backend-architecture` — 后端架构

## 📋 完整能力清单

- **multi-agent** — 多智能体系统
- **claude-integration** — Claude Code集成
- **cursor-integration** — Cursor集成
- **aider-integration** — Aider集成
- **frontend** — 前端开发
- **backend** — 后端开发
- **mobile** — 移动端开发
- **ai-ml** — AI/机器学习
- **devops** — DevOps自动化
- **security** — 安全专家
- **social-media** — 社媒运营
- **writing** — 专业写作
- **qa-testing** — QA测试
- **database** — 数据库管理
- **cloud** — 云工程
- **productivity** — 生产力工具

## 🤖 内置 Agent 类型

| Agent | 专长 | 使用场景 |
|-------|------|----------|
| Frontend Developer | React/Vue/Angular, UI, Core Web Vitals | 现代Web应用 |
| Backend Architect | API设计, 数据库, 可扩展性 | 服务端系统 |
| Mobile App Builder | iOS/Android, React Native, Flutter | 跨平台移动应用 |
| AI Engineer | ML模型, 部署, AI集成 | 机器学习流水线 |
| DevOps Automator | CI/CD, 基础设施自动化 | 持续交付 |
| Rapid Prototyper | 快速POC, MVP | Hackathon, 快速迭代 |
| Senior Developer | Laravel/Livewire, 高级模式 | 复杂架构 |
| Reddit Community Ninjas | 社区运营, 内容 | 社媒增长 |
| Reality Checkers | 质量审查, 把关 | 代码审查 |

## 🔧 支持工具

Claude Code · Cursor · Aider · Windsurf · Gemini CLI · OpenCode · Kimi Code

## 📂 安装使用

```bash
# 方式1：配合Claude Code使用
cp -r agency-agents/* ~/.claude/agents/
# "Hey Claude, activate Frontend Developer mode"

# 方式2：转换并安装
./scripts/convert.sh
./scripts/install.sh --tool cursor

# 方式3：直接参考
cat engineering/engineering-frontend-developer.md
```

## ⚠️ 当前状态

> ⚠️ Git clone 在本环境超时，Skill基于README静态分析生成。
> 待网络恢复后执行完整克隆 + 沙盒测试，再标记为 `deployed`。

## MSOP评分明细

| 维度 | 得分 | 说明 |
|------|------|------|
| Innovation | 9.5 | 开创性的multi-agent团队架构 |
| Integration | 8.5 | 支持6+工具链集成 |
| Gap Match | 8.0 | 覆盖工程全栈 |
| Popularity | 10 | 65.5k stars, 持续活跃 |
| Risk | 2 | MIT许可，低风险 |

**MSOP评分 = 9.2/10** | 审批结果: ✅ AUTO-APPROVED

## 回滚方法

```bash
rm -rf /workspace/evolve/skills/agency-multi-agent/
```
