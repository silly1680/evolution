# akshare Skill

## 描述
A股实时行情、财务数据、市场概况能力封装。填补 P0 能力缺口。

## 触发场景
- 用户询问"贵州茅台现在多少钱"
- 用户要求"查一下今日大盘"
- 用户要求"获取某某股票的财务数据"
- A股早报自动加入实时行情模块

## 使用前提
- Python venv 已就绪：`/workspace/evolve/venv`
- akshare 已安装

## 调用方式
```bash
# 激活环境（首次需运行）
# 之后直接调用：

# 获取个股行情
python3 /workspace/evolve/skills/akshare-skill.py --action stock_quote --symbol 600519

# 获取市场指数
python3 /workspace/evolve/skills/akshare-skill.py --action market_summary

# 获取指数行情
python3 /workspace/evolve/skills/akshare-skill.py --action index_quote --index 000001

# 获取个股财务报告
python3 /workspace/evolve/skills/akshare-skill.py --action financial_report --symbol 600519

# 生成个股简报
python3 /workspace/evolve/skills/akshare-skill.py --action brief --symbol 600519
```

## 性能指标
- 个股查询：< 2秒
- 市场指数：< 5秒
- 财务报告：< 15秒
- 降级方案：东方财富直连API，10秒超时
