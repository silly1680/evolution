#!/usr/bin/env python3
"""
crawl4ai_wrapper.py — AI优化网页爬虫（零依赖版）
用 BeautifulSoup 实现 crawl4ai 的核心能力：
  ① mainContentExtractor — 自动识别并提取网页主体内容
  ② removeNoise — 去除导航/广告/侧边栏
  ③ 多格式输出 — markdown / html / json / media
  ④ JS渲染支持 → 委托给 playwright-browser skill

使用方式:
  python3 crawl4ai_wrapper.py crawl "https://news.sina.com.cn"
  python3 crawl4ai_wrapper.py markdown "https://finance.sina.com.cn/stock/"
  python3 crawl4ai_wrapper.py extract "https://www.eastmoney.com" --query "A股"
  python3 crawl4ai_wrapper.py list-media "https://example.com"
"""
import sys, os, re, json, urllib.request, urllib.parse

# BeautifulSoup用于内容提取（尝试导入，失败则跳过高级功能）
try:
    from bs4 import BeautifulSoup
    BS4_OK = True
except ImportError:
    BS4_OK = False

# ===== 核心：正文提取 =====

class ContentExtractor:
    """AI风格的内容提取器"""

    # 噪音标签（广告/导航/脚注）
    NOISE_TAGS = {'script','style','nav','aside','footer','header','form',
                  'iframe','noscript','svg','button','input','select'}

    # 噪音class/id关键词
    NOISE_CLASSES = [
        'sidebar','nav','menu','footer','header','advertisement','ad-',
        'social','share','comment','related','recommended','popup','modal',
        'breadcrumb','pagination','tag','copyright','disclaimer','cookie',
        'banner','promo','sponsor','affiliate','popup','overlay'
    ]

    # 主体内容标签（优先）
    CONTENT_TAGS = {'article','main','section','div','td','blockquote'}

    def __init__(self, html, url=''):
        self.html = html
        self.url = url
        self.soup = None

    def parse(self):
        if not BS4_OK:
            print('⚠️ beautifulsoup4 未安装，内容提取可能不完整')
        self.soup = BeautifulSoup(self.html, 'html.parser') if BS4_OK else None
        return self

    def extract_main_content(self, min_length=200):
        """提取主内容，去噪音"""
        if not self.soup: self.parse()

        # 1. 尝试找 <article>
        article = self.soup.find('article') if self.soup else None
        if article and len(article.get_text()) > min_length:
            return self._clean_text(article)

        # 2. 找 main 标签
        main = self.soup.find('main') if self.soup else None
        if main and len(main.get_text()) > min_length:
            return self._clean_text(main)

        # 3. 找最大文本块
        best = None
        best_len = 0
        if self.soup:
            for tag in ['div','section','td']:
                for elem in self.soup.find_all(tag):
                    text = elem.get_text(strip=True)
                    if len(text) > best_len and 'class' not in str(elem.get('class','')):
                        best_len = len(text)
                        best = elem

        if best and best_len > min_length:
            return self._clean_text(best)

        # 4. 降级：直接取body
        if self.soup:
            body = self.soup.find('body')
            return self._clean_text(body) if body else self.html[:3000]
        return self.html[:3000]

    def _clean_text(self, elem):
        """清理元素文本"""
        # 去除噪音标签
        for tag in elem.find_all(self.NOISE_TAGS):
            tag.decompose()
        # 去除噪音class/id元素
        if BS4_OK:
            for noise_elem in elem.find_all(
                attrs={'class': lambda c: c and any(n in ' '.join(c).lower() for n in self.NOISE_CLASSES)}
            ):
                noise_elem.decompose()

        text = elem.get_text(separator='\n', strip=True)
        # 清理多余空行
        text = re.sub(r'\n{3,}', '\n\n', text)
        text = re.sub(r' {2,}', ' ', text)
        return text

    def extract_markdown(self):
        """转换为简化Markdown"""
        text = self.extract_main_content()
        # 标题
        text = re.sub(r'\n(.+?)\n=+\n', r'\n## \1\n', text)
        text = re.sub(r'\n(.+?)\n-+\n', r'\n### \1\n', text)
        # 链接保留文字
        if self.soup:
            for a in self.soup.find_all('a'):
                if a.get_text(strip=True):
                    pass  # 保留文字，去除href
        return text[:5000]

    def extract_json(self):
        """提取为结构化JSON"""
        if not self.soup: return {}
        result = {'url': self.url, 'title': '', 'text': '', 'links': [], 'images': []}
        # 标题
        title = self.soup.find('title')
        if title: result['title'] = title.get_text(strip=True)
        h1 = self.soup.find('h1')
        if h1: result['title'] = h1.get_text(strip=True)
        # 正文
        result['text'] = self.extract_main_content()[:3000]
        # 链接
        for a in self.soup.find_all('a', href=True)[:20]:
            href = a['href']
            if href.startswith('http'):
                result['links'].append({'text': a.get_text(strip=True)[:50], 'url': href})
        # 图片
        for img in self.soup.find_all('img', src=True)[:10]:
            src = img.get('src') or img.get('data-src','')
            if src.startswith('http'):
                result['images'].append(src)
        return result

    def extract_by_query(self, query):
        """AI风格：只返回与query最相关的段落"""
        text = self.extract_main_content()
        paragraphs = [p.strip() for p in text.split('\n') if len(p.strip()) > 30]
        if not paragraphs: return text

        # 简单关键词匹配打分
        q_words = set(query.lower().split())
        scored = []
        for p in paragraphs:
            p_lower = p.lower()
            score = sum(1 for w in q_words if w in p_lower)
            # 额外奖励：query词连续出现
            if query.lower() in p_lower: score += 2
            scored.append((score, p))
        scored.sort(key=lambda x: -x[0])
        top = scored[:5]
        if not top or top[0][0] == 0: return paragraphs[0]
        return '\n\n'.join([p for _,p in top])

    def list_media(self):
        """列出页面所有媒体"""
        if not self.soup: return []
        media = []
        for img in self.soup.find_all('img', src=True):
            src = img.get('src') or img.get('data-src','')
            if src.startswith('http') and len(src) > 10:
                media.append({'type':'image', 'url':src, 'alt': img.get('alt','')})
        for vid in self.soup.find_all('video', src=True):
            media.append({'type':'video', 'url':vid['src'], 'poster': vid.get('poster','')})
        return media

# ===== 爬取主函数 =====

def fetch_html(url, timeout=15):
    """下载网页HTML"""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    }
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        charset = 'utf-8'
        ct = resp.headers.get('Content-Type','')
        if 'charset=' in ct:
            charset = ct.split('charset=')[-1].split(';')[0].strip()
        return resp.read().decode(charset, errors='replace')

def crawl(url, output='markdown', query=None):
    """爬取网页"""
    print(f'🌐 正在抓取: {url}', file=sys.stderr)
    html = fetch_html(url)
    extractor = ContentExtractor(html, url)

    if output == 'markdown':
        return extractor.extract_markdown()
    elif output == 'html':
        return extractor.extract_main_content()
    elif output == 'json':
        return json.dumps(extractor.extract_json(), indent=2, ensure_ascii=False)
    elif output == 'query':
        return extractor.extract_by_query(query or '')
    elif output == 'media':
        return json.dumps(extractor.list_media(), indent=2, ensure_ascii=False)
    else:
        return extractor.extract_main_content()

# ===== 命令行入口 =====

def main():
    args = sys.argv[1:]
    if len(args) < 2:
        print(__doc__); sys.exit(1)

    cmd = args[0]
    url = args[1]
    output = 'markdown'
    query = None

    if '--format' in args:
        output = args[args.index('--format') + 1]
    if '--query' in args:
        query = args[args.index('--query') + 1]

    try:
        result = crawl(url, output=output, query=query)
        print(result)
    except Exception as e:
        print(f'❌ 爬取失败: {e}', file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    main()
