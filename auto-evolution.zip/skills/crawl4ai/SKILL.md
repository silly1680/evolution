# Crawl4ai — AI优化网页爬虫

> **MSOP AUTO-GENERATED** | Score: 7.3 | APPROVAL: ✅ AUTO-APPROVED  
> ID: `crawl4ai` | Source: MSOP自主构建（BeautifulSoup + playwright集成）  
> Generated: 2026-03-30 | DNA: `web-crawl`, `content-extraction`, `js-render`, `ai-scrape`  
> 安装: **零依赖**（beautifulsoup4可选，urllib内置；JS渲染委托playwright-browser）

## 概述

AI优化的智能网页爬虫，实现crawl4ai的核心能力：
- 🧠 **AI风格正文提取** — 自动识别网页主体，去除导航/广告/侧边栏
- 📊 **多格式输出** — markdown / html / json / media列表
- 🔍 **Query相关过滤** — 只返回与查询最相关的段落
- 🌐 **JS渲染支持** — 动态页面委托playwright-browser skill
- ⚡ **比requests更智能** — 自动识别正文vs噪音

## 安装

```bash
# 可选beautifulsoup4（更好的解析）
pip install beautifulsoup4

# 直接使用，无需安装
cp /workspace/evolve/skills/crawl4ai/crawl4ai_wrapper.py ./
```

## 使用方式

### 基本爬取
```bash
# 获取网页markdown（去噪音）
python3 crawl4ai_wrapper.py crawl "https://finance.sina.com.cn/stock/"

# 获取JSON结构（含标题、链接、图片）
python3 crawl4ai_wrapper.py extract "https://www.eastmoney.com" --format json
```

### 智能查询模式
```bash
# AI风格：只返回与"A股"最相关的段落
python3 crawl4ai_wrapper.py extract "https://finance.sina.com.cn" --query "A股"
```

### JS渲染页面（配合playwright）
```bash
# playwright处理动态页面
openclaw browser snapshot --url "https://www.eastmoney.com/center/" --profile openclaw

# crawl4ai提取正文
python3 crawl4ai_wrapper.py markdown /path/to/snapshot.html
```

## 适用场景

| 场景 | 工具组合 | 说明 |
|------|---------|------|
| 东方财富资讯 | crawl4ai | 静态页面，直接抓取 |
| 同花顺动态内容 | playwright + crawl4ai | JS渲染后提取 |
| 新浪财经新闻 | crawl4ai | markdown格式，插入早报 |
| 证监会公告 | crawl4ai | JSON结构化，利于后处理 |

## 在A股早报中集成

```python
from crawl4ai_wrapper import crawl

# 抓取昨夜重要财经新闻
news_urls = [
    "https://finance.sina.com.cn/mac/",
    "https://www.yicai.com/news",
]
headlines = []
for url in news_urls:
    try:
        md = crawl(url, output="markdown")
        paras = [p for p in md.split('\n') if len(p) > 50][:3]
        headlines.extend(paras)
    except: pass

print("昨夜财经要闻:")
for h in headlines[:5]:
    print(f"  • {h[:100]}")
```

## MSOP评分

| 维度 | 得分 | 说明 |
|------|------|------|
| Innovation | 7.5 | AI风格正文识别，零依赖实现 |
| Integration | 8.5 | 与playwright/tavily/akshare全链路联动 |
| Gap Match | 8.0 | 填补P1缺口：智能爬虫能力 |
| Popularity | 7.0 | 爬虫是数据获取基础能力 |
| Risk | 2.0 | 纯读操作，有robots.txt检查 |

**MSOP评分 = 7.3/10**

## DNA 能力标签

```
web-crawl → content-extraction → js-render → ai-scrape → data-pipeline
```

## 回滚

```bash
rm -rf /workspace/evolve/skills/crawl4ai/
```
