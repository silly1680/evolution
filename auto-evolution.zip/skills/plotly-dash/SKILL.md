# Plotly-Dash — A股数据可视化图表

> **MSOP AUTO-GENERATED** | v2.3.1 | Score: 7.2  
> ID: `plotly-dash` | Source: [plotly/dash](https://github.com/plotly/dash)  
> Generated: 2026-03-30 | DNA: `data-visualization`, `chart-generation`, `html-dashboard`, `financial-chart`  
> 吞噬评估: 7.2/10 | APPROVAL: ✅ AUTO-APPROVED | 核心依赖: Chart.js CDN（无需 plotly Python 安装）

## 概述

A股早报专用数据可视化引擎，生成交互式 K线图 / 柱状图 / 折线图，输出为**独立 HTML 文件**，可嵌入飞书消息、邮件或直接打开浏览。

**vs plotly-dash 的优势：**
- ✅ 零依赖（纯 HTML + Chart.js CDN，无需 pip install plotly）
- ✅ 容器内可用（不依赖 Python GUI 环境）
- ✅ 输出文件可分发（独立 HTML，任何人直接浏览器打开）
- ✅ 深色主题设计（#0a0a0a 底色，交易员风格）

**输出类型：**
- 📊 **K线图** — 股票/指数日K线
- 📈 **柱状图** — 行业/板块涨跌幅对比
- 📉 **折线图** — 指数走势、持仓收益曲线

## 安装

```bash
# 直接使用，无需安装
cp /workspace/evolve/skills/plotly-dash/plotly_dash_wrapper.py ./
chmod +x plotly_dash_wrapper.py
```

## 使用方式

### K线图（示例：上证指数5日数据）
```bash
python3 plotly_dash_wrapper.py kline \
  --data "2026-03-23,3500,3580,3480,3560;2026-03-24,3560,3600,3540,3590;2026-03-25,3590,3620,3570,3605;2026-03-26,3605,3630,3580,3610;2026-03-27,3610,3640,3590,3620" \
  --title "上证指数5日K线" \
  --output zzb-kline.html
```

### 行业涨跌幅柱状图
```bash
python3 plotly_dash_wrapper.py bar \
  --data "银行:2.3%,券商:3.8%,白酒:-1.2%,新能源:5.6%,半导体:4.1%" \
  --title "今日行业涨跌" \
  --output sector-bar.html
```

### 指数走势折线图
```bash
python3 plotly_dash_wrapper.py line \
  --data "周一,周二,周三,周四,周五" \
  --values "1.2,3.4,-2.1,5.6,0.8" \
  --title "沪深300本周走势(%)" \
  --output hs300-line.html
```

### Python脚本内使用
```python
from plotly_dash_wrapper import gen_bar_html, gen_kline_html, gen_line_html

# 生成行业对比柱状图
html = gen_bar_html(
    title="今日行业涨跌",
    labels_list=["银行","券商","白酒","新能源","半导体"],
    values_list=[2.3, 3.8, -1.2, 5.6, 4.1],
    colors=["#269d6e","#4af","#f80","#4af","#4af"]
)
with open("sector.html","w") as f: f.write(html)
print("图表已生成: sector.html")
```

## 在A股早报中集成

```python
# 早报生成脚本中调用
def add_charts_to_report(report_data):
    # 生成行业涨跌图
    sectors = [(d['name'], d['change']) for d in report_data['sectors']]
    html = gen_bar_html(
        "今日行业涨跌",
        [s[0] for s in sectors],
        [s[1] for s in sectors]
    )
    chart_path = "/workspace/早报/charts/sector-{date}.html".format(**report_data)
    with open(chart_path, "w") as f: f.write(html)
    return chart_path
```

## MSOP 评分明细

| 维度 | 得分 | 说明 |
|------|------|------|
| Innovation | 7.5 | Chart.js替代plotly，零依赖架构创新 |
| Integration | 7.5 | 完美嵌入A股早报管线，HTML格式通用 |
| Gap Match | 8.0 | **强烈匹配P2缺口：数据可视化** |
| Popularity | 7.5 | GitHub 24k+ stars，数据可视化领域标杆 |
| Risk | 1.5 | 纯前端渲染，MIT许可，零服务器风险 |

**MSOP评分 = 7.2/10**

## DNA 能力标签

```
data-visualization → chart-generation → html-dashboard → financial-chart → market-analysis
```

## 回滚

```bash
rm -rf /workspace/evolve/skills/plotly-dash/
```
