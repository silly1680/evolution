#!/usr/bin/env python3
"""
plotly_dash_wrapper.py — A股图表生成器
使用 Chart.js 渲染交互式K线/柱状/折线图，输出单个HTML文件
纯Python标准库（urllib除外）+ Chart.js CDN，无需安装plotly/dash

用法:
  python3 plotly_dash_wrapper.py kline  --data "上证指数,3500,3600,3450,3580" --output kline.html
  python3 plotly_dash_wrapper.py bar   --data "沪深300:5.2%,中证500:3.8%,创业板:2.1%" --output bar.html
  python3 plotly_dash_wrapper.py line  --data "周一,周二,周三,周四,周五" --values "1.2,3.4,-2.1,5.6,0.8" --output line.html
"""
import json, sys, os, urllib.request
from datetime import datetime

CHART_CDN = "https://cdn.jsdelivr.net/npm/chartify@1.0.0/dist/chart.umd.min.js"
CHART_CSS = "https://cdn.jsdelivr.net/npm/chartify@1.0.0/dist/chart.min.css"

def require_internet():
    """检查网络（可选，CDN加载需要）"""
    try:
        req = urllib.request.Request(CHART_CDN, headers={'User-Agent':'Mozilla/5.0'})
        urllib.request.urlopen(req, timeout=5)
        return True
    except:
        return False

def gen_kline_html(title, dates, opens, highs, lows, closes):
    """生成K线图HTML"""
    data_js = f"const labels={json.dumps(dates)};"
    candle_data = json.dumps([{"o":o,"h":h,"l":l,"c":c} for o,h,l,c in zip(opens,highs,lows,closes)])
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>{title}</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
  body{{font-family:Arial,Microsoft YaHei;background:#0a0a0a;color:#e0e0e0;padding:20px;}}
  .header{{text-align:center;margin-bottom:20px;}}
  .chart-wrap{{max-width:900px;margin:0 auto;background:#111;border-radius:12px;padding:16px;}}
  .caption{{text-align:center;color:#888;font-size:12px;margin-top:8px;}}
</style></head><body>
<div class="header"><h2>{title}</h2><span style="color:#888">{datetime.now().strftime('%Y-%m-%d %H:%M')}</span></div>
<div class="chart-wrap"><canvas id="kline"></canvas></div>
<p class="caption">数据来源: A股早报系统 | Chart.js渲染</p>
<script>
{data_js}
const candles = {candle_data};
const ctx = document.getElementById('kline').getContext('2d');
const up = closes.map((c,i)=>c>=opens[i]?'rgba(239,83,80,0.8)':'rgba(38,157,110,0.8)');
const shadow = closes.map((c,i)=>c>=opens[i]?'rgba(239,83,80,0.5)':'rgba(38,157,110,0.5)');

const config = {{
  type:'bar',
  data:{{
    labels,
    datasets:[{{
      label:'K线',
      data: candles.map(d=>({{x:d.x||labels[candles.indexOf(d)],y:[d.o,d.h,d.l,d.c]}})),
      candleData: candles,
      backgroundColor: up,
      borderColor: shadow,
      borderWidth:1,
    }}]
  }},
  options:{{
    responsive:true,
    scales:{{
      x:{{type:'category',grid:{{color:'#222'},ticks:{{color:'#888'}}}},
      y:{{grid:{{color:'#222'},ticks:{{color:'#888'}}}}
    }},
    plugins:{{legend:{{display:false}}}}
  }}
}};
// 简化K线用折线+颜色分段代替
new Chart(ctx, {{
  type:'line',
  data:{{
    labels,
    datasets:[{{
      label:'收盘价',
      data:{json.dumps(closes)},
      borderColor:'#4af',
      backgroundColor:'rgba(68,170,255,0.1)',
      fill:true,
      tension:0.3,
      pointBackgroundColor: closes.map((c,i)=>c>=opens[i]?'#ef5350':'#269d6e'),
    }}]
  }},
  options:{{
    responsive:true,
    plugins:{{legend:{{display:false}},tooltip:{{mode:'index',intersect:false}}}},
    scales:{{
      x:{{grid:{{color:'#222'},ticks:{{color:'#888'}}}},
      y:{{grid:{{color:'#333'},ticks:{{color:'#888'}}}}
    }}
  }}
}});
</script></body></html>"""

def gen_bar_html(title, labels_list, values_list, colors=None):
    """生成柱状图HTML"""
    colors = colors or ['#4af','#269d6e','#f80','#ff6b6b','#ffd93d','#6bcb77','#4d96ff']
    n = len(labels_list)
    bc = [colors[i % len(colors)] for i in range(n)]
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>{title}</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
  body{{font-family:Arial,Microsoft YaHei;background:#0a0a0a;color:#e0e0e0;padding:20px;}}
  .header{{text-align:center;margin-bottom:20px;}}
  .chart-wrap{{max-width:700px;margin:0 auto;background:#111;border-radius:12px;padding:16px;}}
  .caption{{text-align:center;color:#555;font-size:12px;margin-top:8px;}}
</style></head><body>
<div class="header"><h2>{title}</h2></div>
<div class="chart-wrap">
<canvas id="bar"></canvas>
</div>
<p class="caption">A股早报系统 | {datetime.now().strftime('%Y-%m-%d')}</p>
<script>
new Chart(document.getElementById('bar').getContext('2d'),{{
  type:'bar',
  data:{{
    labels:{json.dumps(labels_list)},
    datasets:[{{
      label:'{title}',
      data:{json.dumps(values_list)},
      backgroundColor:{json.dumps(bc)},
      borderRadius:6,
      borderSkipped:false,
    }}]
  }},
  options:{{
    indexAxis:'y',
    responsive:true,
    plugins:{{legend:{{display:false}},tooltip:{{callbacks:{{
      label:ctx=>ctx.raw+'%'
    }}}}},
    scales:{{
      x:{{grid:{{color:'#222'},ticks:{{color:'#888'}}}},
      y:{{grid:{{display:false},ticks:{{color:'#ccc'}}}}
    }}
  }}
}});
</script></body></html>"""

def gen_line_html(title, labels_list, values_list, color='#4af'):
    """生成折线图HTML"""
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>{title}</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
  body{{font-family:Arial,Microsoft YaHei;background:#0a0a0a;color:#e0e0e0;padding:20px;}}
  .header{{text-align:center;margin-bottom:20px;}}
  .chart-wrap{{max-width:800px;margin:0 auto;background:#111;border-radius:12px;padding:16px;}}
</style></head><body>
<div class="header"><h2>{title}</h2><span style="color:#888">{datetime.now().strftime('%Y-%m-%d')}</span></div>
<div class="chart-wrap"><canvas id="line"></canvas></div>
<script>
new Chart(document.getElementById('line').getContext('2d'),{{
  type:'line',
  data:{{
    labels:{json.dumps(labels_list)},
    datasets:[{{
      label:'{title}',
      data:{json.dumps(values_list)},
      borderColor:'{color}',
      backgroundColor:'rgba(68,170,255,0.1)',
      fill:true,tension:0.4,pointRadius:4,pointBackgroundColor:'{color}',
    }}]
  }},
  options:{{
    responsive:true,
    plugins:{{legend:{{display:false}}}},
    scales:{{
      x:{{grid:{{color:'#222'},ticks:{{color:'#888'}}}},
      y:{{grid:{{color:'#333'},ticks:{{color:'#888'}}}}
    }}
  }}
}});
</script></body></html>"""

# ===== 命令行入口 =====
def main():
    args = sys.argv[1:]
    if len(args) < 2 or args[0] not in ('kline','bar','line'):
        print(__doc__)
        sys.exit(1)

    chart_type = args[0]
    output = 'chart.html'
    title = 'A股数据'

    if '--output' in args:
        idx = args.index('--output')
        output = args[idx+1]
    if '--title' in args:
        idx = args.index('--title')
        title = args[idx+1]

    if chart_type == 'kline':
        # --data "日期,开,高,低,收;..."
        raw = next((a for i,a in enumerate(args) if i>0 and not a.startswith('-')),'')
        rows = [r.split(',') for r in raw.split(';') if r]
        dates,opens,highs,lows,closes = [],[],[],[],[]
        for r in rows:
            if len(r)==5: dates.append(r[0]);opens.append(float(r[1]));highs.append(float(r[2]));lows.append(float(r[3]));closes.append(float(r[4]))
        html = gen_kline_html(title, dates, opens, highs, lows, closes)

    elif chart_type == 'bar':
        # --data "标签1:数值1,标签2:数值2,..."
        raw = next((a for i,a in enumerate(args) if i>0 and not a.startswith('-')),'')
        items = [r.split(':') for r in raw.split(',') if r and ':' in r]
        labels_v, values_v = [i[0].strip() for i in items], [float(i[1].replace('%','')) for i in items]
        html = gen_bar_html(title, labels_v, values_v)

    elif chart_type == 'line':
        raw_d = next((args[i+1] for i,a in enumerate(args) if a=='--data' and i+1<len(args)),'')
        raw_v = next((args[i+1] for i,a in enumerate(args) if a=='--values' and i+1<len(args)),'')
        labels_v = [x.strip() for x in raw_d.split(',')]
        values_v = [float(x.strip()) for x in raw_v.split(',')]
        html = gen_line_html(title, labels_v, values_v)

    with open(output, 'w', encoding='utf-8') as f:
        f.write(html)
    print(f'✅ 图表已生成: {output}')

if __name__ == '__main__':
    main()
