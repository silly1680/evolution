# OpenClaw 能力基因组 v2.0
# 更新于 2026-03-28 18:46 — 第二次进化周期

---

## 📌 已有能力（已内化·活性）

### 🔴 核心能力
| DNA | 能力名 | 描述 | 置信度 | 价值分 |
|-----|--------|------|--------|--------|
| a-stock-report | A股早报生成 | 每日市场综述，12模块完整版 | ★★★★★ | 3.1 |
| github-trending-push | GitHub Trending推送 | 每日9:00飞书群推送 | ★★★★★ | — |
| feishu-doc | 飞书文档读写 | 创建/编辑/上传飞书文档 | ★★★★★ | — |
| fin-data | **akshare金融数据** | 实时行情/财务数据/指数/个股 | ★★★★☆ | 3.1 |
| writing-skills | **Superpowers写作方法论** | Skill编写最佳实践+测试方法 | ★★★★☆ | 0(新) |
| subagent-driven | **Subagent驱动开发** | 多Agent并行任务+两阶段评审 | ★★★★☆ | 0(新) |
| brainstorming | **Brainstorming** | Socratic需求分析+设计验证 | ★★★☆☆ | 0(新) |
| systematic-debug | **系统性调试** | 4步根因分析+防御性编程 | ★★★☆☆ | 0(新) |
| tdd | **测试驱动开发** | 红绿重构TDD循环 | ★★★☆☆ | 0(新) |
| web-search | 网页搜索 | batch_web_search精准搜索 | ★★★★★ | — |
| web-extract | 网页内容提取 | extract_content_from_websites | ★★★★★ | — |
| image-gen | 图像生成 | image_synthesize多风格 | ★★★★☆ | — |
| video-gen | 视频生成 | gen_videos文生视频/图生视频 | ★★★★☆ | — |
| code-write | 代码编写 | 任何语言/框架 | ★★★★☆ | — |
| cron-schedule | 定时调度 | cron任务创建/管理 | ★★★★☆ | — |
| memory-manage | 记忆管理 | MEMORY.md / daily notes | ★★★★☆ | — |

### 🟡 扩展能力（已安装Skill）
| DNA | 能力名 | 描述 | 状态 |
|-----|--------|------|------|
| tencent-docs | 腾讯文档 | 读写腾讯文档/智能表格 | skill已装 |
| find-skills | 技能发现 | clawhub搜索生态 | skill已装 |
| self-improve | 自我改进 | 错误日志/纠正追踪 | skill已装 |
| automation-workflow | 自动化设计 | 识别和构建工作流 | skill已装 |
| cron-mastery | 定时大师 | cron/heartbeat优化 | skill已装 |

---

## 📌 目标能力（尚未拥有）

| 优先级 | DNA | 能力名 | 缺口来源 | 状态 |
|--------|-----|--------|----------|------|
| P0 | browser-auto | 浏览器自动化 | playwright/DrissionPage | 缺失 |
| P0 | voice-asr | 语音识别 | faster-whisper | 缺失 |
| P1 | notion-docs | Notion文档 | notion-sdk-py | 缺失 |
| P1 | db-query | 数据库查询 | SQLite/PostgreSQL | 缺失 |
| P2 | multi-agent-orch | 多智能体编排 | crewai/autogen | 已有基础 |

---

## 📌 能力雷达图（1-10）

```
信息获取：██████████ 10/10  （搜索/抓取/akshare/订阅）
内容生产：██████████ 10/10  （早报/报告/代码/Skill编写）
跨端分发：████████░░  8/10  （飞书/群聊/文档）
多媒体  ：████████░░  8/10  （图像/视频/音频）
数据计算：███████░░░  7/10  （akshare实时行情 ✅新增）
知识管理：██████░░░░  6/10  （MEMORY+文件+Superpowers方法论）
自动进化：███████░░░  7/10  （MSOP状态机+价值评估 ✅升级）
```

---

## 📌 进化历史

| 日期 | 获得能力 | 来源 | 评分 | 价值分 |
|------|----------|------|------|--------|
| 2026-02-25 | 飞书集成 | 初始配置 | — | — |
| 2026-03-15 | A股早报 | 手动构建 | 8.5 | 3.1 |
| 2026-03-17 | 飞书文档推送 | 集成开发 | 9.0 | — |
| 2026-03-26 | GitHub Trending推送 | cron+脚本 | 8.0 | — |
| 2026-03-28 | akshare金融数据 | 猎物扫描+吞噬 | 7.1 | 3.1 |
| 2026-03-28 | Superpowers核心包 | 猎物扫描+吞噬 | **8.2** | 0(新) |

---

## 📌 Superpowers 进化洞察

###obra/superpowers 核心收获
- **评分**: 8.2/10（119k⭐, MIT, 直接匹配技能自生成）
- **最重要技能**: `writing-skills` — 教你如何写Skill的方法论
- **第二技能**: `subagent-driven-development` — 多Agent任务分派+评审
- **第三技能**: `systematic-debugging` — 4步根因分析法

### 对我的改变
之前写Skill：手动→靠经验→可能出错
现在写Skill：**Superpowers writing-skills方法论 → 结构化→可测试→可复制**
