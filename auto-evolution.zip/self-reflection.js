/**
 * MSOP Self-Reflection Module
 * 定期评估能力是否真正提升系统
 */
const fs = require('fs');
const path = require('path');

const WORKSPACE = '/workspace/evolve';
const REGISTRY_FILE = path.join(WORKSPACE, 'capability-registry.json');
const REFLECTION_LOG = path.join(WORKSPACE, 'self-reflection-log.json');
const OBSERVATION_LOG = path.join(WORKSPACE, 'observation-log.json');
const STRATEGY_FILE = path.join(WORKSPACE, 'evolution-strategy.json');

function loadRegistry() {
  return JSON.parse(fs.readFileSync(REGISTRY_FILE, 'utf-8'));
}

function loadReflectionLog() {
  if (!fs.existsSync(REFLECTION_LOG)) return [];
  return JSON.parse(fs.readFileSync(REFLECTION_LOG, 'utf-8'));
}

function saveReflectionLog(log) {
  fs.writeFileSync(REFLECTION_LOG, JSON.stringify(log, null, 2), 'utf-8');
}

function loadObservationLog() {
  if (!fs.existsSync(OBSERVATION_LOG)) return [];
  return JSON.parse(fs.readFileSync(OBSERVATION_LOG, 'utf-8'));
}

function loadStrategy() {
  if (!fs.existsSync(STRATEGY_FILE)) return {};
  return JSON.parse(fs.readFileSync(STRATEGY_FILE, 'utf-8'));
}

function analyzeCapabilityHealth(cap) {
  const s = cap.stats || {};
  const calls = s.calls || 0;
  const rate = s.successRate || 0;
  const time = s.avgTime || 0;
  const vs = cap.valueScore || 0;
  let health = 'healthy';
  let verdict = '';
  let suggestion = '';
  if (calls === 0) {
    health = 'dormant';
    verdict = '从未被调用，可能不是当前真正需要的';
    suggestion = '降权或重新评估其价值';
  } else if (rate < 0.5) {
    health = 'failing';
    verdict = '成功率仅' + (rate * 100).toFixed(0) + '%，故障率偏高';
    suggestion = '需排查错误原因或降级处理';
  } else if (time > 30) {
    health = 'slow';
    verdict = '平均耗时' + time.toFixed(1) + '秒，体验较差';
    suggestion = '优化性能或考虑替代方案';
  } else if (vs > 5) {
    health = 'thriving';
    verdict = '价值分' + vs + '，高效且高频';
    suggestion = '持续保持，可考虑扩展使用场景';
  } else if (vs < 2 && calls > 3) {
    health = 'low-value';
    verdict = '价值分' + vs + '低于2，调用多但得分低';
    suggestion = '考虑优化或淘汰';
  } else {
    verdict = '运行正常，价值分' + vs;
    suggestion = '保持监控';
  }
  return { health, verdict, suggestion };
}

function generateReflectionReport() {
  const registry = loadRegistry();
  const observations = loadObservationLog();
  const strategy = loadStrategy();
  const timestamp = new Date().toISOString();
  const today = timestamp.slice(0, 10);
  const caps = Object.values(registry);
  const activeCaps = caps.filter(c => c.status === 'active');
  const healthStats = { healthy: 0, thriving: 0, dormant: 0, failing: 0, slow: 0, low_value: 0 };
  const capHealth = activeCaps.map(c => {
    const h = analyzeCapabilityHealth(c);
    healthStats[h.health]++;
    return { id: c.id, name: c.name, ...h, stats: c.stats, valueScore: c.valueScore || 0 };
  });

  const cutoff24h = new Date(Date.now() - 24 * 3600 * 1000).toISOString();
  const recentObs = observations.filter(o => o.timestamp > cutoff24h);

  const allDna = activeCaps.flatMap(c => c.dna || []);
  const dnaFreq = {};
  allDna.forEach(d => { dnaFreq[d] = (dnaFreq[d] || 0) + 1; });
  const topDna = Object.entries(dnaFreq).sort((a, b) => b[1] - a[1]).slice(0, 10);

  const newCaps = activeCaps.filter(c => {
    const deployed = new Date(c.deployedAt || 0);
    return (Date.now() - deployed.getTime()) / (1000 * 3600 * 24) <= 7;
  });
  const matureCaps = activeCaps.filter(c => {
    const deployed = new Date(c.deployedAt || 0);
    return (Date.now() - deployed.getTime()) / (1000 * 3600 * 24) > 7;
  });
  const avgNewScore = newCaps.length > 0
    ? newCaps.reduce((s, c) => s + (c.valueScore || 0), 0) / newCaps.length : 0;
  const avgMatureScore = matureCaps.length > 0
    ? matureCaps.reduce((s, c) => s + (c.valueScore || 0), 0) / matureCaps.length : 0;

  const dnaGaps = [];
  const allDnaSet = new Set(allDna);
  if (!allDnaSet.has('agentic') && !allDnaSet.has('multi-agent')) {
    dnaGaps.push({ dna: 'agentic', reason: '自主执行型Agent是AI发展的核心方向' });
  }
  if (!allDnaSet.has('rag')) {
    dnaGaps.push({ dna: 'rag', reason: 'RAG知识库能力可大幅提升问答质量' });
  }
  if (!allDnaSet.has('code-execution')) {
    dnaGaps.push({ dna: 'code-execution', reason: '代码执行能力是自动化编程的基础' });
  }

  const toRetire = capHealth.filter(c => c.health === 'dormant' || c.health === 'low_value');
  const insights = [];
  if (activeCaps.length < 5) insights.push('能力库规模较小，建议优先积累核心能力');
  if (recentObs.length > 50) insights.push('最近24小时有' + recentObs.length + '次调用，系统活跃度高');
  if (avgMatureScore > avgNewScore * 1.5) insights.push('老能力仍是核心支柱，新能力需要时间证明价值');
  if (healthStats.dormant > activeCaps.length * 0.3) insights.push('超过30%能力处于沉睡状态，建议精简');
  if (topDna.length > 0 && topDna[0][1] >= 3) insights.push('DNA核心: ' + topDna[0][0] + ' 出现' + topDna[0][1] + '次');
  if (insights.length === 0) insights.push('系统运行平稳，持续监控即可');

  const mode = strategy.current_mode || 'balanced';
  const phase = strategy.current_phase || 'phase_1';

  const report = [];
  report.push('# Self-Reflection Report | ' + today + ' | ' + mode.toUpperCase() + ' / ' + phase);
  report.push('');
  report.push('## 1. 能力健康度 (' + activeCaps.length + '个活跃)');
  const emojiMap = { thriving: 'G', healthy: 'Y', dormant: 'B', slow: 'O', failing: 'R', low_value: 'K' };
  for (const [h, label] of [['thriving', 'Thriving'], ['healthy', 'Healthy'], ['dormant', 'Dormant'], ['slow', 'Slow'], ['failing', 'Failing'], ['low_value', 'Low-Value']]) {
    const cnt = healthStats[h] || 0;
    if (cnt > 0) report.push('- ' + emojiMap[h] + ' ' + label + ': ' + cnt + '个');
  }
  report.push('');
  capHealth.forEach(c => {
    const e = emojiMap[c.health] || '?';
    report.push('  [' + e + '] ' + c.name + ' (value=' + c.valueScore + ') - ' + c.verdict);
  });
  report.push('');
  report.push('## 2. 新旧能力对比 (7天分水岭)');
  report.push('- New: ' + newCaps.length + ' caps, avg score=' + avgNewScore.toFixed(2));
  report.push('- Mature: ' + matureCaps.length + ' caps, avg score=' + avgMatureScore.toFixed(2));
  if (newCaps.length > 0 && matureCaps.length > 0) {
    if (avgNewScore > avgMatureScore) report.push('- Insight: 新能力表现优于老能力，方向正确');
    else if (avgNewScore < avgMatureScore * 0.7) report.push('- Warning: 新能力价值明显低于老能力');
  }
  report.push('');
  report.push('## 3. DNA覆盖 (Top 5)');
  topDna.forEach(function(d) { report.push('- ' + d[0] + ': ' + d[1] + 'x'); });
  report.push('');
  if (dnaGaps.length > 0) {
    report.push('## 4. DNA进化机会');
    dnaGaps.forEach(function(g) { report.push('- ' + g.dna + ': ' + g.reason); });
    report.push('');
  }
  report.push('## 5. 淘汰建议');
  if (toRetire.length > 0) {
    toRetire.forEach(function(c) { report.push('- ' + c.name + ': ' + c.verdict + ' -> ' + c.suggestion); });
  } else {
    report.push('(无需要淘汰的能力)');
  }
  report.push('');
  report.push('## 6. 核心洞察');
  insights.forEach(function(i) { report.push('- ' + i); });

  const fullReport = report.join('\n');
  console.log(fullReport);

  const log = loadReflectionLog();
  log.unshift({
    timestamp, today, mode, phase,
    activeCaps: activeCaps.length,
    healthStats,
    avgNewScore: +avgNewScore.toFixed(3),
    avgMatureScore: +avgMatureScore.toFixed(3),
    topDna: topDna.slice(0, 5),
    toRetire: toRetire.map(function(c) { return c.id; }),
    insights: insights,
  });
  if (log.length > 100) log.splice(100);
  saveReflectionLog(log);

  return { timestamp, mode, phase, activeCaps: activeCaps.length, healthStats, insights };
}

module.exports = { generateReflectionReport, analyzeCapabilityHealth };

if (require.main === module) {
  var args = process.argv.slice(2);
  if (args[0] === 'run' || !args[0]) {
    console.log('\nSelf-Reflection running...\n');
    generateReflectionReport();
  } else if (args[0] === 'history') {
    var log = loadReflectionLog();
    console.log('\nHistory (' + log.length + ' entries):');
    log.slice(0, 10).forEach(function(e) {
      console.log('  [' + e.today + '] ' + e.mode + '/' + e.phase + ' caps=' + e.activeCaps + ' ' + JSON.stringify(e.healthStats));
    });
  } else if (args[0] === 'health') {
    var registry = loadRegistry();
    console.log('\nCapability Health:');
    Object.values(registry).filter(function(c) { return c.status === 'active'; }).forEach(function(c) {
      var h = analyzeCapabilityHealth(c);
      console.log('  [' + h.health + '] ' + c.name + ': ' + h.verdict);
    });
  } else {
    console.log('Usage: node self-reflection.js [run|history|health]');
  }
}
