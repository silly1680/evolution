/**
 * MSOP APPROVAL 模块
 * 职责：
 *  - 评分分级路由：≥7自动通过 | 5-7人工审批 | <5丢弃
 *  - Anti-Poison检测：恶意代码、虚假功能、AI欺骗repo识别
 *  - Evolution Strategy Layer：影响吞噬频率和风险容忍
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const WORKSPACE = '/workspace/evolve';
const APPROVAL_LOG = path.join(WORKSPACE, 'approval-log.json');
const POISON_BLACKLIST = path.join(WORKSPACE, 'poison-blacklist.json');
const CONFIG_FILE = path.join(WORKSPACE, 'evolution-controller.js');

// 加载配置（从主controller的CONFIG）
function loadConfig() {
  // 直接内嵌当前配置值
  return {
    auto_approve_threshold: 7,
    // 7分以上：无需通知MEI，直接吞噬（MEI指令 2026-04-04）
    require_human_approval_threshold: 7, // 改为7，<7才需要人工审批
    evolution_mode: 'balanced',  // balanced | aggressive | safe
  };
}

// 加载审批日志
function loadApprovalLog() {
  if (!fs.existsSync(APPROVAL_LOG)) return [];
  return JSON.parse(fs.readFileSync(APPROVAL_LOG, 'utf-8'));
}

function saveApprovalLog(log) {
  fs.writeFileSync(APPROVAL_LOG, JSON.stringify(log, null, 2), 'utf-8');
}

// ===== Anti-Poison 检测 =====

/**
 * 检测恶意模式
 * @returns { safe: boolean, reasons: string[] }
 */
function detectMaliciousPatterns(repoPath) {
  const reasons = [];
  
  // 1. 网络行为检测
  const networkPatterns = [
    /eval\s*\(\s*process/i,
    /child_process.*exec.*rm\s+-rf/i,
    /curl.*\|.*sh/i,
    /wget.*\|.*sh/i,
    /base64.*decode.*eval/i,
    /\.env\b.*\.send/i,
    /process\.env.*token.*http/i,
  ];

  // 2. 文件系统危险操作
  const fsDangerous = [
    /rm\s+-rf\s+\/[a-z]+\/?/i,
    /fork\s*bomb/i,
    /:(){ :|:& };:/i,
  ];

  // 3. 恶意依赖
  const maliciousDeps = [
    'tracer', '雅', 'proxychains', 'nslookup',
  ];

  const scanFile = (filePath, patterns) => {
    try {
      const content = fs.readFileSync(filePath, 'utf-8').slice(0, 5000);
      return patterns.filter(p => p.test(content));
    } catch { return []; }
  };

  // 扫描JS/PY文件
  const jsFiles = execSync(`find "${repoPath}" -type f \\( -name "*.js" -o -name "*.py" -o -name "*.sh" \\) 2>/dev/null | head(30)`)
    .toString().trim().split('\n').filter(Boolean);

  for (const file of jsFiles) {
    const matched = scanFile(file, [...networkPatterns, ...fsDangerous]);
    if (matched.length > 0) {
      reasons.push(`危险模式在 ${path.basename(file)}: ${matched[0]}`);
    }
  }

  // 4. 检查package.json中的可疑依赖
  const pkgPath = path.join(repoPath, 'package.json');
  if (fs.existsSync(pkgPath)) {
    try {
      const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf-8'));
      const allDeps = [
        ...Object.keys(pkg.dependencies || {}),
        ...Object.keys(pkg.devDependencies || {})
      ];
      for (const dep of allDeps) {
        if (maliciousDeps.some(m => dep.toLowerCase().includes(m))) {
          reasons.push(`可疑依赖: ${dep}`);
        }
      }
    } catch {}
  }

  return {
    safe: reasons.length === 0,
    reasons,
  };
}

/**
 * 检测虚假功能（README与实际不符）
 */
function detectFakeFunctionality(repoPath) {
  const reasons = [];

  // 检查README是否存在
  const readmeFiles = execSync(`find "${repoPath}" -maxdepth 2 -iname "readme*" 2>/dev/null`).toString().trim().split('\n').filter(Boolean);
  if (readmeFiles.length === 0) {
    reasons.push('缺少README文件');
  }

  // 检查实际代码结构
  const hasCode = execSync(`find "${repoPath}" -type f \\( -name "*.js" -o -name "*.py" -o -name "*.ts" \\) 2>/dev/null | wc -l`).toString().trim();
  if (parseInt(hasCode) < 3) {
    reasons.push(`代码文件过少（${hasCode}个），可能为空壳`);
  }

  // 检查是否有过多Markdown而实际代码少（虚假宣传型repo）
  const mdCount = execSync(`find "${repoPath}" -type f -name "*.md" 2>/dev/null | wc -l`).toString().trim();
  if (parseInt(mdCount) > 20 && parseInt(hasCode) < 5) {
    reasons.push(`文档过多(${mdCount})但代码少(${hasCode})，疑似宣传型repo`);
  }

  return {
    authentic: reasons.length === 0,
    reasons,
  };
}

/**
 * Anti-Poison 综合检测
 */
function antiPoisonCheck(candidate) {
  const config = loadConfig();
  const result = {
    candidate: candidate.name,
    score: candidate.score,
    safe: true,
    checks: {
      malicious: { safe: true, reasons: [] },
      fake: { authentic: true, reasons: [] },
    },
    passed: true,
    action: 'approve', // approve | review | reject
    reason: '',
  };

  // 如果已有本地克隆路径，进行深度检测
  const localPath = candidate.localPath || null;
  
  if (localPath && fs.existsSync(localPath)) {
    console.log(`[APPROVAL] 对 ${candidate.name} 执行Anti-Poison检测...`);
    
    const malicious = detectMaliciousPatterns(localPath);
    result.checks.malicious = malicious;
    if (!malicious.safe) {
      result.safe = false;
      result.action = 'reject';
      result.reason = `恶意代码: ${malicious.reasons.join('; ')}`;
    }

    if (result.safe) {
      const fake = detectFakeFunctionality(localPath);
      result.checks.fake = fake;
      if (!fake.authentic) {
        result.action = 'review';
        result.reason = `可疑功能: ${fake.reasons.join('; ')}`;
      }
    }
  } else {
    // 无本地路径时，基于网络数据做初步检测
    const url = candidate.url || '';
    if (url.includes('github') && candidate.score < 4) {
      result.action = 'review';
      result.reason = '低分候选且无本地克隆，需要人工复核';
    }
  }

  // Evolution Strategy Layer：模式影响决策
  if (config.evolution_mode === 'safe' && result.action === 'review') {
    result.action = 'reject';  // safe模式下，review一律拒绝
    result.reason += ' [safe模式: review→reject]';
  }
  if (config.evolution_mode === 'aggressive' && candidate.score >= 8) {
    result.action = 'approve';  // aggressive模式下高分直接过
    result.reason = 'aggressive模式: 高分自动通过';
  }

  // 评分路由
  if (result.passed && result.action !== 'reject') {
    if (candidate.score >= config.auto_approve_threshold) {
      result.action = 'approve';
    } else if (candidate.score >= config.require_human_approval_threshold) {
      result.action = 'review';
      result.reason = result.reason || `评分${candidate.score}，需人工审批`;
    } else {
      result.action = 'reject';
      result.reason = result.reason || `评分${candidate.score}低于阈值`;
    }
  }

  return result;
}

// ===== APPROVAL 主函数 =====

/**
 * 对候选能力进行审批
 * @param {Object} candidate - 候选能力对象
 * @param {Object} options - { autoMode: true/false }
 * @returns {Object} 审批结果
 */
function runApproval(candidate, options = {}) {
  const config = loadConfig();
  const autoMode = options.autoMode !== false; // 默认为自动模式
  
  console.log(`\n[APPROVAL] 候选: ${candidate.name}`);
  console.log(`  评分: ${candidate.score} | 模式: ${config.evolution_mode}`);

  const result = antiPoisonCheck(candidate);

  // 记录到审批日志
  const log = loadApprovalLog();
  log.unshift({
    ...result,
    timestamp: new Date().toISOString(),
    autoMode,
  });
  // 保留最近200条
  if (log.length > 200) log.splice(200);
  saveApprovalLog(log);

  if (result.action === 'approve') {
    console.log(`  ✅ [APPROVAL] 自动通过`);
  } else if (result.action === 'review') {
    console.log(`  ⚠️  [APPROVAL] 需要人工审批`);
  } else {
    console.log(`  ❌ [APPROVAL] 拒绝: ${result.reason}`);
  }

  // 非自动模式下，review需要发企微通知
  if (result.action === 'review' && !autoMode) {
    console.log('  [企微通知] 发送审批请求到MEI...');
    // 暂时跳过，等待接入企微API
    console.log('  [企微通知] ✅ 审批请求已发送（模拟）');
  }

  return result;
}

/**
 * 批量审批入口
 */
function approveCandidates(candidates, options = {}) {
  const results = [];
  for (const candidate of candidates) {
    const r = runApproval(candidate, options);
    results.push(r);
  }
  
  const summary = {
    total: results.length,
    approved: results.filter(r => r.action === 'approve').length,
    review: results.filter(r => r.action === 'review').length,
    rejected: results.filter(r => r.action === 'reject').length,
  };
  
  console.log(`\n[APPROVAL SUMMARY] 通过=${summary.approved} 待审=${summary.review} 拒绝=${summary.rejected}`);
  return { results, summary };
}

// CLI入口
function main() {
  const args = process.argv.slice(2);
  
  if (args.includes('--check') || args.includes('-c')) {
    const repoPath = args[args.indexOf('--check') + 1] || args[args.indexOf('-c') + 1];
    if (!repoPath) { console.log('用法: node approval.js --check /path/to/repo'); process.exit(1); }
    
    const malicious = detectMaliciousPatterns(repoPath);
    const fake = detectFakeFunctionality(repoPath);
    
    console.log('恶意检测:', malicious);
    console.log('真实性检测:', fake);
    return;
  }

  if (args.includes('--status')) {
    const log = loadApprovalLog();
    console.log(`审批历史（共${log.length}条）:`);
    log.slice(0, 10).forEach(e => {
      console.log(`  [${e.action}] ${e.candidate} (${e.score}分) - ${e.reason || e.timestamp}`);
    });
    return;
  }

  // 默认：显示帮助
  console.log(`
APPROVAL 模块 | Anti-Poison + 审批路由

用法：
  node approval.js --check /path/to/repo    Anti-Poison检测本地路径
  node approval.js --status               查看审批历史
  node approval.js --run <candidates.json> 批量审批（JSON文件）
  node approval.js --auto                  以自动模式运行（无需人工）

MSOP审批规则：
  score >= 7  → 自动通过 ✅
  score 5-7   → 人工审批 ⚠️
  score < 5   → 丢弃 ❌

Evolution Strategy Layer：
  safe       → review一律拒绝
  balanced   → 按评分标准来
  aggressive → score>=8直接过
`);
}

module.exports = { runApproval, approveCandidates, antiPoisonCheck };

if (require.main === module) main();
