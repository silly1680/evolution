/**
 * MSOP Evolution Strategy Layer
 * 职责：
 *  - 管理进化模式（balanced / aggressive / safe）
 *  - 根据模式调整系统参数
 *  - Capability Priority Queue（能力优先级队列）
 *  - 多阶段进化路径追踪
 */

const fs = require('fs');
const path = require('path');

const WORKSPACE = '/workspace/evolve';
const STRATEGY_FILE = path.join(WORKSPACE, 'evolution-strategy.json');
const REGISTRY_FILE = path.join(WORKSPACE, 'capability-registry.json');

// ===== 进化模式定义 =====

const MODES = {
  safe: {
    name: 'Safe（安全优先）',
    description: '只吞噬经过充分验证的能力，零风险，适合生产环境',
    scan_interval_hours: 48,         // 每48小时扫描一次
    max_repo_per_cycle: 2,           // 每周期最多2个
    auto_approve_threshold: 8,       // ≥8分才自动通过
    human_approval_threshold: 7,     // 7-8分需人工
    sandbox_required: true,           // 必须沙盒验证
    min_stars_threshold: 5000,       // 最低5000 stars
    innovation_bias: 0.2,             // 创新系数权重低（保守）
    risk_tolerance: 1,                // 风险容忍度：极低
    allow_experimental: false,         // 不允许实验性
    self_reflection_interval: 1,       // 每周期都反思
    retire_aggressive: true,          // 淘汰更激进
  },
  balanced: {
    name: 'Balanced（平衡模式）',
    description: '兼顾速度与安全，适合日常能力积累',
    scan_interval_hours: 24,
    max_repo_per_cycle: 5,
    auto_approve_threshold: 7,
    human_approval_threshold: 5,
    sandbox_required: true,
    min_stars_threshold: 1000,
    innovation_bias: 0.35,
    risk_tolerance: 2,
    allow_experimental: true,
    self_reflection_interval: 3,
    retire_aggressive: false,
  },
  aggressive: {
    name: 'Aggressive（激进模式）',
    description: '快速扩张，适合能力快速增长期',
    scan_interval_hours: 12,
    max_repo_per_cycle: 10,
    auto_approve_threshold: 6,
    human_approval_threshold: 4,
    sandbox_required: false,          // 可跳过沙盒
    min_stars_threshold: 100,
    innovation_bias: 0.6,             // 创新权重高
    risk_tolerance: 4,
    allow_experimental: true,
    self_reflection_interval: 5,
    retire_aggressive: false,
  },
};

// ===== Capability Priority Queue =====

const PRIORITY_TEMPLATES = {
  general: {
    name: '通用能力',
    weights: {
      browser: 9, vision: 9, trading: 8, coding: 8,
      data: 7, automation: 7, writing: 6, memory: 6,
    },
  },
  coding_focused: {
    name: '编程优先',
    weights: {
      coding: 10, browser: 9, debugging: 9, testing: 8,
      data: 6, automation: 6, writing: 5, memory: 5,
    },
  },
  trading_focused: {
    name: '交易优先',
    weights: {
      trading: 10, financial_data: 10, market_analysis: 9,
      automation: 7, coding: 6, data: 7, vision: 5,
    },
  },
  ai_research: {
    name: 'AI研究',
    weights: {
      llm: 10, rag: 9, agentic: 9, coding: 8,
      data: 7, vision: 7, automation: 6, writing: 5,
    },
  },
};

// ===== 多阶段进化路径 =====

const EVOLUTION_PHASES = {
  phase_1: {
    id: 'phase_1',
    name: 'Foundational（基础建设期）',
    description: '构建核心能力基座：browser、coding、memory、basic-automation',
    duration_cycles: 5,
    target_capabilities: ['browser', 'coding', 'memory', 'automation', 'data'],
    recommended_mode: 'safe',
    exit_criteria: {
      capability_count: 5,
      min_avg_score: 7.0,
    },
  },
  phase_2: {
    id: 'phase_2',
    name: 'Specialization（专项深化期）',
    description: '深化垂直领域：trading、vision、AI/ML等专项能力',
    duration_cycles: 10,
    target_capabilities: ['trading', 'vision', 'ai-ml', 'data', 'coding'],
    recommended_mode: 'balanced',
    exit_criteria: {
      capability_count: 10,
      min_avg_score: 7.5,
      trading_capability: true,
    },
  },
  phase_3: {
    id: 'phase_3',
    name: 'Integration（系统融合期）',
    description: '将多能力融合为workflow，形成端到端自动化能力',
    duration_cycles: 15,
    target_capabilities: ['agentic', 'multi-agent', 'workflow', 'autonomous'],
    recommended_mode: 'aggressive',
    exit_criteria: {
      workflow_count: 3,
      multi_agent: true,
    },
  },
};

// ===== 策略管理器 =====

function loadStrategy() {
  if (!fs.existsSync(STRATEGY_FILE)) {
    return getDefaultStrategy();
  }
  return JSON.parse(fs.readFileSync(STRATEGY_FILE, 'utf-8'));
}

function saveStrategy(strategy) {
  fs.writeFileSync(STRATEGY_FILE, JSON.stringify(strategy, null, 2), 'utf-8');
}

function getDefaultStrategy() {
  return {
    current_mode: 'balanced',
    current_phase: 'phase_1',
    cycle_in_phase: 0,
    priority_template: 'general',
    priority_weights: PRIORITY_TEMPLATES.general.weights,
    evolution_history: [],
    total_cycles: 0,
    mode_changes: [],
    phase_changes: [],
    createdAt: new Date().toISOString(),
  };
}

// ===== 核心函数 =====

/**
 * 获取当前模式的配置参数
 */
function getModeConfig(mode) {
  return MODES[mode] || MODES.balanced;
}

/**
 * 获取当前策略
 */
function getCurrentStrategy() {
  return loadStrategy();
}

/**
 * 切换进化模式
 */
function setEvolutionMode(newMode) {
  if (!MODES[newMode]) {
    throw new Error(`未知模式: ${newMode}，可用: ${Object.keys(MODES).join(', ')}`);
  }

  const strategy = loadStrategy();
  const oldMode = strategy.current_mode;
  strategy.current_mode = newMode;
  strategy.mode_changes.push({
    from: oldMode,
    to: newMode,
    at: new Date().toISOString(),
  });

  saveStrategy(strategy);

  const config = getModeConfig(newMode);
  console.log(`[Strategy] 模式切换: ${oldMode} → ${newMode}`);
  console.log(`[Strategy] ${config.name}: ${config.description}`);
  console.log(`[Strategy] 新参数: scan=${config.scan_interval_hours}h, max=${config.max_repo_per_cycle}, threshold=${config.auto_approve_threshold}`);

  return { oldMode, newMode, config };
}

/**
 * 计算候选能力的优先级分数
 * priority_score = base_score * innovation_bias + weight_factor * gap_urgency
 */
function calculatePriorityScore(candidate, strategy) {
  const weights = strategy.priority_weights;
  const mode = strategy.current_mode;
  const config = getModeConfig(mode);

  // 基础能力匹配分数
  let weightFactor = 5; // 默认中优先级
  const caps = candidate.capabilities || candidate.dna || [];

  for (const cap of caps) {
    const w = weights[cap.toLowerCase()] || weights[cap] || 5;
    weightFactor = Math.max(weightFactor, w);
  }

  // 稀缺性奖励：registry中没有的能力更高分
  let registry = {};
  try {
    registry = JSON.parse(fs.readFileSync(REGISTRY_FILE, 'utf-8'));
  } catch {}

  const existingDna = new Set(Object.values(registry).flatMap(c => c.dna || []));
  const isNew = caps.some(c => !existingDna.has(c.toLowerCase()) && !existingDna.has(c));
  const scarcityBonus = isNew ? 1.5 : 1.0;

  // 综合优先级
  const baseScore = candidate.score || candidate.msopScore || 6;
  const priorityScore = baseScore * config.innovation_bias + (weightFactor / 10) * 5 * scarcityBonus;

  return Math.round(priorityScore * 100) / 100;
}

/**
 * 按优先级排序候选列表
 */
function rankCandidates(candidates, strategy) {
  return candidates
    .map(c => ({
      ...c,
      priorityScore: calculatePriorityScore(c, strategy),
    }))
    .sort((a, b) => {
      // 优先按优先级分数，再按MSOP评分
      if (b.priorityScore !== a.priorityScore) {
        return b.priorityScore - a.priorityScore;
      }
      return (b.score || 0) - (a.score || 0);
    });
}

/**
 * 检查并推进进化阶段
 */
function checkPhaseTransition(strategy) {
  const registry = JSON.parse(fs.readFileSync(REGISTRY_FILE, 'utf-8'));
  const currentPhase = EVOLUTION_PHASES[strategy.current_phase];
  const phaseNum = parseInt(strategy.current_phase.split('_')[1]);

  strategy.cycle_in_phase++;
  strategy.total_cycles++;

  // 检查退出条件
  const caps = Object.values(registry).filter(c => c.status !== 'retired');
  const avgScore = caps.reduce((sum, c) => sum + (c.score || 0), 0) / Math.max(caps.length, 1);
  const hasTargetCaps = currentPhase.target_capabilities.every(
    tc => caps.some(c => (c.dna || []).some(d => d.includes(tc)))
  );

  const exitCriteria = currentPhase.exit_criteria;
  let canTransition = false;
  let reason = '';

  if (phaseNum >= 3) {
    // Phase 3 之后不再自动升级
    return { transitioned: false, reason: '已达最终阶段', strategy };
  }

  if (exitCriteria.capability_count && caps.length >= exitCriteria.capability_count) {
    if (exitCriteria.min_avg_score && avgScore >= exitCriteria.min_avg_score) {
      if (!exitCriteria.trading_capability || hasTargetCaps) {
        canTransition = true;
        reason = `能力数量${caps.length}达标 + 平均分${avgScore.toFixed(1)} >= ${exitCriteria.min_avg_score}`;
      }
    }
  }

  if (canTransition) {
    const nextPhaseNum = phaseNum + 1;
    const nextPhaseKey = `phase_${nextPhaseNum}`;
    const nextPhase = EVOLUTION_PHASES[nextPhaseKey];

    if (nextPhase) {
      const oldPhase = strategy.current_phase;
      strategy.current_phase = nextPhaseKey;
      strategy.cycle_in_phase = 0;
      strategy.phase_changes.push({
        from: oldPhase,
        to: nextPhaseKey,
        at: new Date().toISOString(),
        reason,
      });

      // 自动切换到推荐模式
      setEvolutionMode(nextPhase.recommended_mode);

      saveStrategy(strategy);

      return {
        transitioned: true,
        from: oldPhase,
        to: nextPhaseKey,
        nextPhase,
        reason,
        strategy,
      };
    }
  }

  saveStrategy(strategy);
  return { transitioned: false, reason, strategy, cycle_in_phase: strategy.cycle_in_phase };
}

/**
 * 获取进化路线图报告
 */
function getEvolutionRoadmap() {
  const strategy = loadStrategy();
  const registry = JSON.parse(fs.readFileSync(REGISTRY_FILE, 'utf-8'));
  const caps = Object.values(registry).filter(c => c.status !== 'retired');

  const report = [];
  report.push('# 🧬 Evolution Intelligence Report');
  report.push(`**生成时间**: ${new Date().toISOString().slice(0, 19).replace('T', ' ')}`);
  report.push('');
  report.push(`## 当前状态`);
  report.push(`| 指标 | 值 |`);
  report.push(`|------|-----|`);
  report.push(`| 当前模式 | **${strategy.current_mode.toUpperCase()}**（${getModeConfig(strategy.current_mode).name}）|`);
  report.push(`| 当前阶段 | **${strategy.current_phase}**（${EVOLUTION_PHASES[strategy.current_phase].name}）|`);
  report.push(`| 本阶段周期 | ${strategy.cycle_in_phase} / ${EVOLUTION_PHASES[strategy.current_phase].duration_cycles} |`);
  report.push(`| 总进化周期 | ${strategy.total_cycles} |`);
  report.push(`| 已积累能力 | ${caps.length} 个 |`);
  report.push('');

  report.push('## 各阶段定义');
  for (const [key, phase] of Object.entries(EVOLUTION_PHASES)) {
    const isCurrent = key === strategy.current_phase;
    const isPast = parseInt(key.split('_')[1]) < parseInt(strategy.current_phase.split('_')[1]);
    report.push(`### ${isCurrent ? '👉' : isPast ? '✅' : '🔒'} ${key}: ${phase.name}`);
    report.push(`> ${phase.description}`);
    report.push(`- 目标能力: ${phase.target_capabilities.join(', ')}`);
    report.push(`- 推荐模式: ${phase.recommended_mode}`);
    report.push(`- 周期长度: ${phase.duration_cycles}`);
    report.push('');
  }

  report.push('## Capability Priority Queue');
  const template = PRIORITY_TEMPLATES[strategy.priority_template];
  report.push(`当前模板: **${template.name}**`);
  const sortedWeights = Object.entries(strategy.priority_weights)
    .sort((a, b) => b[1] - a[1]);
  report.push('| 能力 | 优先级 |');
  report.push('|------|--------|');
  sortedWeights.forEach(([cap, w]) => {
    const bar = '█'.repeat(Math.round(w / 2)) + '░'.repeat(5 - Math.round(w / 2));
    report.push(`| \`${cap}\` | ${bar} ${w} |`);
  });
  report.push('');

  report.push('## 模式切换历史');
  if (strategy.mode_changes.length === 0) {
    report.push('（暂无）');
  } else {
    strategy.mode_changes.slice(-5).forEach(m => {
      report.push(`- ${m.at.slice(0,16)}: ${m.from} → ${m.to}`);
    });
  }
  report.push('');

  report.push('## 进化历史里程碑');
  if (strategy.phase_changes.length === 0) {
    report.push('（暂无阶段变化）');
  } else {
    strategy.phase_changes.forEach(p => {
      report.push(`- ${p.at.slice(0,16)}: ${p.from} → ${p.to} (${p.reason})`);
    });
  }

  return report.join('\n');
}

/**
 * 设置能力优先级模板
 */
function setPriorityTemplate(templateName) {
  if (!PRIORITY_TEMPLATES[templateName]) {
    throw new Error(`未知模板: ${templateName}，可用: ${Object.keys(PRIORITY_TEMPLATES).join(', ')}`);
  }
  const strategy = loadStrategy();
  strategy.priority_template = templateName;
  strategy.priority_weights = { ...PRIORITY_TEMPLATES[templateName].weights };
  saveStrategy(strategy);
  return { template: templateName, weights: strategy.priority_weights };
}

/**
 * 获取当前模式的CONFIG（供msop-runner.js使用）
 */
function getRuntimeConfig() {
  const strategy = loadStrategy();
  const mode = strategy.current_mode;
  const config = getModeConfig(mode);

  return {
    scan_interval: config.scan_interval_hours * 3600,
    max_repo_per_cycle: config.max_repo_per_cycle,
    auto_approve_threshold: config.auto_approve_threshold,
    require_human_approval_threshold: config.human_approval_threshold,
    sandbox_required: config.sandbox_required,
    llm_analysis: true,
    evolution_mode: mode,
    min_stars_threshold: config.min_stars_threshold,
    innovation_bias: config.innovation_bias,
    risk_tolerance: config.risk_tolerance,
    allow_experimental: config.allow_experimental,
    self_reflection_interval: config.self_reflection_interval,
    retire_aggressive: config.retire_aggressive,
    priority_weights: strategy.priority_weights,
    current_phase: strategy.current_phase,
  };
}

// ===== CLI 入口 =====

function main() {
  const args = process.argv.slice(2);
  const action = args[0];

  if (action === 'status' || !action) {
    const s = loadStrategy();
    const config = getModeConfig(s.current_mode);
    console.log('\n🧬 Evolution Strategy 当前状态');
    console.log('='.repeat(45));
    console.log(`模式: ${s.current_mode.toUpperCase()} - ${config.name}`);
    console.log(`阶段: ${s.current_phase} - ${EVOLUTION_PHASES[s.current_phase].name}`);
    console.log(`本阶段周期: ${s.cycle_in_phase}/${EVOLUTION_PHASES[s.current_phase].duration_cycles}`);
    console.log(`总周期: ${s.total_cycles}`);
    console.log(`优先级模板: ${s.priority_template}`);
    console.log('');
    console.log('模式参数:');
    console.log(`  扫描间隔: ${config.scan_interval_hours}h`);
    console.log(`  每轮上限: ${config.max_repo_per_cycle} repos`);
    console.log(`  自动通过阈值: ${config.auto_approve_threshold}`);
    console.log(`  最低Stars: ${config.min_stars_threshold}`);
    console.log(`  风险容忍: ${config.risk_tolerance}/5`);
    console.log(`  沙盒必须: ${config.sandbox_required}`);
    return;
  }

  if (action === 'mode' && args[1]) {
    const r = setEvolutionMode(args[1]);
    console.log(JSON.stringify(r, null, 2));
    return;
  }

  if (action === 'rank' && args[1]) {
    const strategy = loadStrategy();
    const fs2 = require('fs');
    const candidates = JSON.parse(fs2.readFileSync(args[1], 'utf-8'));
    const ranked = rankCandidates(candidates, strategy);
    console.log('\n优先级排序结果:');
    ranked.forEach((c, i) => {
      console.log('  ' + (i+1) + '. ' + c.name + ' (priority=' + c.priorityScore.toFixed(2) + ', score=' + c.score + ')');
    });
    return;
  }

  if (action === 'phase') {
    const s = loadStrategy();
    const r = checkPhaseTransition(s);
    console.log(JSON.stringify(r, null, 2));
    return;
  }

  if (action === 'roadmap') {
    console.log(getEvolutionRoadmap());
    return;
  }

  if (action === 'config') {
    console.log(JSON.stringify(getRuntimeConfig(), null, 2));
    return;
  }

  if (action === 'template' && args[1]) {
    const r = setPriorityTemplate(args[1]);
    console.log(JSON.stringify(r, null, 2));
    return;
  }

  console.log(`
Evolution Strategy Layer | MSOP 进化策略控制

用法：
  node evolution-strategy.js status              查看当前状态
  node evolution-strategy.js mode <mode>        切换模式 (safe|balanced|aggressive)
  node evolution-strategy.js rank <file.json>  对候选文件排序
  node evolution-strategy.js phase             检查阶段推进
  node evolution-strategy.js roadmap            完整进化路线图
  node evolution-strategy.js config             获取运行时配置(JSON)
  node evolution-strategy.js template <name>    切换优先级模板
                                                  (general|coding_focused|
                                                   trading_focused|ai_research)

进化模式：
  safe       - 安全优先，低风险
  balanced   - 平衡（默认）
  aggressive - 激进快速扩张

进化阶段：
  phase_1 - 基础建设期（构建核心能力基座）
  phase_2 - 专项深化期（深化垂直领域）
  phase_3 - 系统融合期（多能力融合workflow）
`);
}

module.exports = {
  getCurrentStrategy,
  setEvolutionMode,
  calculatePriorityScore,
  rankCandidates,
  checkPhaseTransition,
  getEvolutionRoadmap,
  setPriorityTemplate,
  getRuntimeConfig,
  getModeConfig,
  EVOLUTION_PHASES,
  PRIORITY_TEMPLATES,
  MODES,
};

if (require.main === module) main();
