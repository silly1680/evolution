#!/usr/bin/env node
/**
 * MSOP 状态机调度器 - Evolution Controller
 * 
 * 职责：
 * ① 管理状态机状态转换
 * ② 驱动 OBSERVE → VALUE_UPDATE → RETIRE_CHECK 循环
 * ③ 自动执行 SKILL_GENERATION（观察成功后生成Skill）
 * 
 * 运行方式：
 *   node /workspace/evolve/evolution-controller.js --action status
 *   node /workspace/evolve/evolution-controller.js --action run-cycle
 *   node /workspace/evolve/evolution-controller.js --action observe
 *   node /workspace/evolve/evolution-controller.js --action retire-check
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// ===== 核心配置 =====
const WORKSPACE = process.env.EVOLVE_WORKSPACE || __dirname;
const CANDIDATES_DIR = path.join(WORKSPACE, 'candidates');
const SKILLS_OUT_DIR = path.join(WORKSPACE, 'skills');
const REGISTRY_FILE = path.join(WORKSPACE, 'capability-registry.json');
const OBSERVATION_LOG = path.join(WORKSPACE, 'observation-log.json');
const STATE_FILE = path.join(WORKSPACE, 'state-machine.json');

// ===== 系统控制参数（MSOP定义）=====
const CONFIG = {
  scan_interval: 24 * 3600,      // 扫描间隔：24小时
  max_repo_per_cycle: 5,          // 每轮最多处理5个候选
  auto_approve_threshold: 7,      // >=7分自动通过
  sandbox_required: true,         // 沙盒验证必须
  llm_analysis: true,            // LLM分析必须
  retention_days: 30,             // 能力保留天数
  value_threshold: 3,             // 淘汰阈值：value_score < 3
  usage_threshold: 5,            // 淘汰阈值：usage < 5
  success_rate_threshold: 0.6,    // 淘汰阈值：成功率 < 60%
  evolution_mode: 'balanced',     // 进化模式：balanced | aggressive | safe
  self_reflection_interval: 3,    // 每N个观察周期执行一次自我反思
};

// ===== 状态定义 =====
const STATES = {
  IDLE: 'IDLE',
  SCAN: 'SCAN',
  GAP_ANALYSIS: 'GAP_ANALYSIS',
  TARGET_SELECTION: 'TARGET_SELECTION',
  EVALUATION: 'EVALUATION',
  APPROVAL: 'APPROVAL',
  FETCH: 'FETCH',
  SANDBOX_TEST: 'SANDBOX_TEST',
  CAPABILITY_EXTRACTION: 'CAPABILITY_EXTRACTION',
  DNA_ENCODING: 'DNA_ENCODING',
  COMPOSITION: 'COMPOSITION',
  SKILL_GENERATION: 'SKILL_GENERATION',
  DEPLOY: 'DEPLOY',
  OBSERVE: 'OBSERVE',
  VALUE_UPDATE: 'VALUE_UPDATE',
  RETIRE_CHECK: 'RETIRE_CHECK',
};

// ===== 候选能力注册表 =====
function loadRegistry() {
  if (!fs.existsSync(REGISTRY_FILE)) {
    return {};
  }
  return JSON.parse(fs.readFileSync(REGISTRY_FILE, 'utf-8'));
}

function saveRegistry(registry) {
  fs.writeFileSync(REGISTRY_FILE, JSON.stringify(registry, null, 2), 'utf-8');
}

function initRegistry() {
  const registry = loadRegistry();
  // 如果没有记录，初始化为空对象，并注册已有的akshare能力
  if (Object.keys(registry).length === 0) {
    registry['akshare-data'] = {
      id: 'akshare-data',
      name: 'akshare金融数据',
      dna: ['stock-data', 'market-quote', 'financial-report', 'eastmoney-api'],
      version: '1.0.0',
      status: 'active',
      score: 7.1,
      source: 'https://github.com/akfamily/akshare',
      deployedAt: '2026-03-28',
      stats: {
        calls: 5,
        successRate: 1.0,
        avgTime: 2.5,
        lastUsed: new Date().toISOString(),
        totalErrors: 0
      },
      valueScore: 0, // 初始为0，等VALUE_UPDATE计算
    };
    saveRegistry(registry);
    console.log('[注册表] 已初始化，包含已有能力：akshare-data');
  }
  return registry;
}

// ===== 观察日志（OBSERVE）=====
function loadObservationLog() {
  if (!fs.existsSync(OBSERVATION_LOG)) {
    return [];
  }
  return JSON.parse(fs.readFileSync(OBSERVATION_LOG, 'utf-8'));
}

function saveObservationLog(log) {
  fs.writeFileSync(OBSERVATION_LOG, JSON.stringify(log, null, 2), 'utf-8');
}

function logCall(capabilityId, success, timeMs, errorMsg) {
  const log = loadObservationLog();
  const entry = {
    id: `call-${Date.now()}`,
    capabilityId,
    success,
    timeMs,
    errorMsg: errorMsg || null,
    timestamp: new Date().toISOString(),
  };
  log.push(entry);
  // 保留最近1000条记录
  if (log.length > 1000) {
    log.splice(0, log.length - 1000);
  }
  saveObservationLog(log);
  return entry;
}

function getCapabilityStats(capabilityId) {
  const log = loadObservationLog();
  const calls = log.filter(e => e.capabilityId === capabilityId);
  if (calls.length === 0) {
    return { calls: 0, successRate: 0, avgTime: 0, totalErrors: 0 };
  }
  const successes = calls.filter(e => e.success).length;
  const totalTime = calls.reduce((sum, e) => sum + (e.timeMs || 0), 0);
  const errors = calls.filter(e => !e.success).length;
  return {
    calls: calls.length,
    successRate: Math.round((successes / calls.length) * 100) / 100,
    avgTime: Math.round(totalTime / calls.length * 100) / 100,
    totalErrors: errors,
    lastUsed: calls[calls.length - 1]?.timestamp,
  };
}

// ===== 价值评估（VALUE_UPDATE）=====
// value_score = usage * 0.4 + success_rate * 0.3 + efficiency * 0.3
function calculateValueScore(stats) {
  // efficiency: 基于avgTime，<1秒=1.0，>10秒=0
  const efficiency = Math.max(0, 1 - Math.max(0, stats.avgTime - 1) / 9);
  const score = stats.calls * 0.4 + stats.successRate * 0.3 + efficiency * 0.3;
  return Math.round(score * 100) / 100;
}

function updateAllValueScores() {
  const registry = loadRegistry();
  let updated = false;
  for (const id in registry) {
    const cap = registry[id];
    // 从观察日志获取真实统计
    const obsStats = getCapabilityStats(id);
    const regStats = cap.stats || {};
    
    // 合并策略：取观察日志的calls覆盖，无则保留注册表数据
    const mergedStats = {
      calls: obsStats.calls > 0 ? obsStats.calls : regStats.calls,
      successRate: obsStats.calls > 0 ? obsStats.successRate : (regStats.successRate || 1.0),
      avgTime: obsStats.calls > 0 ? obsStats.avgTime : (regStats.avgTime || 0),
      totalErrors: obsStats.totalErrors,
      lastUsed: obsStats.lastUsed || regStats.lastUsed,
    };
    cap.stats = mergedStats;
    cap.valueScore = calculateValueScore(mergedStats);
    updated = true;
  }
  if (updated) {
    saveRegistry(registry);
  }
  return registry;
}

// ===== 淘汰检查（RETIRE_CHECK）=====
// 规则：value_score < 3 AND usage < 5 AND success_rate < 0.6
function runRetireCheck() {
  // 先更新所有价值评分（合并观察日志+注册表）
  const registry = updateAllValueScores();
  const observationLog = loadObservationLog();
  const retired = [];
  const survivors = [];

  for (const id in registry) {
    const cap = registry[id];
    // 如果从未被调用过，不淘汰
    if (cap.stats.calls === 0) {
      survivors.push(id);
      continue;
    }
    const stats = getCapabilityStats(id);
    const valueScore = calculateValueScore(stats);
    cap.valueScore = valueScore;

    // 使用cap.stats（已合并）
    const totalCalls = cap.stats?.calls || 0;
    const totalRate = cap.stats?.successRate || 0;
    const shouldRetire =
      valueScore < CONFIG.value_threshold &&
      totalCalls < CONFIG.usage_threshold &&
      totalRate < CONFIG.success_rate_threshold;

    if (shouldRetire) {
      cap.status = 'retired';
      cap.retiredAt = new Date().toISOString();
      retired.push({ id, name: cap.name, valueScore, stats });
      console.log(`[淘汰] ${cap.name} (value=${valueScore}, calls=${stats.calls}, rate=${stats.successRate})`);
    } else {
      survivors.push(id);
    }
  }

  saveRegistry(registry);

  // 清理30天以上的旧观察记录
  const cutoff = new Date(Date.now() - CONFIG.retention_days * 24 * 3600 * 1000).toISOString();
  const pruned = observationLog.filter(e => e.timestamp > cutoff);
  if (pruned.length !== observationLog.length) {
    saveObservationLog(pruned);
    console.log(`[清理] 观察日志：${observationLog.length} → ${pruned.length} 条`);
  }

  return { retired, survivors: survivors.length };
}

// ===== 自我反思（SELF-REFLECTION）=====
function runSelfReflection() {
  const registry = loadRegistry();
  const report = [];
  report.push(`## 🧠 自我反思报告 | ${new Date().toISOString().slice(0, 10)}`);
  report.push('');
  report.push('### 能力价值排行榜');
  
  const sorted = Object.values(registry)
    .filter(c => c.status === 'active')
    .sort((a, b) => (b.valueScore || 0) - (a.valueScore || 0));

  report.push(`| 能力 | 评分 | 调用次数 | 成功率 | 平均耗时 | 价值分 |`);
  report.push(`|------|------|----------|--------|----------|-------|`);
  
  sorted.forEach(c => {
    const s = c.stats || {};
    report.push(`| ${c.name} | ${c.score || '?'} | ${s.calls || 0} | ${s.successRate || '?'} | ${s.avgTime || '?'}s | ${c.valueScore || '?'} |`);
  });

  report.push('');
  report.push('### 进化建议');
  
  // 分析缺口
  const topUsed = sorted.filter(c => (c.stats?.calls || 0) > 10);
  const noUse = sorted.filter(c => (c.stats?.calls || 0) === 0);
  
  if (topUsed.length > 0) {
    report.push(`- ✅ 高频能力：${topUsed.map(c => c.name).join('、')} — 这些是核心能力，继续保持`);
  }
  if (noUse.length > 0) {
    report.push(`- ⚠️ 未使用能力：${noUse.map(c => c.name).join('、')} — 下个周期决定是否保留`);
  }
  
  // 识别进化方向
  const lowScore = sorted.filter(c => (c.valueScore || 0) < 3 && (c.stats?.calls || 0) > 0);
  if (lowScore.length > 0) {
    report.push(`- 🔴 价值不足能力：${lowScore.map(c => `${c.name}(${c.valueScore})`).join('、')} — 考虑优化或淘汰`);
  }

  const summary = report.join('\n');
  console.log(summary);
  return summary;
}

// ===== 技能生成（SKILL_GENERATION）=====
function generateSkillMeta(capabilityId, dna, source) {
  return {
    name: capabilityId,
    description: `自动生成的能力，DNA：[${dna.join(', ')}]，来源：${source}`,
    version: '1.0.0',
    generatedBy: 'MSOP-SKILL_GENERATION',
    generatedAt: new Date().toISOString(),
    dna,
    source,
    status: 'auto-generated'
  };
}

// ===== 注册新能力（DEPLOY）=====
function deployCapability(id, name, dna, score, source, scriptPath) {
  const registry = loadRegistry();
  if (registry[id]) {
    console.log(`[部署] ${id} 已存在，版本更新`);
    registry[id].version = (parseFloat(registry[id].version || '1.0') + 0.1).toFixed(1);
    registry[id].stats = { calls: 0, successRate: 0, avgTime: 0, totalErrors: 0 };
    registry[id].deployedAt = new Date().toISOString();
  } else {
    registry[id] = {
      id,
      name,
      dna,
      version: '1.0.0',
      status: 'active',
      score,
      source,
      deployedAt: new Date().toISOString(),
      stats: { calls: 0, successRate: 0, avgTime: 0, totalErrors: 0 },
      valueScore: 0,
      scriptPath: scriptPath || null,
    };
    console.log(`[部署] 新能力注册：${id} (score=${score})`);
  }
  saveRegistry(registry);
  return registry[id];
}

// ===== 主调度循环 =====
async function runCycle() {
  console.log('\n========== MSOP 进化周期 ==========');
  console.log(`模式：${CONFIG.evolution_mode} | 时间：${new Date().toISOString()}`);
  console.log('');

  // ① SCAN
  console.log('[SCAN] 执行猎物扫描...');
  try {
    execSync(`node ${path.join(__dirname, 'prey-scanner.js')}`, { timeout: 60000, cwd: WORKSPACE, stdio: 'pipe' });
    console.log('[SCAN] ✅ 完成');
  } catch (e) {
    console.log('[SCAN] ⚠️ 无输出或失败');
  }

  // ② GAP_ANALYSIS + TARGET_SELECTION
  console.log('[GAP_ANALYSIS] 执行缺口分析...');
  try {
    execSync(`node ${path.join(__dirname, 'gap-seeker.js')}`, { timeout: 60000, cwd: WORKSPACE, stdio: 'pipe' });
    console.log('[GAP_ANALYSIS] ✅ 完成');
  } catch (e) {
    console.log('[GAP_ANALYSIS] ⚠️ 无输出或失败');
  }

  // ③ 读取候选列表（从猎物扫描结果）
  const latestCandidate = fs.readdirSync(CANDIDATES_DIR)
    .filter(f => f.endsWith('.json'))
    .sort()
    .pop();
  
  if (latestCandidate) {
    const candidates = JSON.parse(
      fs.readFileSync(path.join(CANDIDATES_DIR, latestCandidate), 'utf-8')
    ).filter(c => c.score >= CONFIG.auto_approve_threshold);

    console.log(`[EVALUATION] 高分候选：${candidates.length} 个`);
    
    for (const candidate of candidates.slice(0, CONFIG.max_repo_per_cycle)) {
      const id = candidate.name.toLowerCase().replace(/[^a-z0-9-]/g, '-');
      console.log(`\n[CANDIDATE] ${candidate.name} (score=${candidate.score})`);
      console.log(`  匹配缺口：${candidate.matches?.map(m => m.gapName).join(', ') || '综合'}`);
      
      // 符合自动审批阈值，直接跳过APPROVAL（老梅说不需要审批）
      if (candidate.score >= CONFIG.auto_approve_threshold) {
        console.log(`  [APPROVAL] ✅ 自动通过（score=${candidate.score} >= ${CONFIG.auto_approve_threshold})`);
        
        // 部署到注册表
        deployCapability(
          id,
          candidate.name,
          candidate.matches?.map(m => m.gapId) || ['general'],
          candidate.score,
          candidate.url
        );
        console.log(`  [DEPLOY] ✅ 已注册到能力库`);
      }
    }
  }

  // ④ OBSERVE：更新所有能力的统计
  console.log('\n[OBSERVE] 更新能力统计...');
  const reg = updateAllValueScores();
  console.log(`[OBSERVE] 已更新 ${Object.keys(reg).length} 个能力`);
  
  // ⑤ VALUE_UPDATE（包含在updateAllValueScores里了）
  console.log('[VALUE_UPDATE] 价值评分已计算');
  
  // ⑥ RETIRE_CHECK
  console.log('\n[RETIRE_CHECK] 执行淘汰检查...');
  const { retired, survivors } = runRetireCheck();
  console.log(`[RETIRE_CHECK] 淘汰 ${retired.length} 个，保留 ${survivors} 个`);

  // ⑦ SELF-REFLECTION
  console.log('\n[SELF-REFLECTION] 执行自我反思...');
  runSelfReflection();

  console.log('\n========== 进化周期完成 ==========');
  return { deployed: Object.keys(reg).length, retired: retired.length };
}

// ===== 命令行入口 =====
function main() {
  const args = process.argv.slice(2);
  const action = args.find(a => !a.startsWith('--')) || 'status';
  
  // 初始化注册表
  initRegistry();
  
  if (action === 'status' || args.includes('--status')) {
    const registry = loadRegistry();
    console.log('\n📋 能力注册表');
    console.log(`状态 | 能力 | 版本 | 评分 | 价值分 | 调用次数 | 成功率\n`);
    for (const id in registry) {
      const c = registry[id];
      const s = c.stats || {};
      console.log(`${c.status} | ${c.name} | v${c.version} | ${c.score} | ${c.valueScore} | ${s.calls} | ${s.successRate}`);
    }
    console.log(`\n总计：${Object.keys(registry).length} 个能力`);
    console.log(`配置：进化模式=${CONFIG.evolution_mode}，自动通过阈值=${CONFIG.auto_approve_threshold}`);
    return;
  }

  if (action === 'call' || args.includes('--call')) {
    const capId = (args[args.indexOf('--call') + 1] || args[args.indexOf('-c') + 1]);
    const start = Date.now();
    console.log(`[OBSERVE] 记录调用：${capId}`);
    const success = true; // 调用时假设成功
    const entry = logCall(capId, success, Date.now() - start);
    console.log(`[OBSERVE] 已记录：${entry.id}`);
    return;
  }

  if (action === 'run-cycle' || args.includes('--run-cycle')) {
    runCycle().then(r => {
      console.log('\n周期完成：', r);
      process.exit(0);
    }).catch(e => {
      console.error('周期执行失败：', e);
      process.exit(1);
    });
    return;
  }

  if (action === 'retire-check' || args.includes('--retire')) {
    const r = runRetireCheck();
    console.log('淘汰结果：', r);
    return;
  }

  if (action === 'value-update' || args.includes('--value')) {
    const r = updateAllValueScores();
    console.log('价值评分已更新');
    Object.values(r).forEach(c => {
      console.log(`  ${c.name}: value_score=${c.valueScore} (calls=${c.stats?.calls}, rate=${c.stats?.successRate})`);
    });
    return;
  }

  if (action === 'reflect' || args.includes('--reflect')) {
    runSelfReflection();
    return;
  }

  if (action === 'deploy' || args.includes('--deploy')) {
    const [id, name, dnaStr, score, source] = args.slice(args.indexOf('--deploy') + 1);
    if (!id || !name) {
      console.error('用法：--deploy <id> <name> <dna,comma,sep> <score> <source>');
      process.exit(1);
    }
    deployCapability(id, name, dnaStr.split(','), parseFloat(score), source);
    return;
  }

  // 默认：显示帮助
  console.log(`
MSOP 进化控制器 | 状态机调度器

用法：
  node evolution-controller.js status          查看能力注册表
  node evolution-controller.js run-cycle      运行完整进化周期
  node evolution-controller.js retire-check   执行淘汰检查
  node evolution-controller.js value-update  更新所有能力价值分
  node evolution-controller.js reflect       执行自我反思
  node evolution-controller.js deploy <id> <name> <dna> <score> <source>  注册新能力
  node evolution-controller.js --call <id>  记录一次能力调用（供OBSERVE用）

当前配置：
  进化模式: ${CONFIG.evolution_mode}
  自动通过阈值: ${CONFIG.auto_approve_threshold}
  淘汰条件: value_score < ${CONFIG.value_threshold} AND calls < ${CONFIG.usage_threshold} AND rate < ${CONFIG.success_rate_threshold}
  扫描间隔: ${CONFIG.scan_interval / 3600}h
`);
}

main();
