#!/usr/bin/env node
/**
 * notify-mei.js - 吞噬完成后通知MEI
 * 向飞书群聊发送吞噬结果汇总
 */
const https = require('https');

const APP_ID = 'cli_a91483224338dbd1';
const APP_SECRET = 'KZXWfAyjcuEnyAiaff3TDdyQanRzdiFW';
const CHAT_ID = 'oc_e6580ad4cb5aba32c479aa07e0b54a5f';

async function getToken() {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({ app_id: APP_ID, app_secret: APP_SECRET });
    const req = https.request({
      hostname: 'open.feishu.cn',
      path: '/open-apis/auth/v3/tenant_access_token/internal',
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
    }, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try { resolve(JSON.parse(d).tenant_access_token); }
        catch { reject(new Error('Token解析失败')); }
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

async function sendMessage(token, content) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      receive_id: CHAT_ID,
      msg_type: 'text',
      content: JSON.stringify({ text: content })
    });
    const req = https.request({
      hostname: 'open.feishu.cn',
      path: '/open-apis/im/v1/messages?receive_id_type=chat_id',
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body)
      }
    }, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try { resolve(JSON.parse(d)); }
        catch { resolve(d); }
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

async function main() {
  const approved = JSON.parse(process.argv[2] || '[]');
  const review = JSON.parse(process.argv[3] || '[]');

  if (approved.length === 0 && review.length === 0) {
    console.log('无可通知内容，退出');
    return;
  }

  try {
    const token = await getToken();
    let msg = '🧽 **MSOP 吞噬完成**\n\n';
    msg += `本轮自动吞噬 **${approved.length}** 个能力：\n`;
    if (approved.length > 0) {
      msg += approved.map(c => `• ${c.name} (⭐${c.msopScore || c.score || '?'})`).join('\n');
    } else {
      msg += '• （无）';
    }
    if (review.length > 0) {
      msg += `\n\n⚠️ **需人工审批 ${review.length} 个**：\n`;
      msg += review.map(c => `• ${c.name}`).join('\n');
      msg += '\n\n请确认是否吞噬';
    }
    msg += '\n\n_由 MSOP 自动运行_';

    const result = await sendMessage(token, msg);
    if (result?.code === 0) {
      console.log('✅ 通知发送成功');
    } else {
      console.log('⚠️ 通知发送结果:', result?.msg || JSON.stringify(result));
    }
  } catch (e) {
    console.error('❌ 通知发送失败:', e.message);
  }
}

main();
