#!/usr/bin/env node
/**
 * 猎物扫描器 - Prey Scanner
 * 参照 MSOP SCAN + GAP_ANALYSIS + TARGET_SELECTION
 * 
 * 职责：
 * ① 扫描 GitHub Trending / Clawhub / npm 寻找候选能力
 * ② 对照 capability-genome.md 缺口列表进行匹配
 * ③ 对候选目标进行评分（MSOP评分公式）
 * ④ 输出候选报告到 candidates/
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

const WORKSPACE = process.env.EVOLVE_WORKSPACE || __dirname;
const GENOME_FILE = path.join(WORKSPACE, 'capability-genome.md');
const CANDIDATES_DIR = path.join(WORKSPACE, 'candidates');
const REPORT_FILE = path.join(WORKSPACE, 'capability-hunt-report.md');

// 确保目录存在
if (!fs.existsSync(CANDIDATES_DIR)) fs.mkdirSync(CANDIDATES_DIR, { recursive: true });

// ===== 能力缺口定义（从genome读取的简化版）=====
const TARGET_GAPS = [
  { id: 'fin-data-api', name: '实时行情/财务数据', priority: 'P0', keywords: ['stock', 'finance', 'akshare', 'tushare', 'trading', 'market data', 'financial API'] },
  { id: 'cross-platform-docs', name: '跨平台文档', priority: 'P0', keywords: ['notion', 'google docs', 'confluence', 'obsidian', 'readme'] },
  { id: 'browser-auto', name: '浏览器自动化', priority: 'P1', keywords: ['playwright', 'puppeteer', 'selenium', 'browser automation', 'headless'] },
  { id: 'voice-understand', name: '音频语音理解', priority: 'P1', keywords: ['speech', 'voice', 'audio', 'transcription', 'whisper', 'ASR'] },
  { id: 'db-query', name: '数据库查询', priority: 'P1', keywords: ['sqlite', 'postgresql', 'mysql', 'database', 'sql query'] },
  { id: 'multi-agent', name: '多智能体协作', priority: 'P2', keywords: ['multi-agent', 'agent orchestration', 'crewai', 'autogen'] },
  { id: 'data-viz', name: '数据可视化', priority: 'P2', keywords: ['chart', 'visualization', 'dashboard', 'plotly', 'echarts', 'd3'] },
  { id: 'email-operate', name: '邮件收发', priority: 'P2', keywords: ['email', 'smtp', 'imap', 'gmail', 'mailgun'] },
];

// ===== GitHub Trending 抓取（API限流时降级）=====
function fetchGitHubTrending() {
  return new Promise((resolve) => {
    // 方案1：尝试API（带token优先）
    const token = process.env.GITHUB_TOKEN;
    const apiOptions = {
      hostname: 'api.github.com',
      path: '/search/repositories?q=stars:>500+pushed:>2026-01-01&sort=stars&order=desc&per_page=30',
      headers: {
        'User-Agent': 'OpenClaw-Evolve-Scanner/1.0',
        'Accept': 'application/vnd.github.v3+json',
        ...(token ? { 'Authorization': `token ${token}` } : {})
      }
    };

    https.get(apiOptions, res => {
      if (res.statusCode === 200) {
        let data = '';
        res.on('data', c => data += c);
        res.on('end', () => {
          try {
            const items = JSON.parse(data).items || [];
            if (items.length > 0) { console.log('[SCAN] GitHub API成功，获取到' + items.length + '个仓库'); resolve(items); return; }
          } catch {}
          // 解析失败，降级到爬虫
          fetchViaScraping().then(resolve).catch(() => resolve([]));
        });
      } else {
        // API失败，降级到爬虫
        console.log('[SCAN] GitHub API状态码=' + res.statusCode + '，降级到页面爬取');
        fetchViaScraping().then(resolve).catch(() => resolve([]));
      }
    }).on('error', () => {
      // 网络错误，降级到爬虫
      fetchViaScraping().then(resolve).catch(() => resolve([]));
    });
  });
}

// ===== 直接爬取 GitHub Trending 页面 =====
// 解析 https://github.com/trending?since=daily
function fetchViaScraping() {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'github.com',
      path: '/trending?since=daily',
      headers: { 'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36' }
    };

    https.get(options, res => {
      if (res.statusCode !== 200) { reject(new Error('status=' + res.statusCode)); return; }
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try {
          const repos = [];
          // 匹配 <h2 class="h3"><a href="/user/repo"> 或 <h2><a href="/owner/name">
          const repoRegex = /<h2\s+class="[^"]*h3[^"]*">\s*<a\s+href="(\/[^"]+\/[^"]+)">/g;
          const descRegex = /<p\s+class="[^"]*col-9[^"]*">([^<]+)<\/p>/g;
          const langRegex = /<span[^>]*itemprop="programmingLanguage"[^>]*>([^<]+)<\/span>/g;
          const starRegex = /<a[^>]*href="[^"]*\/stargazers[^"]*"[^>]*>\s*([\d,]+)\s*<\/a>/g;

          const hrefs = [...data.matchAll(repoRegex)].map(m => m[1]);
          const descriptions = [...data.matchAll(descRegex)].map(m => m[1].trim());
          const langs = [...data.matchAll(langRegex)].map(m => m[1].trim());
          const stars = [...data.matchAll(starRegex)].map(m => parseInt(m[1].replace(/,/g, '')) || 0);

          for (let i = 0; i < Math.min(hrefs.length, 30); i++) {
            const parts = hrefs[i].split('/');
            if (parts.length < 2) continue;
            const owner = parts[1];
            const name = parts[2] || parts[1];
            repos.push({
              full_name: owner + '/' + name,
              name: name,
              owner: { login: owner },
              html_url: 'https://github.com' + hrefs[i],
              description: descriptions[i] || '',
              stargazers_count: stars[i] || 0,
              language: langs[i] || null,
              pushed_at: new Date().toISOString(),
              license: { name: 'MIT' }, // 假设有license
            });
          }

          console.log('[SCAN] 页面爬取成功，解析到' + repos.length + '个仓库');
          resolve(repos);
        } catch (e) {
          console.log('[SCAN] 页面解析失败:', e.message);
          reject(e);
        }
      });
    }).on('error', reject);
  });
}

// ===== Clawhub API 获取热门skill =====
function fetchClawhubSkills() {
  return new Promise((resolve) => {
    const options = {
      hostname: 'clawhub.com',
      path: '/api/skills?sort=popular&limit=20',
      headers: { 'User-Agent': 'OpenClaw-Evolve-Scanner/1.0' }
    };
    let data = '';
    https.get(options, res => {
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve(JSON.parse(data).skills || []); }
        catch { resolve([]); }
      });
    }).on('error', () => resolve([]));
  });
}

// ===== 缺口匹配 =====
function matchGaps(repo) {
  const name = (repo.name + ' ' + (repo.description || '')).toLowerCase();
  const matched = [];
  for (const gap of TARGET_GAPS) {
    for (const kw of gap.keywords) {
      if (name.includes(kw.toLowerCase())) {
        matched.push({ gapId: gap.id, gapName: gap.name, priority: gap.priority, keyword: kw });
        break;
      }
    }
  }
  return matched;
}

// ===== MSOP评分公式（固定）=====
// score = innovation * 0.35 + integration * 0.25 + gap_match * 0.2 + popularity * 0.1 - risk * 0.3
function scoreRepo(repo, matches) {
  // innovation: 基于星标数和更新时间（高星+近期更新=高创新）
  const stars = repo.stargazers_count || 0;
  const pushedDaysAgo = repo.pushed_at
    ? (Date.now() - new Date(repo.pushed_at).getTime()) / (1000 * 3600 * 24)
    : 999;
  const recencyBonus = pushedDaysAgo < 7 ? 1.5 : pushedDaysAgo < 30 ? 1.2 : 1.0;
  const innovation = Math.min(10, Math.max(3,
    stars > 50000 ? 9.5 * recencyBonus :
    stars > 10000 ? 8.5 * recencyBonus :
    stars > 1000  ? 7.5 * recencyBonus :
    stars > 100   ? 6.0 : 4.0
  ));

  // integration: 与现有系统集成度（MIT许可+多工具支持=高分）
  const integration = matches.length > 0 ? 8.5 : 5;

  // gap_match: 匹配缺口数量
  const gap_match = Math.min(10, matches.length * 4 + (matches.length > 0 ? 2 : 0));

  // popularity: 基于星标（归一化到10分）
  const popularity = Math.min(10, stars / 500);

  // risk: 有license=低风险，无license=高风险
  const risk = repo.license?.name ? 1.5 : 4;

  const score = innovation * 0.35 + integration * 0.25 + gap_match * 0.2 + popularity * 0.1 - risk * 0.3;
  return {
    score: Math.round(score * 10) / 10,
    innovationScore: Math.round(innovation * 10) / 10,
    integrationScore: Math.round(integration * 10) / 10,
    gapMatchScore: Math.round(gap_match * 10) / 10,
    popularityScore: Math.round(popularity * 10) / 10,
    riskScore: risk,
    breakdown: {
      innovation: innovation.toFixed(1),
      integration: integration.toFixed(1),
      gap_match: gap_match.toFixed(1),
      popularity: popularity.toFixed(1),
      risk: risk.toFixed(1)
    }
  };
}

// ===== 报告生成 =====
function generateReport(repos, clawhubSkills) {
  const date = new Date().toISOString().slice(0, 10);
  const candidates = repos.map(r => {
    const matches = matchGaps(r);
    const sc = scoreRepo(r, matches);
    return { ...r, matches, score: sc.score, breakdown: sc.breakdown };
  }).filter(r => r.score >= 5.5 || r.matches.length > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 15);

  let md = `# 🏹 能力狩猎报告\n`;
  md += `> 扫描时间：${date}  |  来源：GitHub Trending + Clawhub  |  匹配缺口：${TARGET_GAPS.length}个\n\n`;

  md += `## 📊 匹配缺口一览\n\n`;
  for (const gap of TARGET_GAPS) {
    const found = candidates.filter(c => c.matches.some(m => m.gapId === gap.id));
    md += `- **[${gap.priority}] ${gap.name}**：${found.length}个候选\n`;
  }

  md += `\n## 🥇 候选目标 TOP 15\n\n`;
  md += `| 排名 | 仓库 | 评分 | 匹配缺口 | Stars | 风险 |\n`;
  md += `|------|------|------|----------|-------|------|\n`;
  candidates.forEach((r, i) => {
    const gapNames = r.matches.map(m => `\`${m.gapName}\``).join(', ') || '综合';
    const badge = r.score >= 7 ? '🟢' : r.score >= 6 ? '🟡' : '🔴';
    md += `| ${i + 1} | [${r.name}](${r.html_url}) | ${badge} ${r.score} | ${gapNames} | ${r.stargazers_count} | ${r.license?.name || '无'} |\n`;
  });

  md += `\n## 📋 详细评分拆解\n\n`;
  candidates.slice(0, 8).forEach(r => {
    md += `### ${r.name} \`${r.score}/10\`\n`;
    md += `- Stars: ${r.stargazers_count} | 描述: ${r.description || '无'}\n`;
    md += `- 公式拆解：innovation×0.35(${r.breakdown.innovation}) + integration×0.25(${r.breakdown.integration}) + gap_match×0.2(${r.breakdown.gap_match}) + popularity×0.1(${r.breakdown.popularity}) - risk×0.3(${r.breakdown.risk})\n`;
    if (r.matches.length > 0) {
      md += `- 🎯 匹配缺口：${r.matches.map(m => `${m.gapName}(${m.keyword})`).join('、')}\n`;
    }
    md += `- 🔗 ${r.html_url}\n\n`;
  });

  // 建议行动
  const highPriority = candidates.filter(r => r.score >= 7);
  md += `## 🚀 下一步行动建议\n\n`;
  if (highPriority.length > 0) {
    md += `**推荐立即吞噬（评分≥7）：**\n`;
    highPriority.forEach(r => {
      md += `- [ ] **${r.name}** (${r.score}) — 匹配${r.matches[0]?.gapName}，${r.html_url}\n`;
    });
    md += `\n`;
  }
  md += `**P0缺口补充建议：**\n`;
  const p0Gaps = TARGET_GAPS.filter(g => g.priority === 'P0');
  p0Gaps.forEach(g => {
    const found = candidates.filter(c => c.matches.some(m => m.gapId === g.id));
    if (found.length === 0) {
      md += `- ⚠️ **[${g.id}] ${g.name}** — 无候选，需手动搜索补充\n`;
    } else {
      md += `- ✅ **[${g.id}] ${g.name}** — ${found.length}个候选，建议优先扫描\n`;
    }
  });

  md += `\n---\n*由 OpenClaw 能力进化系统自动生成 | 🧬 MSOP v1.0*\n`;
  return md;
}

// ===== 主流程 =====
async function main() {
  console.log('[�猎物] 开始扫描...');
  
  const [repos, clawhubSkills] = await Promise.all([
    fetchGitHubTrending(),
    fetchClawhubSkills()
  ]);

  console.log(`[�猎物] 获取到 ${repos.length} 个GitHub仓库`);
  console.log(`[�猎物] 获取到 ${clawhubSkills.length} 个Clawhub技能`);

  const report = generateReport(repos, clawhubSkills);
  fs.writeFileSync(REPORT_FILE, report, 'utf-8');
  console.log(`[�猎物] 报告已生成：${REPORT_FILE}`);

  // 保存候选列表JSON
  const candidates = repos.map(r => {
    const matches = matchGaps(r);
    const sc = scoreRepo(r, matches);
    return {
      name: r.name,
      full_name: r.full_name,
      score: sc.score,
      innovationScore: sc.innovationScore,
      integrationScore: sc.integrationScore,
      gapMatchScore: sc.gapMatchScore,
      popularityScore: sc.popularityScore,
      riskScore: sc.riskScore,
      matches,
      stars: r.stargazers_count,
      url: r.html_url,
      description: r.description,
      language: r.language,
      license: r.license?.name || null,
      pushed_at: r.pushed_at,
    };
  }).filter(r => r.score >= 5.5 || r.matches.length > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 20);

  fs.writeFileSync(path.join(CANDIDATES_DIR, `candidates-${Date.now()}.json`), JSON.stringify(candidates, null, 2));
  fs.writeFileSync(path.join(CANDIDATES_DIR, 'latest-candidates.json'), JSON.stringify(candidates, null, 2));
  console.log(`[�猎物] 候选列表已存档，共 ${candidates.length} 个`);

  // 打印摘要
  const top5 = candidates.slice(0, 5);
  console.log('\n🏆 TOP 5 候选：');
  top5.forEach((c, i) => {
    console.log(`  ${i + 1}. [${c.score}] ${c.name} — 匹配: ${c.matches.map(m => m.gapName).join(', ')}`);
  });
}

main().catch(console.error);
